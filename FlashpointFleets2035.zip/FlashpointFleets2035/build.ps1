# ============================================================================
# Flashpoint Fleets 2035 - build script (both DLLs)
# Usage:
#   powershell -ExecutionPolicy Bypass -File build.ps1
#   powershell -ExecutionPolicy Bypass -File build.ps1 -GameDir "D:\Games\Nuclear Option\Nuclear Option"
#   ... -Deploy              also copies outputs into the game's BepInEx/plugins
#   ... -UnityPlugins <path> also copies the main DLL into the Blueprinter
#                            Unity project's Assets/Plugins folder
# Requirements: .NET SDK 6+ (dotnet), your local Nuclear Option install.
# ============================================================================

param(
    [string]$GameDir = "C:\Games\Nuclear Option\Nuclear Option",
    [switch]$Deploy,
    [string]$UnityPlugins = "C:\Users\admin\Downloads\Blueprinter-Editor\Assets\Plugins"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $root "dist"
New-Item -ItemType Directory -Force -Path $out | Out-Null

if (-not (Test-Path (Join-Path $GameDir "NuclearOption_Data\Managed\Assembly-CSharp.dll"))) {
    Write-Host "!! Assembly-CSharp.dll not found under $GameDir" -ForegroundColor Red
    Write-Host "   Pass your game folder:  -GameDir `"C:\path\to\Nuclear Option`"" -ForegroundColor Yellow
    Write-Host "   (the folder that contains NuclearOption.exe)" -ForegroundColor Yellow
    exit 1
}

Write-Host "== Flashpoint Fleets 2035 build ==" -ForegroundColor Cyan
Write-Host "   GameDir: $GameDir"

& dotnet build (Join-Path $root "Plugin\FlashpointFleets2035.csproj") `
    -c Release -p:GameDir="$GameDir" -o $out
if ($LASTEXITCODE -ne 0) { throw "main plugin build failed" }

& dotnet build (Join-Path $root "TorpedoShield\TorpedoShield.csproj") `
    -c Release -p:GameDir="$GameDir" -o $out
if ($LASTEXITCODE -ne 0) { throw "TorpedoShield build failed" }

Write-Host ""
Write-Host "Built:" -ForegroundColor Green
Get-ChildItem $out -Filter *.dll | ForEach-Object { Write-Host "   $($_.FullName)" }

if ($UnityPlugins -ne "") {
    New-Item -ItemType Directory -Force -Path $UnityPlugins | Out-Null
    Copy-Item (Join-Path $out "FlashpointFleets2035.dll") $UnityPlugins -Force
    Write-Host "Copied FlashpointFleets2035.dll -> $UnityPlugins (for the Unity prefab factory)" -ForegroundColor Green
}

if ($Deploy) {
    $plugins = Join-Path $GameDir "BepInEx\plugins"
    New-Item -ItemType Directory -Force -Path $plugins | Out-Null
    Copy-Item (Join-Path $out "FlashpointFleets2035.dll") $plugins -Force
    Copy-Item (Join-Path $out "TorpedoShield.dll") $plugins -Force
    Write-Host "Deployed both DLLs -> $plugins" -ForegroundColor Green
    Write-Host "Remember to also place FlashpointFleets2035.nobp (built with Blueprinter) there." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Copy FlashpointFleets2035.dll into the Unity project's Assets\Plugins folder"
Write-Host "     (or re-run with -UnityPlugins <path>) so the prefab factory can attach"
Write-Host "     FFNoisemakerRack / FFResupplyShip to the ship prefabs."
Write-Host "  2. In the Blueprinter Editor Unity project: FF > Build All Ships."
Write-Host "  3. Blueprinter > Mod Builder > FlashpointFleets2035 > Build Mod -> .nobp"
Write-Host "  4. Ship the .nobp next to the two DLLs in BepInEx/plugins."
