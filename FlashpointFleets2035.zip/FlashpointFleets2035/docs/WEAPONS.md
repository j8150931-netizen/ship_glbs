# WEAPONS - Flashpoint Fleets 2035 catalog

All fifteen weapons are created at runtime by cloning vanilla missile prefabs
(the torpedo-mod technique) and re-stating motors/warheads/seeker profiles. Donor
mapping is resilient: each entry has a fallback chain, and if the primary donor is
absent in your game version the loader walks the chain and logs what it used.

Stat semantics (mirroring SonPamungkas' Torpedo mod):

* `speedMult` - top speed; thrust scales with sqrt so the flight profile stays stable
* `burnTimeMult` - motor burn time = range
* `blastMult` / `pierceBonus` - warhead blast and armor piercing (pierce matters vs
  `ShipPart.armorProperties`)
* `skimAltitude` - terminal sea-skim altitude (meters); `-1` = no profile change

## PLAN

| Weapon | Role | Donor | speed | burn | blast | pierce+ | Notes |
|---|---|---|---|---|---|---|---|
| **HHQ-9B** | LR SAM | SAM chain | 0.96x | 1.45x | 0.85x | - | area denial, long legs |
| **HHQ-16FE** | MR SAM | SAM chain | 1.02x | 1.00x | 0.55x | - | fast lock vs sea-skimmers |
| **HHQ-10** | RAM-class | R-45 chain | 1.10x | 0.55x | 0.30x | - | terminal defense, 24 rds |
| **YJ-18A** | AShM | AShM1 | 1.15x | 1.25x | 1.35x | 800 | **sea-skim 6 m**, supersonic sprint |
| **YJ-83K** | AShM | AShM1 | 0.88x | 1.10x | 0.90x | 400 | **sea-skim 8 m**, cheap salvo weapon |
| **Yu-8** | ASW | AShM1 | 0.80x | 0.60x | 1.10x | - | swims with Torpedo mod, standoff rocket without |

## Russian Federation

| Weapon | Role | Donor | speed | burn | blast | pierce+ | Notes |
|---|---|---|---|---|---|---|---|
| **48N6DM (S-400)** | LR SAM | SAM chain | 1.12x | 1.60x | 1.00x | - | the longest legs in the pack |
| **9M96E2 (Redut)** | MR SAM | SAM chain | 1.05x | 0.90x | 0.50x | - | agile active-radar quad-pack |
| **P-800 Oniks** | AShM | AShM1 | **1.45x** | 1.15x | 1.50x | 1500 | **sea-skim 5 m**, Mach 2+ class |
| **3M-54 Kalibr** | AShM/LACM | CruiseMissile1 | 0.92x | 1.50x | 1.30x | 900 | **sea-skim 10 m**, marathon range |

## United States

| Weapon | Role | Donor | speed | burn | blast | pierce+ | Notes |
|---|---|---|---|---|---|---|---|
| **RIM-174 SM-6** | LR SAM + AShM | SAM chain | 1.08x | 1.35x | 0.80x | - | dual role (antiAir + antiSurface) |
| **RIM-66 SM-2MR** | MR SAM | SAM chain | 1.00x | 1.05x | 0.65x | - | salvo-friendly |
| **RIM-162 ESSM** | SR/point SAM | SAM chain | 1.15x | 0.75x | 0.40x | - | fastest lock in the pack |
| **RIM-116 RAM** | RAM | R-45 chain | 1.20x | 0.50x | 0.30x | - | 21 rds x2 launchers |
| **Mk54 MAKO (VLA)** | ASW | AShM1 | 0.85x | 0.65x | 1.15x | - | vertical-launch ASW; named for the SCT-350 Mako lineage |

## How the launcher wiring works

Each ship launcher prefab carries the catalog key in its GameObject name
(e.g. `FF_T055_VLS_Fore_FF_HHQ9B`). After `Encyclopedia.AfterLoad` the plugin clones each
catalog missile, registers its `MissileDefinition` in the encyclopedia, and swaps the
`info` + `missile` fields of every matching launcher. Because the whole catalog is
runtime-cloned from vanilla assets:

* no game assets are redistributed (the .nobp only contains our ship meshes),
* prefab hashes are re-assigned for Mirage networking (multiplayer-safe),
* it works alongside other weapon packs (Eroge's, Aryx Weaponry, Multi-Missile) - they
  patch different names.

If a donor missile genuinely cannot be found (heavily renamed game version), the launcher
silently keeps its vanilla loadout and the log states which key failed - the ships still
sail and fight.

## Sea-skim terminal profiles

`SeaSkimmer.cs` post-fixes `Missile.SetAimpoint` for catalog keys with a skim altitude:
once the cloned cruise seeker enters terminal mode the altitude target is clamped to
5-10 m, so YJ-18A / YJ-83K / Oniks / Kalibr ride the wave tops under the radar horizon
into the hull. The patch is name-gated and postfix-only - it cannot affect vanilla
missiles, other packs, or the Torpedo mod (which prefixes the same method for different
names).

## ASW behavior

* **With SonPamungkas' Torpedo mod installed**: Mk54 / Yu-8 entries inherit swimming
  physics from the ecosystem (they detect as torpedoes themselves and can be intercepted
  by enemy TorpedoShield ships - symmetric warfare).
* **Without it**: both degrade to short-burn standoff ASW rockets - they bracket the
  datum with a shallow attack instead of swimming. The log states this once at startup.
