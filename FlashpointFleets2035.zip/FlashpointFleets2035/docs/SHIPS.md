# SHIPS - Flashpoint Fleets 2035 specifications

All coordinates: canonical ship space (+Z bow, +Y up, origin at waterline center).
Sections are listed bow -> stern; `SectionNN` indices refer to the model groups
(Section00 = stern band ... SectionNN = bow band, as exported by the prep pipeline).

---

## FF_T055 - Renhai-class Cruiser (Type 055) - PLAN

| Parameter | Value |
|---|---|
| LOA / beam / mast height | 180 m / 26.6 m (model) / 39.1 m |
| Draft (waterline placement) | 6.6 m |
| Speed (game units) | 32 |
| Value / manpower / armor tier | 2600 / 400 / 6 |
| Radar | 30 km omni on the integrated mast (dual-band profile) |

**Damage sections (9)** - Bow (110 HP) / ForeVLS (130, **ammo rack**) / Bridge (120,
critical) / MastFunnel (110) / Midships (150) / AftVLS (130, **ammo rack**) / HangarBlock
(140) / HangarMouth (120) / FlightDeckStern (110, weakest joints - tears off first).
Every band: independent displacement (buoyancy), leak threshold 80 %, leak 1-2.5 units/s,
sink at 75 % flooded, break-joint 8,000-12,000. Piercing/blast armor 380-420.

**Weapons (full count)**

| Mount | Type | Cells / ammo | Position |
|---|---|---|---|
| FF_T055_VLS_Fore_FF_HHQ9B | HHQ-9B SAM | 8x8 = 64 cells, 64 rds | fo'c'sle, z +55 |
| FF_T055_VLS_Aft_FF_HHQ9B | HHQ-9B SAM | 8x4 = 32 cells, 32 rds | z -22 |
| FF_T055_VLS_Aft_FF_YJ18A | YJ-18A AShM | 8x2 = 16 cells, 16 rds | z -38 |
| FF_T055_HQ10_FF_HHQ10 | HHQ-10 RAM | 24 rds | hangar top, z -68, facing aft |
| FF_T055_CIWS_Port / _Stbd | 1130-style CIWS | - | z +28 fwd / z -62 aft |
| FF_T055_Gun130 | 130 mm | - | bow, z +74 |
| FF_T055_ASROC_FF_Yu8 | Yu-8 ASW | 2 cells, 6 rds | port bridge wing |

**Aviation**: twin-spot hangar (18 m mouth) + 24 m flight deck, vertical landing point,
rearm access.

---

## FF_T054A - Jiangkai II-class Frigate (Type 054A) - PLAN

| Parameter | Value |
|---|---|
| LOA / beam / mast | 134 m / 17.6 m / 29.3 m |
| Draft | 4.3 m |
| Speed | 27 |
| Value / manpower / armor | 900 / 190 / 3 |
| Radar | 18 km omni |

**Damage sections (8)** - Bow (80) / ForeVLS (95, ammo rack) / Bridge (85, critical) /
MastBlock (85) / Midships (100, ammo rack - YJ-83 canisters) / Funnel (90) / Hangar (95) /
SternDeck (80).

**Weapons**: 32-cell VLS HHQ-16FE (4x8), 2x4 YJ-83K inclined canisters, 2x 730-style
CIWS on hangar shoulders, 76 mm main gun, 2-tube Yu-8 ASW. **Aviation**: single-helo
hangar + 18 m deck.

---

## FF_NAKH - Admiral Nakhimov (2035 refit) - Russian Federation

| Parameter | Value |
|---|---|
| LOA / beam / mast | 252 m / 30 m / 57.6 m |
| Draft | 7.6 m |
| Speed | 31 |
| Value / manpower / armor | 4200 / 760 / 8 (heaviest belt in the pack) |
| Radar | 32 km omni |

**Damage sections (10)** - Bow (160) / GunMounts (170, ammo rack) / S400Field (190,
ammo rack) / ForeDeck (180) / Tower (165, critical) / UKSKDeck (185, ammo rack) /
FunnelBlock (175) / AftVLS (170, ammo rack) / Hangar (165) / SternDeck (150).
Four ammunition-rack bands - this ship detonates spectacularly when caught.

**Weapons (full count, 128 cells + guns)**

| Mount | Type | Cells / ammo |
|---|---|---|
| FF_NAKH_S400_L / _R_FF_48N6DM | 48N6DM (S-400) | 4x12 x2 = 48 cells, 48 rds |
| FF_NAKH_UKSK_FF_Oniks | P-800 Oniks | 4x12 = 24 cells, 24 rds |
| FF_NAKH_UKSK_FF_Kalibr | 3M-54 Kalibr | 4x12 = 24 cells, 24 rds |
| FF_NAKH_Redut_FF_9M96E2 | 9M96E2 (Redut) | 8x4 = 32 cells, 32 rds |
| FF_NAKH_Kashtan_FL/FR/AL/AR | Kashtan-M CIWS x4 | guns + missiles |
| FF_NAKH_Gun130_1 / _2 | twin 130 mm mounts x2 | bow, superfiring |
| FF_NAKH_RBU_FF_Yu8 | ASW rockets | 2 cells, 8 rds |

**Aviation**: twin-helo hangar (the model even ships its Ka-27 parked on the stern deck).

---

## FF_HAW - USS Hawaii (CSGN 2030 refit) - United States

| Parameter | Value |
|---|---|
| LOA / beam / mast | 240 m / 34 m / 55.2 m |
| Draft | 9.5 m |
| Speed | 30 |
| Value / manpower / armor | 3600 / 520 / 6 |
| Radar | 34 km omni (Aegis SPY profile) |

**Damage sections (10)** - Bow (150) / RailgunDeck (160, ammo rack) / ForeVLS (180, ammo
rack) / Bridge (160, critical) / AegisTower (165) / Midships (175) / AftVLS (170, ammo
rack) / HangarBlock (165) / HangarMouth (150) / SternDeck (145).

**Weapons (96 Mk41 cells + 42 RAM rounds + guns)**

| Mount | Type | Cells / ammo |
|---|---|---|
| FF_HAW_VLS_Fore_FF_SM6 | SM-6 | 4x8 = 32 cells |
| FF_HAW_VLS_Fore_FF_ESSM | ESSM | 4x8 = 32 cells |
| FF_HAW_VLS_Aft_FF_SM2 | SM-2MR | 4x4 = 16 cells |
| FF_HAW_VLS_Aft_VLA_FF_Mk54 | Mk54 MAKO VLA (ASW) | 4x4 = 16 cells |
| FF_HAW_Railgun_P / _S | railgun turrets x2 | bow, superfiring |
| FF_HAW_RAM_Fwd / _Aft_FF_RIM116 | RIM-116 RAM x2 | 21 rds each |
| FF_HAW_CIWS_Port / _Stbd | CIWS x2 | bridge wings / aft |

**Aviation**: twin-spot hangar, 26 m flight deck.

---

## Damage-model notes

* Sections use the game's native `ShipPart` flooding: below `leakThreshold` % HP the band
  takes water at `leakRateMin`-`leakRateMax`; at `sinkThreshold` (75 %) flooded it loses
  buoyancy (`displacement`) and drags the hull down; joints break at
  `breakJointStrength` so destroyed bands tear off and sink independently.
* Ammo racks are 35 HP `UnitPart` boxes inside VLS/gun bands - a penetrating hit there
  cooks the magazine: secondary detonation plus instant section damage.
* `criticalParts` (bridge/tower bands) at `criticalRatio` 0.5: lose half the bridge and
  the ship is disabled - radar dark, weapons slaved, adrift.
* Torpedo hits on any band flood it immediately (the torpedo mod's warheads deal massive
  pierce); the TorpedoShield companion exists precisely to blunt that.
