# COMPATIBILITY - Flashpoint Fleets 2035

## Loadout / ecosystem

| Mod | Status | Notes |
|---|---|---|
| **BepInEx 5.4.x** | Required | standard loader |
| **Blueprinter 2.1.x** (Nikkorap) | Required | loads the `.nobp`; the main DLL declares the dependency |
| **Torpedo** (SonPamungkas) | Recommended | Mk54/Yu-8 swim as real torpedoes; Mako/Hammerhead/Lemon/Megalodon become the threats TorpedoShield defends against. Soft dependency - everything degrades gracefully without it |
| **GOTH MOMMY** (SonPamungkas) | Recommended | fully compatible by design (see below). Soft dependency |
| **Aryx Naval Expansion** (Aryx3D) | Compatible | both packs register separate `ShipDefinition`s; TorpedoShield explicitly covers ANE ships (they are `Ship` units) |
| **BOTE** (MinecrackTyler) | Compatible | BOTE ships are `AircraftDefinition`-based; TorpedoShield's sonar covers them via the `Ship` component where present, and its AimPoint/CIWS patches are class-wide |
| **Eroge's Missile Pack / Aryx Weaponry / Multi-Missile** | Compatible | they patch different missile names; our launcher wiring only touches `FF_`-prefixed launchers |
| **1509 Ship Pack (Destrier)** | Compatible | standard ShipDefinition units - TorpedoShield defends them too |

## GOTH MOMMY - how the composition works

GOTH installs Harmony **prefixes** on `Radar.RadarCheck`, `Radar.CanSeeRadarReturn`,
`DetectorManager.RequestRadarCheck`, `Turret.*`, `MissileLauncher.Fire`, etc. - when its
config is on it *replaces* the vanilla detection math with over-the-horizon refraction.

TorpedoShield installs **postfixes** on the same methods. Harmony runs prefixes first,
then (whether or not the original ran), postfixes - so:

1. GOTH's OTH radar sweep executes (or vanilla's, if GOTH is off) - untouched.
2. TorpedoShield's `RadarCheck` postfix adds torpedo contacts inside the sonar envelope.
3. GOTH's `CanSeeRadarReturn` prefix computes its signal score; TorpedoShield's postfix
   then forces the return visible **only for torpedo contacts within sonar range**.
4. In target assessment, TorpedoShield's `AssessTargetPriority` postfix runs after
   GOTH's coordinator: ASW launchers get top priority on torpedo tracks, guns only for
   surfaced torpedoes, everything else is told to ignore them (so GOTH's SAM coordinator
   doesn't dump the magazine into the sea).

Additionally, `GothCompat` reads GOTH's `SAM_ThreatReengageCooldown` via reflection when
present so torpedo engagement pacing mirrors GOTH's, and it honors GOTH's fleet
`missileAttacks` bookkeeping (`AlreadyEngagedByFleet`) to avoid double-allocating
interceptors.

Load order does not matter (no hard references between the two plugins).

## Multiplayer policy

Same rule as the torpedo mod: **all players must run the same set of mods**. The ships,
missiles and launchers are standard networked units (Mirage `NetworkIdentity`, prefab
hashes re-assigned on clone). TorpedoShield's detection patches are simulation-side and
identical on every client. The noisemaker buoy *visuals* are local-only decoration; the
seduction steering is deterministic from the shared buoy registry.

## Known limitations (honest list)

* **SAM donor names vary** by game version. The catalog walks a fallback chain
  (`SAM1 -> SAM2 -> SAM3 -> R-45 -> R45 -> AShM1`) and logs what it used; run
  `FF > Dump Game Assets` once to verify and tune `FF_ShipSpec.cs` if needed.
* **Without the Torpedo mod**, Mk54 / Yu-8 are standoff rockets, not swimmers (logged at
  startup), and there is no vanilla torpedo threat for TorpedoShield to fight - it still
  defends against any torpedo-modded opponent.
* **CIWS vs deep torpedoes**: guns only engage torpedoes running shallower than ~1.2 m
  (bullets don't curve underwater; hard-kill for deep runners is the ASW launcher's
  job). Surfaced/sprint torpedoes like the Mako are valid gun targets.
* **Seduction is an aimpoint nudge**, not a full acoustic model: it biases torpedo
  steering toward buoys inside 900 m with a per-call pull; it can be resisted by
  re-locked guidance (just like real noisemakers vs modern torpedoes).
* **Evasion steering** (`CombTracks`) nudges `ShipPropulsion` inputs by reflection; if a
  future game update renames that field the feature disables itself silently (logged in
  debug) rather than throwing.
* **Railguns on the Hawaii** use the vanilla gun/railgun donor assets; their over-the-
  horizon behavior improves further with GOTH's naval bombardment module active.
* The **USS Hawaii** model's fictional CSGN 2030 refit had no published class data - the
  240 m / 96-cell / twin-railgun fit is a design interpretation consistent with the
  model's geometry.
* Full-count VLS (112 cells on a Type 055, etc.) is AI-magazine-based: each launcher
  cycles its ammo pool across the visible cells - matching ANE's approach (their
  HeavyFrigate carries 32 rounds per launcher) while showing every cell.

## Version notes

* Built against game 0.34.x / Unity 2022.3.62f3 / Blueprinter 2.1.x (the exact revision
  the ANE 1.0.4 bundle reports).
* Component field layout was verified 1:1 against ANE 1.0.4's published bundle
  (`Ship`, `ShipPart`, `Turret`, `MissileLauncher`, `Radar`, `Hangar`, `Airbase`,
  `ShipPropulsion`, `FireControl`, `Rearmer`, `ShipDefinition` serialized layouts).
