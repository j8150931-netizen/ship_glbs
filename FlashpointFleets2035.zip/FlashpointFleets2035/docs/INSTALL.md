# INSTALL - Flashpoint Fleets 2035 (player guide)

## Requirements

* Nuclear Option (0.34.x)
* **BepInEx 5** (Windows x64) installed in the game folder
* **Blueprinter 2.1.x** (`Blueprinter.dll` in `BepInEx/plugins`)
* Recommended: SonPamungkas' **Torpedo** mod (your Mk54 / Yu-8 actually swim, and the
  Mako / Hammerhead become the threat these ships defend against)
* Recommended: SonPamungkas' **GOTH MOMMY** (radar/over-the-horizon overhaul -
  TorpedoShield is built to run alongside it)

## Install

Drop the release files into `C:\Games\Nuclear Option\Nuclear Option\BepInEx\plugins\`
(any subfolder works - Blueprinter scans recursively):

```
BepInEx/plugins/
├── Blueprinter.dll                     (dependency, if not already present)
├── FlashpointFleets2035.dll            (main mod)
├── FlashpointFleets2035.nobp           (ships - must sit next to the DLL)
└── TorpedoShield.dll                   (companion: torpedo defense for ALL ships)
```

Run the game. In the mission editor / spawn menu, search the **Naval** category for:

* Renhai-class Cruiser (Type 055)
* Jiangkai II-class Frigate (Type 054A)
* Admiral Nakhimov (2035 Refit)
* USS Hawaii (CSGN 2030 Refit)

All four are available to **both factions** by design.

## What you get in flight

* Commandable AI warships (drive them like other ships: waypoint, strike, patrol orders)
  with ANE-class behavior - they maneuver, use standoff range, screen, and defend
  themselves with the full air-defense stack.
* SAMs ripple out of **individually modeled VLS cells** (112 on the Type 055, 80 on the
  Nakhimov, 96 on the Hawaii...), each cell cold-launching with ejection smoke.
* Anti-ship missiles run **sea-skim terminal profiles** (YJ-18A, YJ-83K, Oniks, Kalibr).
* Functional **hangars**: land a helicopter on the marked flight deck, taxi in, rearm at
  the ship (`Rearmer`), repair and relaunch. The ships also rearm each other.
* **Damage model**: hit a VLS field and watch the cook-off; hole the bow and the section
  floods, lists and tears off; lose the bridge and the radar goes dark; the ship sinks
  progressively by compartment.
* **Torpedo defense** (TorpedoShield): ships sonar-detect incoming torpedoes (Mako,
  Hammerhead, Lemon, Megalodon or any future torpedo mod), launch ASW interceptors,
  auto-deploy noisemaker decoys, comb the tracks, and CIWS engage surfaced torpedoes.
  Works on vanilla and Aryx Naval Expansion ships too.

## Configuration (BepInEx/config)

* `FlashpointFleets2035.cfg` - weapon creation, sea-skim profiles, noisemaker radius /
  cooldown
* `TorpedoShield.cfg` - sonar ranges, classification mode (ByName/ByTrait/Both),
  interceptor / CIWS / SAM engagement rules, seduction radius, evasion on-off

Everything is safe in multiplayer as long as all players run the same mods (the ships and
weapons are standard networked units; the torpedo mod itself documents the same policy).

## Uninstall

Delete the four files above. No game files are modified.
