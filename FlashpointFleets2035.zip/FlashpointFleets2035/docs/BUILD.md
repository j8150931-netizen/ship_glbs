# BUILD - Flashpoint Fleets 2035

You said your toolchain is ready (BepInEx 5 + Blueprinter + Unity 2022.3.62f2 + AssetRipper
with the Blueprinter Editor project set up, `_donotship` populated). If any of that is
missing, follow Nikkorap's GUIDE.md in NOBlueprinter-Editor first - the steps below assume
a working Blueprinter Editor project.

## 0. Requirements check

```
C:\Games\Nuclear Option\Nuclear Option\NuclearOption_Data\Managed\Assembly-CSharp.dll   (game refs)
dotnet --version          (6 or newer)
Unity 2022.3.62f2 project with Blueprinter set up + _donotship imported
```

## 1. Build the two DLLs

From the repo root:

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1 `
    -GameDir "C:\Games\Nuclear Option\Nuclear Option" `
    -UnityPlugins "<your Blueprinter Editor project path>\Assets\Plugins"
```

Outputs `dist\FlashpointFleets2035.dll` and `dist\TorpedoShield.dll`, and copies the main
DLL into the Unity project's `Assets/Plugins` (the prefab factory attaches
`FFNoisemakerRack` / `FFResupplyShip` from it).

> If you prefer building in the IDE: open `Plugin/FlashpointFleets2035.csproj` and
> `TorpedoShield/TorpedoShield.csproj`. The `GameDir` MSBuild property defaults to
> `C:\Games\Nuclear Option\Nuclear Option`.

## 2. Install the assets into the Unity project

Copy from `UnityProject/Assets/`:

* `Blueprinter/Mods/FlashpointFleets2035/` -> your project's `Assets/Blueprinter/Mods/`
  (contains `ModInfo.json` + `Models/<Ship>/OBJ` with obj/mtl/textures and manifests)
* `FlashpointFleets/Editor/` -> your project's `Assets/FlashpointFleets/Editor/`

Let Unity import (the 054A textures are 4x2048; Hawaii OBJ is 565k tris - import takes a
moment). `FF_ImportPostprocessor` forces meter-scale import and converts the OBJ materials
to URP Lit automatically.

## 3. One-time donor check

Menu: **FF > Dump Game Assets** - writes `ff_game_assets_report.txt` listing every vanilla
`MissileDefinition`, `WeaponMount`, `ShipDefinition` and every prefab with a
`MissileLauncher` or `Gun`. Verify:

* donors `AShM1`, `AShM2`, `CruiseMissile1` exist (they always do - the torpedo mod and
  ANE rely on them),
* a SAM donor among `SAM1/SAM2/R-45/R45` (the fallback chain tries them in order and
  falls back to `AShM1` with a console warning),
* a `CIWS`/`Gun` prefab name (any prefab with a `Gun` component works as fallback).

If a name in your game version differs, edit `FF_ShipSpec.cs` `donorPrefab` fields.

## 4. Build the ships

Menu: **FF > Build All Ships** (or per-ship under FF > Build Ship). This generates, per ship:

* `Assets/Blueprinter/Mods/FlashpointFleets2035/Prefabs/FF_<id>.prefab`
* `Assets/Blueprinter/Mods/FlashpointFleets2035/Definitions/FF_<id>_Definition.asset`
* a build report in `Assets/Blueprinter/Mods/FlashpointFleets2035/BuildReports/`

Then **FF > Validate Mod** - checks models, prefabs, components, launchers, hangars and
the mod DLL. Fix anything red (usually a donor name) and rebuild.

### What the builder does, exactly

1. Instantiates the prepared hull model; groups `SectionNN__*` mesh objects under named
   `ShipPart` bands (stern -> bow) with per-section mass / displacement / leak rates /
   sink threshold / armor - the game's own progressive-flooding damage model, configured
   to ANE's pattern.
2. Root gets `Ship`, `ShipPart`, `Rigidbody`, `UnitCommand`, `ShipNetworkTransform`,
   `NetworkIdentity`, `SetGlobalParticles`, `ShipAI`, `FireControl`, `Capture`,
   `Airbase`, `Rearmer` (+ mod scripts from the DLL).
3. Sensors: `Radar` (masthead, full `RadarParameters`) + bridge `TargetDetector`, wired
   to the ship and to every turret.
4. Weapons: vanilla donor launcher/gun prefabs are cloned, renamed `FF_*`, placed at the
   spec'd deck coordinates, `Turret` fields retuned, and every VLS launcher gets a
   **generated full-count cell grid** (launch transforms at -90 deg X so cells point up -
   the game-native convention, matching ANE's RAM45Launcher cell layout).
5. Hangar: `Hangar` (spawn transform, vanilla aircraft list), `Airbase` (vertical landing
   point on the flight deck, capture settings), `Rearmer` access point.
6. Ammo racks on VLS/UKSK sections: fragile `UnitPart` boxes = cook-off risk.
7. Wake particles / engine + water audio cloned from game assets when found.
8. `ShipDefinition` asset with dims, icons, identities - all fields verified against the
   live ANE 1.0.4 bundle layout.

## 5. Build the .nobp

**Blueprinter > Mod Builder** -> select `FlashpointFleets2035` -> Display name
"Flashpoint Fleets 2035" -> version `0.9.0` -> output folder outside Assets ->
**Build Mod**. You get `FlashpointFleets2035_0.9.0.nobp` (or similar).

## 6. Deploy

Copy into `<game>\BepInEx\plugins\FlashpointFleets\`:

```
FlashpointFleets2035.dll      (dist)
TorpedoShield.dll             (dist)
FlashpointFleets2035.nobp     (Mod Builder output)
```

Requires: BepInEx 5, Blueprinter 2.1.x in plugins. Recommended companions:
SonPamungkas' Torpedo mod (real swimming torpedoes for Mk54/Yu-8 + Mako threat),
GOTH MOMMY (radar/OTH overhaul - TorpedoShield composes with it), Aryx Naval Expansion
(both packs coexist; TorpedoShield defends ANE ships too).

## Troubleshooting

| Symptom | Fix |
|---|---|
| `model not found at .../Type055/OBJ/Type055.obj` | Models folder wasn't copied into `Assets/Blueprinter/Mods/FlashpointFleets2035/` (step 2) |
| Ship builds but launchers = 0 | Donor names - run FF > Dump Game Assets, fix `donorPrefab` in FF_ShipSpec.cs |
| Noisemakers missing on ships | Main DLL wasn't in `Assets/Plugins` during step 4 - rebuild ships after copying it |
| Ships pink/magenta | URP conversion skipped - select the model, reimport; FF_ImportPostprocessor fixes materials on import |
| `shipType` wrong in encyclopedia | Check vanilla warship values in the dump report; edit `FFShipSpec.shipType` |
| Torpedoes ignore ships / Mk54 doesn't swim | Install SonPamungkas' Torpedo mod - Flashpoint degrades to standoff ASW without it |

## Re-preparing models (optional)

`tools/prep_ships.py` is the full reproducible pipeline (Python 3.10+, trimesh, numpy,
Pillow). It re-assembles the GLBs (instancing-aware), orients them (+Z bow / +Y up /
waterline origin), scales to real LOA, splits damage sections and exports the OBJ/MTL/
texture sets plus manifests. You normally never need to run it - the outputs are shipped.
