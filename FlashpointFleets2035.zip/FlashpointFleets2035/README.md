# Flashpoint Fleets 2035

A four-ship nuclear navy pack for **Nuclear Option** (game 0.34.x, Unity 2022.3.62), built on
the same architecture as Aryx Naval Expansion and BOTE:

| Ship | Navy | LOA | Cells / weapons |
|---|---|---|---|
| **Renhai-class Cruiser (Type 055)** | PLAN | 180 m | 112-cell universal VLS (HHQ-9B + YJ-18A), HHQ-10, 2x 1130 CIWS, 130 mm, Yu-8 ASW, 2-helo hangar |
| **Jiangkai II Frigate (Type 054A)** | PLAN | 134 m | 32-cell VLS (HHQ-16FE), 8x YJ-83K, 2x 730 CIWS, 76 mm, Yu-8 ASW, 1-helo hangar |
| **Admiral Nakhimov (2035 refit)** | RF | 252 m | 48x S-400 48N6DM, 48x UKSK (Oniks + Kalibr), 32x Redut 9M96E2, 4x Kashtan-M, 2x 130 mm, Yu-8/RBU ASW, 2-helo hangar |
| **USS Hawaii (CSGN 2030 refit)** | USA | 240 m | 64 + 32 Mk41 cells (SM-6 / ESSM / SM-2 / Mk54 VLA), 2x railgun, 2x RAM, 2x CIWS, 2-helo hangar |

Every ship is a fully functional ANE-class unit: **ShipAI + FireControl**, sectioned damage
model (8-10 detachable `ShipPart` bands with progressive flooding, ammo-rack cook-off,
critical-part logic), **functional hangars** (`Hangar` + `Airbase` + `Rearmer` + vertical
landing point), omni radar + bridge lookout, wake FX and engine audio, and **full-count
VLS cell grids** using the game's native multi-cell `MissileLauncher`.

Two DLLs are included:

* **`FlashpointFleets2035`** - the main mod: builds the HHQ / YJ / S-400 / Kalibr / SM
  catalog at runtime (cloned from vanilla missiles, torpedo-mod style, multiplayer-safe),
  wires it onto the ship launchers, gives anti-ship missiles sea-skim terminal profiles,
  and carries the noisemaker racks.
* **`TorpedoShield`** - the companion AI/radar DLL (GOTH MOMMY compatible): sonar-style
  torpedo detection for **all** ships (vanilla, ANE, Flashpoint), ASW interceptor
  prioritization, CIWS vs. surfaced torpedoes, noisemaker seduction and torpedo-evasion
  steering. Pure postfix Harmony - composes with GOTH in any load order.

## What's in this package

```
FlashpointFleets2035/
├── README.md, docs/                    <- start with docs/BUILD.md
├── UnityProject/Assets/
│   ├── Blueprinter/Mods/FlashpointFleets2035/   <- drop into your Blueprinter Editor project
│   │   ├── ModInfo.json
│   │   └── Models/<Ship>/OBJ/...                 <- prepared, canonical, textured
│   └── FlashpointFleets/Editor/                 <- FF menu: one-click ship builder
├── Plugin/                             <- main DLL source + csproj
├── TorpedoShield/                      <- companion DLL source + csproj
├── build.ps1                           <- builds both DLLs against your game folder
└── tools/                              <- the Python prep pipeline (reproducible)
```

## Quick start (you have the toolchain ready)

```powershell
# 1. build both DLLs against your game install
powershell -ExecutionPolicy Bypass -File build.ps1 `
    -UnityPlugins "<BlueprinterEditorProject>\Assets\Plugins"

# 2. copy UnityProject/Assets/* into your Blueprinter Editor project
#    (merge Assets/Blueprinter/Mods/FlashpointFleets2035 + Assets/FlashpointFleets)

# 3. in Unity:  FF > Dump Game Assets  (check donor names once)
#               FF > Build All Ships
#               Blueprinter > Mod Builder > FlashpointFleets2035 > Build Mod

# 4. deploy: FlashpointFleets2035.nobp + FlashpointFleets2035.dll + TorpedoShield.dll
#    into  <game>\BepInEx\plugins\
```

Full details: **[docs/BUILD.md](docs/BUILD.md)** - players: **[docs/INSTALL.md](docs/INSTALL.md)** -
ship specs: **[docs/SHIPS.md](docs/SHIPS.md)** - weapon stats: **[docs/WEAPONS.md](docs/WEAPONS.md)** -
mod interop: **[docs/COMPATIBILITY.md](docs/COMPATIBILITY.md)**.

## Credits & basis

* Architecture modeled on **Aryx Naval Expansion** (Aryx3D), **BOTE** (MinecrackTyler) and
  **Blueprinter** (Nikkorap) - ship recipe extracted from their published bundles.
* Weapon-variant cloning technique from **SonPamungkas' Torpedo mod** (MIT).
* Companion DLL designed to compose with **GOTH MOMMY** (SonPamungkas).
* Ship models as provided (Type 055 - Sketchfab; Type 054A - CGTrader; Nakhimov 2035 &
  USS Hawaii CSNG 2030 - user-supplied). All re-oriented to the game's canonical ship
  space (+Z bow, +Y up, origin at waterline, meters) and split into damage sections.
