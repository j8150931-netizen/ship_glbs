#!/usr/bin/env python3
"""Correctly assemble glTF scenes (handling instancing) and analyze ship structure."""
import trimesh, numpy as np, json, sys, collections

def collect(scene):
    """Yield (node_name, geometry_name, vertices_world, faces) handling instancing properly."""
    graph = scene.graph
    items = []
    for node in graph.nodes_geometry:
        try:
            T, gname = graph.get(node)
            geom = scene.geometry[gname]
            if geom is None or not hasattr(geom, 'vertices') or len(geom.vertices) == 0:
                continue
            v = trimesh.transform_points(np.asarray(geom.vertices), T)
            f = np.asarray(geom.faces)
            items.append((node, gname, v, f))
        except Exception as e:
            print(f"  [warn] node {node}: {e}")
    return items

def analyze(path, name):
    print(f"\n{'='*70}\n{name}\n{'='*70}")
    scene = trimesh.load(path, force='scene', process=False)
    items = collect(scene)
    print(f"nodes with geometry: {len(items)}")
    V = np.vstack([v for _,_,v,_ in items])
    lo, hi = V.min(0), V.max(0)
    ext = hi - lo
    print(f"assembled bounds lo={np.round(lo,2)} hi={np.round(hi,2)} extents={np.round(ext,2)}")
    # per-part dump with world coords
    rows = []
    for node, gname, v, f in items:
        plo, phi = v.min(0), v.max(0)
        rows.append(dict(node=node, geom=gname, faces=len(f),
                         lo=np.round(plo,2).tolist(), hi=np.round(phi,2).tolist(),
                         ext=np.round(phi-plo,2).tolist(), centroid=np.round((plo+phi)/2,2).tolist()))
    # biggest parts
    rows.sort(key=lambda r: -max(r['ext']))
    for r in rows[:15]:
        print(f"  {r['node'][:48]:50s} f={r['faces']:6d} ext={r['ext']} lo={r['lo']}")
    return items, lo, hi, ext, rows

if __name__ == '__main__':
    analyze('type055/source/type-055.glb', 'Type 055')
    analyze('frigate054a/frigate.glb', 'Type 054A')
    analyze('/home/z/my-project/upload/admiral_nakhimov_2035.glb', 'Admiral Nakhimov 2035')
    analyze('/home/z/my-project/upload/uss_hawaii_csng_2030_refit.glb', 'USS Hawaii CSNG 2030')
