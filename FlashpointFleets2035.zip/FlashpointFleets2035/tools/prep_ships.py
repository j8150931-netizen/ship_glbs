#!/usr/bin/env python3
"""
Flashpoint Fleets 2035 - ship model preparation pipeline.

Takes the 4 uploaded ship models, and for each:
  1. Assembles the glTF scene correctly (instancing-aware).
  2. Drops junk geometry (loose entities far from hull).
  3. Detects / applies canonical orientation: +Z = bow, +Y = up, origin = waterline center.
  4. Scales to real-world meters.
  5. Splits into damage sections (bow..stern bands).
  6. Exports <ship>.obj (custom exporter: one 'o' object per (section, material) -> Unity child GOs),
     <ship>.mtl, extracted PNG textures, plus the original .glb as an alternate import route.
  7. Writes manifest.json with hull envelope data for the Unity prefab builder.
"""
import trimesh, numpy as np, json, os, shutil, math, sys, re
from PIL import Image

def sanitize(name):
    s = re.sub(r'[^A-Za-z0-9_.-]', '_', str(name)).strip('_') or 'Mat'
    return s[:48]

SRC = {
    "Type055":   dict(path="C:/Users/admin/Downloads/ff_prep_src/type055/type-055.glb"),
    "Type054A":  dict(path="C:/Users/admin/Downloads/ff_prep_src/frigate054a/frigate.glb"),
    "Nakhimov":  dict(path="C:/Users/admin/Downloads/admiral_nakhimov_2035.glb"),
    "Hawaii":    dict(path="C:/Users/admin/Downloads/uss_hawaii_csng_2030_refit.glb"),
}

CFG = {
    # up: axis index acting as 'up' in source (before transform), fwd: axis index of length,
    # fwd_sign_override: None => auto-detect bow (transom test), else +1/-1 applied to fwd axis
    # length/height/beam target in meters, draft in meters (waterline), sections count, waterline_hint:
    #   'model_zero' = waterline already at coordinate 0 of the up axis
    "Type055":  dict(up=1, fwd=2, fwd_sign=None, loa=180.0, beam=20.0, draft=6.6,  sections=9,  waterline='model_zero', ext=".y_up_z_fwd"),
    "Type054A": dict(up=1, fwd=2, fwd_sign=None, loa=134.0, beam=16.0, draft=4.3, sections=8, waterline='model_zero'),
    "Nakhimov": dict(up=1, fwd=0, fwd_sign=None, loa=252.0, beam=28.5, draft=7.6, sections=10, waterline='keel_draft'),
    "Hawaii":   dict(up=1, fwd=0, fwd_sign=None, loa=240.0, beam=24.0, draft=9.5, sections=10, waterline='keel_draft'),
}

SECTION_NAMES = ["Bow", "ForeVLS", "Bridge", "Midships", "AftVLS", "Hangar", "Stern"]

OUT = "C:/Users/admin/Downloads/ff_prep_out"

# ----------------------------------------------------------------------------
def collect(scene):
    """Instancing-aware assembly: [(node, geom, world_verts, faces, uvs, material)]"""
    items = []
    for node in scene.graph.nodes_geometry:
        try:
            T, gname = scene.graph.get(node)
            geom = scene.geometry[gname]
            if geom is None or not hasattr(geom, 'vertices') or len(geom.vertices) == 0:
                continue
            v = trimesh.transform_points(np.asarray(geom.vertices, dtype=np.float64), T)
            f = np.asarray(geom.faces, dtype=np.int64)
            uv = None
            if (getattr(geom.visual, 'uv', None) is not None and len(geom.visual.uv) == len(geom.vertices)):
                uv = np.asarray(geom.visual.uv, dtype=np.float64)
            mat = getattr(geom.visual, 'material', None) if geom.visual is not None else None
            items.append(dict(node=node, verts=v, faces=f, uv=uv, mat=mat))
        except Exception as e:
            print(f"    [warn] {node}: {e}")
    return items

def material_info(mat):
    """Return (name, basecolor_rgb, texture_PIL_or_None)."""
    if mat is None:
        return ("Default", (0.65, 0.65, 0.68), None)
    name = str(getattr(mat, 'name', None) or 'Material')[:40]
    col = getattr(mat, 'baseColorFactor', None)
    if col is not None:
        try:
            col = (float(col[0]), float(col[1]), float(col[2]))
        except Exception:
            col = None
    if col is None:
        col = (0.65, 0.65, 0.68)
    # clamp visual brightness into sane range
    col = tuple(max(0.0, min(1.0, c)) for c in col)
    tex = getattr(mat, 'baseColorTexture', None)
    if tex is not None:
        try:
            tex = Image.fromarray(np.asarray(tex)) if not isinstance(tex, Image.Image) else tex
        except Exception:
            tex = None
    return (name, col, tex)

# ----------------------------------------------------------------------------
def detect_bow(verts, fwd_axis):
    """Return +1 if bow is at max(fwd), -1 if at min. Transom = dense flat plate at extreme;
    raked bow = sparse wedge. We compare vertex density in the outer 3% bands, weighted by
    flatness (count of vertices sharing nearly the same fwd coordinate)."""
    lo, hi = verts.min(0), verts.max(0)
    L = hi[fwd_axis] - lo[fwd_axis]
    band = max(L * 0.02, 1e-6)
    def end_score(sign):
        edge = hi[fwd_axis] if sign > 0 else lo[fwd_axis]
        sel = np.abs(verts[:, fwd_axis] - edge) < band
        if sel.sum() < 4:
            return -1.0
        E = verts[sel]
        # flatness: how many verts sit within 0.2% of the extreme plane
        inner = 0.002 * L
        on_plane = (np.abs(E[:, fwd_axis] - edge) < inner).sum()
        # span across remaining axes (transom is wide & tall, bow narrow)
        others = [a for a in range(3) if a != fwd_axis]
        span = 1.0
        for a in others:
            span *= (E[:, a].max() - E[:, a].min())
        return (on_plane / max(sel.sum(), 1)) * span
    sp, sm = end_score(+1), end_score(-1)
    # the transom (stern) has the HIGHER score => bow is the other end
    return -1 if sp >= sm else +1

def up_axis_auto(verts, cfg):
    """If up not forced: choose axis where the hull's vertical center is lowest vs mast."""
    return cfg.get('up')

# ----------------------------------------------------------------------------
def prep_ship(key, cfg):
    print(f"\n{'='*74}\n{key}\n{'='*74}")
    src = SRC[key]['path']
    scene = trimesh.load(src, force='scene', process=False)
    items = collect(scene)
    print(f"assembled {len(items)} geometry nodes")

    up = cfg['up']; up_sign = cfg.get('up_sign', +1)
    fwd = cfg['fwd']

    # merge all verts for orientation analysis
    allV = np.vstack([it['verts'] for it in items])

    # junk drop: parts with centroid farther than 55% of LOA from the global centroid
    centroid = (allV.min(0) + allV.max(0)) / 2
    span = allV.max(0) - allV.min(0)
    ref = span.max()
    kept = []
    for it in items:
        c = (it['verts'].min(0) + it['verts'].max(0)) / 2
        d = np.linalg.norm((c - centroid) / ref)
        size = (it['verts'].max(0) - it['verts'].min(0)).max()
        if d > 0.6 or size > 1.05 * ref or len(it['faces']) == 0:
            print(f"    drop junk: {it['node'][:46]:48s} d={d:.2f} size={size:.1f}")
            continue
        kept.append(it)
    items = kept
    allV = np.vstack([it['verts'] for it in items])

    fwd_sign = cfg.get('fwd_sign') or detect_bow(allV, fwd)
    print(f"forward axis={fwd} sign={fwd_sign:+d} (auto={'yes' if not cfg.get('fwd_sign') else 'no'})")

    # Build canonical basis: new_z = bow, new_y = up, new_x = starboard (right-handed)
    fwd_vec = np.zeros(3); fwd_vec[fwd] = fwd_sign
    up_vec = np.zeros(3); up_vec[up] = up_sign
    right_vec = np.cross(fwd_vec, up_vec)   # for RH: x = y cross z... we want z=fwd,y=up => x = up x fwd? check below
    # We need R with columns (new_x, new_y, new_z) expressed in old coords, s.t.
    # v_new = R^T v_old, R = [x_new, y_new, z_new].
    # right-handed: x = cross(y, z)
    right_vec = np.cross(up_vec, fwd_vec)
    assert abs(np.linalg.det(np.stack([right_vec, up_vec, fwd_vec], axis=1)) - 1.0) < 1e-8, "basis not RH"

    def to_canonical(v):
        # v_new = [v . right, v . up, v . fwd]
        return np.stack([v @ right_vec, v @ up_vec, v @ fwd_vec], axis=-1)

    # transform all geometry
    for it in items:
        it['cverts'] = to_canonical(it['verts'])

    allC = np.vstack([it['cverts'] for it in items])
    lo, hi = allC.min(0), allC.max(0)
    length = hi[2] - lo[2]
    scale = cfg['loa'] / length
    print(f"canonical: length={length:.2f} -> scale x{scale:.4f} (LOA {cfg['loa']}m), "
          f"beam={hi[0]-lo[0]:.2f}->{(hi[0]-lo[0])*scale:.1f}m, height={hi[1]-lo[1]:.2f}->{(hi[1]-lo[1])*scale:.1f}m")

    # waterline placement: keel at -draft, origin centered (bow +Z max, stern -Z min)
    draft = cfg['draft']
    zc = (hi[2] + lo[2]) / 2
    if cfg['waterline'] == 'model_zero':
        # model's waterline sits at canonical y = lo[1] if the model starts at keel y0==waterline0?
        # heuristic used here: source 'up' origin already = waterline
        dy = -lo[1] * 0  # keep 0: waterline at source up==0
        wl_y = 0.0
        offset = np.array([-(hi[0]+lo[0])/2, wl_y, -zc])
    else:  # keel_draft: waterline = keel + draft
        keel_y = lo[1]
        offset = np.array([-(hi[0]+lo[0])/2, -keel_y - draft/scale, -zc])
    # note: for model_zero ships, if keel (min y) is not negative, we shift keel to -draft
    if cfg['waterline'] == 'model_zero':
        if lo[1] > -(0.15 * (hi[1]-lo[1])):   # keel not deep enough -> treat as keel at 0
            offset[1] = -lo[1] - draft/scale

    def finalize(v):
        return (v + offset) * scale

    for it in items:
        it['fverts'] = finalize(it['cverts'])

    allF = np.vstack([it['fverts'] for it in items])
    flo, fhi = allF.min(0), allF.max(0)
    print(f"final: x=({flo[0]:.1f},{fhi[0]:.1f}) y=({flo[1]:.1f},{fhi[1]:.1f}) z=({flo[2]:.1f},{fhi[2]:.1f})  "
          f"(keel should be ~-{cfg['draft']}, bow at z=+{cfg['loa']/2:.0f})")

    # ---------------- section split ----------------
    n = cfg['sections']
    zmin, zmax = flo[2], fhi[2]
    bounds = np.linspace(zmin, zmax, n + 1)
    def section_idx(z):
        i = int(np.clip(np.digitize(z, bounds[1:-1], right=False), 0, n - 1))
        return i

    # material registry (dedup sanitized names)
    mats = {}       # sanitized mname -> dict(color, tex)
    name_map = {}   # original name -> sanitized unique name
    texfiles = {}   # id(mat obj)-> filename
    sections = [[] for _ in range(n)]

    for it in items:
        mname_orig, color, tex = material_info(it['mat'])
        if tex is not None:
            tf = f"{key}_{sanitize(mname_orig)}.png"
            texfiles[id(it['mat'])] = tf
        if mname_orig not in name_map:
            base = sanitize(mname_orig)
            uniq, k = base, 1
            while uniq in mats:
                uniq = f"{base}_{k}"; k += 1
            name_map[mname_orig] = uniq
            mats[uniq] = dict(color=color, tex=tf if tex is not None else None)
        it['matname'] = name_map[mname_orig]
        F = it['faces']
        V = it['fverts']
        tri_z = V[F, 2].mean(axis=1)
        # split faces by centroid band
        for i in range(n):
            m = (tri_z >= bounds[i]) & (tri_z <= bounds[i+1] if i == n-1 else tri_z < bounds[i+1])
            if not m.any():
                continue
            sections[i].append(dict(face_idx=np.where(m)[0], item=it, mat=it['matname']))

    # verify bow taper for sanity: beam at bow band should be << midship
    boww = fhi[0]-flo[0]
    print(f"sections populated: {[len(s) for s in sections]}")

    # ---------------- export OBJ ----------------
    shipdir = os.path.join(OUT, key)
    os.makedirs(shipdir, exist_ok=True)
    objdir = os.path.join(shipdir, "OBJ")
    texdir = os.path.join(objdir, "textures")
    os.makedirs(texdir, exist_ok=True)

    # save textures
    for it in items:
        _, _, tex = material_info(it['mat'])
        if tex is not None:
            tf = texfiles.get(id(it['mat']))
            if tf and not os.path.exists(os.path.join(texdir, tf)):
                tex.save(os.path.join(texdir, tf), "PNG")
    # color-only ships get nothing (MTL Kd colors)

    obj_path = os.path.join(objdir, f"{key}.obj")
    mtl_path = os.path.join(objdir, f"{key}.mtl")
    with open(obj_path, "w") as obj, open(mtl_path, "w") as mtl:
        obj.write(f"# Flashpoint Fleets 2035 - {key}\n")
        obj.write(f"# canonical: +Z bow, +Y up, origin waterline center, meters\n")
        obj.write(f"mtllib {key}.mtl\n")
        mtl.write(f"# {key} materials\n")
        # write materials (already sanitized + deduped keys)
        for mname, m in mats.items():
            safe = mname
            r, g, b = m['color']
            mtl.write(f"\nnewmtl {safe}\nKd {r:.4f} {g:.4f} {b:.4f}\nKa 0 0 0\nKs 0.08 0.08 0.08\nNs 32\n")
            if m['tex']:
                mtl.write(f"map_Kd textures/{m['tex']}\n")
        v_off = 1  # OBJ 1-based global indices
        total_v = 0
        for si in range(n):
            sname = f"Section{si:02d}"
            # group entries by material
            bymat = {}
            for grp in sections[si]:
                bymat.setdefault(grp['mat'], []).append(grp)
            for mname, grps in bymat.items():
                safe = mname
                oname = f"{sname}__{safe}"
                # gather needed verts: union of faces across grps (they may come from different items!)
                # -> emit verts per item with local remap
                obj.write(f"\no {oname}\ng {oname}\nusemtl {safe}\n")
                for grp in grps:
                    it = grp['item']; faces = it['faces'][grp['face_idx']]
                    Vv = it['fverts']; UV = it['uv']
                    idx = np.unique(faces.reshape(-1))
                    remap = {int(old): i for i, old in enumerate(idx)}
                    for old in idx:
                        p = Vv[old]
                        obj.write(f"v {p[0]:.4f} {p[1]:.4f} {p[2]:.4f}\n")
                    if UV is not None and len(UV) == len(Vv):
                        for old in idx:
                            t = UV[old]
                            obj.write(f"vt {t[0]:.5f} {t[1]:.5f}\n")
                    else:
                        for old in idx:
                            obj.write("vt 0 0\n")
                    for f in faces:
                        a, b, c = (remap[int(x)] + v_off for x in f)
                        obj.write(f"f {a}/{a} {b}/{b} {c}/{c}\n")
                    v_off += len(idx)
                    total_v += len(idx)
    print(f"OBJ written: {obj_path} ({total_v} verts exported)")

    # copy original glb alongside (glTFast alternate route)
    glb_dst = os.path.join(shipdir, f"{key}_original.glb")
    shutil.copy(src, glb_dst)

    # ---------------- manifest ----------------
    section_meta = []
    for si in range(n):
        Vs = []
        for grp in sections[si]:
            it = grp['item']
            Vs.append(it['fverts'][it['faces'][grp['face_idx']].reshape(-1)])
        if Vs:
            Vs = np.vstack(Vs)
            slo, shi = Vs.min(0), Vs.max(0)
            section_meta.append(dict(name=f"Section{si:02d}",
                                     z0=round(float(slo[2]), 2), z1=round(float(shi[2]), 2),
                                     x0=round(float(slo[0]), 2), x1=round(float(shi[0]), 2),
                                     y0=round(float(slo[1]), 2), y1=round(float(shi[1]), 2),
                                     triangles=int(sum(len(g['face_idx']) for g in sections[si]))))
        else:
            section_meta.append(dict(name=f"Section{si:02d}", triangles=0))

    manifest = dict(
        key=key, loa=cfg['loa'], beam=round(float(fhi[0]-flo[0]), 2),
        height=round(float(fhi[1]-flo[1]), 2), draft=cfg['draft'],
        keel=round(float(flo[1]), 2), mastTop=round(float(fhi[1]), 2),
        bowZ=round(float(fhi[2]), 2), sternZ=round(float(flo[2]), 2),
        sections=section_meta,
        materials={m: dict(color=[round(c,3) for c in v['color']], texture=v['tex']) for m, v in mats.items()},
        convention="+Z bow, +Y up, origin at waterline center, 1 unit = 1 meter",
        exported=[f"OBJ/{key}.obj", f"OBJ/{key}.mtl", "OBJ/textures/", f"{key}_original.glb"],
    )
    with open(os.path.join(shipdir, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"manifest: {len(section_meta)} sections, {len(mats)} materials -> {shipdir}/manifest.json")
    return manifest

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    allm = {}
    for key, cfg in CFG.items():
        try:
            allm[key] = prep_ship(key, cfg)
        except Exception as e:
            import traceback; traceback.print_exc()
            print(f"!! {key} FAILED: {e}")
    with open(os.path.join(OUT, "manifest_all.json"), "w") as f:
        json.dump(allm, f, indent=2)
    print("\nALL DONE ->", OUT)
