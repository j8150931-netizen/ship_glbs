// ============================================================================
// Flashpoint Fleets 2035 - FF_PrefabFactory.cs
// Assembles a complete, functional Nuclear Option warship from an FFShipSpec:
//
//   Ship root   : Ship, ShipPart, Rigidbody, UnitCommand, ShipNetworkTransform,
//                 NetworkIdentity, SetGlobalParticles, ShipAI, FireControl,
//                 Capture, Airbase, Rearmer
//   Sections    : ShipPart + MeshCollider damage bands with progressive
//                 flooding (displacement/leak/sink), ammo-rack UnitParts
//   Sensors     : Radar (mast) + TargetDetector (bridge Lookout)
//   Propulsion  : ShipPropulsion on the stern section with Forcepoint
//   Weapons     : donor launcher/CIWS/gun prefabs cloned + renamed FF_*,
//                 full-count VLS launch-transform grids (game-native cells)
//   Hangar      : Hangar + spawn transform + vertical landing point +
//                 Airbase wiring + Rearmer access point
//   FX          : wake particles / water sounds / engine audio from game
//                 assets where available
//   Definition  : ShipDefinition ScriptableObject asset under the mod folder
//
// References to game classes resolve because the Blueprinter Editor project
// imports the game's assemblies; private serialized fields are set through
// SerializedObject exactly the way the game serializes them.
// ============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Mirage;
using NuclearOption.NetworkTransforms;

namespace FlashpointFleets.EditorTools
{
    public static class FF_PrefabFactory
    {
        static readonly List<string> Log = new List<string>();
        static void Say(string s) { Log.Add(s); Debug.Log("[FF] " + s); }
        static void Warn(string s) { Log.Add("[FF][WARN] " + s); Debug.LogWarning("[FF] " + s); }

        // ==================================================================
        // MAIN ENTRY
        // ==================================================================
        public static GameObject Build(FFShipSpec spec)
        {
            Log.Clear();
            Say($"Building {spec.unitName} ({spec.id}) ...");

            var root = new GameObject("FF_" + spec.id + "_Ship");
            try
            {
                BuildRoot(root, spec);
                var modelRoot = AttachModelSections(root, spec);
                var sections = BuildSectionParts(root, spec, modelRoot);
                BuildSensors(root, spec, sections);
                BuildPropulsion(root, spec, sections);
                var fireControl = BuildFireControl(root);
                var radar = BuildWeapons(root, spec, sections, fireControl);
                if (!SKIP_HANGAR) BuildHangar(root, spec, sections);
                BuildAmmoRacks(root, spec, sections);
                BuildWakeAndAudio(root, spec);
                AttachModScripts(root, spec);
                var definition = BuildDefinition(spec, root);
                {
                    var shipUnit = root.GetComponent<Ship>();
                    var dso = new SerializedObject(shipUnit);
                    var dp = dso.FindProperty("definition");
                    if (dp != null) { dp.objectReferenceValue = definition; dso.ApplyModifiedProperties(); }
                    else Warn("Ship has no serialized 'definition' property");
                }

                // save prefab + definition under the mod folder
                var prefabFolder = FF_ShipSpec.ModRoot + "/Prefabs";
                EnsureFolder(prefabFolder);
                var prefabPath = prefabFolder + "/FF_" + spec.id + ".prefab";
                var saved = PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
                AssetDatabase.SaveAssets();

                // wire definition -> prefab (must be saved asset for the reference to stick)
                var so = new SerializedObject(definition);
                so.FindProperty("unitPrefab").objectReferenceValue = saved;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(definition);
                AssetDatabase.SaveAssets();

                Say($"Saved {prefabPath} and definition {definition.name}.");
                var report = FF_ShipSpec.ModRoot + "/BuildReports";
                EnsureFolder(report);
                FileWrite(report + "/FF_" + spec.id + "_build.txt",
                    "Flashpoint Fleets build report - " + spec.unitName + "\n" +
                    DateTime.Now + "\n\n" + string.Join("\n", Log));
                return saved;
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
            }
        }

        static void FileWrite(string path, string content)
        {
            try { System.IO.File.WriteAllText(path, content); }
            catch (Exception e) { Warn("report write failed: " + e.Message); }
        }

        static void EnsureFolder(string folder)
        {
            var parts = folder.Split('/');
            var cur = "Assets";
            for (int i = 1; i < parts.Length; i++)
            {
                var next = cur + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(cur, parts[i]);
                cur = next;
            }
        }

        // ==================================================================
        // ROOT
        // ==================================================================
        static void BuildRoot(GameObject root, FFShipSpec spec)
        {
            root.AddComponent<Ship>();
            var rootRb = root.AddComponent<Rigidbody>();
            rootRb.isKinematic = true; // non-convex hull colliders are invalid on a dynamic Rigidbody
            root.AddComponent<UnitCommand>();
            root.AddComponent<ShipNetworkTransform>();
            root.AddComponent<NetworkIdentity>();
            AddIfExists(root, "SetGlobalParticles");
            root.AddComponent<ShipAI>();
            root.AddComponent<FireControl>();
            root.AddComponent<Capture>();
            root.AddComponent<Airbase>();
            root.AddComponent<Rearmer>();

            // transform anchors
            Anchor(root, "keel", 0, -8f, 0); // keel marker (ShipAI grounding reference)
            var rb = root.GetComponent<Rigidbody>();
            rb.mass = TotalMass(spec);
            rb.drag = 0.2f; rb.angularDrag = 0.8f;
            rb.interpolation = RigidbodyInterpolation.Interpolate;

            var ship = root.GetComponent<Ship>();
            var shipSo = new SerializedObject(ship);
            SetProp(shipSo, "criticalRatio", 0.5f);
            var cp = shipSo.FindProperty("criticalParts");
            if (cp != null && cp.isArray) cp.arraySize = 0; // sections register below
            shipSo.ApplyModifiedProperties();
        }

        static float TotalMass(FFShipSpec spec) =>
            spec.sections.Sum(s => s.massTons) * 1000f * 0.4f; // game-tuned factor

        static Transform Anchor(GameObject parent, string name, float x, float y, float z)
        {
            var t = new GameObject(name).transform;
            t.SetParent(parent.transform, false);
            t.localPosition = new Vector3(x, y, z);
            return t;
        }

        // ==================================================================
        // MODEL + SECTION PARTS
        // ==================================================================
        static GameObject AttachModelSections(GameObject root, FFShipSpec spec)
        {
            var model = AssetDatabase.LoadAssetAtPath<GameObject>(spec.modelPath);
            if (model == null)
                throw new Exception("Model not found at " + spec.modelPath +
                    " - copy the prepared Models/ folder into the mod folder first (see docs/BUILD.md).");
            var inst = (GameObject)PrefabUtility.InstantiatePrefab(model);
            if (inst == null) inst = UnityEngine.Object.Instantiate(model);
            PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
            inst.name = "Hull";
            inst.transform.SetParent(root.transform, false);
            Say("model instantiated: " + spec.modelPath + " (" + inst.transform.childCount + " top children)");
            return inst;
        }

        static Dictionary<string, ShipPart> BuildSectionParts(GameObject root, FFShipSpec spec, GameObject modelRoot)
        {
            var map = new Dictionary<string, ShipPart>();
            var ship = root.GetComponent<Ship>();
            var criticalList = new List<ShipPart>();

            foreach (var s in spec.sections)
            {
                var go = new GameObject("FF_" + spec.id + "_" + s.label);
                go.transform.SetParent(root.transform, false);

                // move matching model children under the section
                var prefix = $"Section{s.modelSection:00}__";
                int moved = 0;
                foreach (Transform child in modelRoot.transform.Cast<Transform>().ToList())
                {
                    if (child.name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                    {
                        child.SetParent(go.transform, true); // keep world (canonical) placement
                        moved++;
                    }
                }
                if (moved == 0) Warn($"section {s.label}: no model group '{prefix}*' found");

                var part = go.AddComponent<ShipPart>();
                Set(part, "mass", s.massTons * 1000f);
                Set(part, "hitPoints", s.hitPoints);
                Set(part, "displacement", s.displacement);
                Set(part, "height", s.height);
                Set(part, "leakThreshold", s.leakThreshold);
                Set(part, "leakRateMin", s.leakRateMin);
                Set(part, "leakRateMax", s.leakRateMax);
                Set(part, "sinkThreshold", s.sinkThreshold);
                Set(part, "breakJointStrength", s.breakJointStrength);
                {
                    var apo = new SerializedObject(part);
                    var a = apo.FindProperty("armorProperties");
                    if (a != null)
                    {
                        a.FindPropertyRelative("pierceArmor").floatValue = s.pierceArmor;
                        a.FindPropertyRelative("blastArmor").floatValue = s.blastArmor;
                        a.FindPropertyRelative("fireArmor").floatValue = s.fireArmor;
                    }
                    apo.FindProperty("parentUnit").objectReferenceValue = ship;
                    apo.ApplyModifiedProperties();
                }

                if (s.critical) criticalList.Add(part);
                map[s.label] = part;

                // ShipPart.Awake calls GetComponent<Collider>() on its OWN GameObject, so each section part
                // needs a collider right here: one box fitted to the section's renderers.
                {
                    var rends = go.GetComponentsInChildren<Renderer>(true);
                    var bc = go.AddComponent<BoxCollider>();
                    if (rends.Length > 0)
                    {
                        var wb = rends[0].bounds;
                        foreach (var r in rends) wb.Encapsulate(r.bounds);
                        bc.center = go.transform.InverseTransformPoint(wb.center);
                        var ls = go.transform.InverseTransformVector(wb.size);
                        bc.size = new Vector3(Mathf.Max(0.5f, Mathf.Abs(ls.x)), Mathf.Max(0.5f, Mathf.Abs(ls.y)), Mathf.Max(0.5f, Mathf.Abs(ls.z)));
                    }
                    else bc.size = Vector3.one;
                }
            }

            // Ship.criticalParts
            var so = new SerializedObject(ship);
            var cp = so.FindProperty("criticalParts");
            if (cp != null && cp.isArray)
            {
                cp.arraySize = criticalList.Count;
                for (int i = 0; i < criticalList.Count; i++)
                    cp.GetArrayElementAtIndex(i).objectReferenceValue = criticalList[i];
            }
            so.ApplyModifiedProperties();
            // ShipAI keel reference
            var ai = root.GetComponent<ShipAI>();
            var aso = new SerializedObject(ai);
            var keel = root.transform.Find("keel");
            if (keel != null) aso.FindProperty("keel").objectReferenceValue = keel;
            aso.ApplyModifiedProperties();
            return map;
        }

        // ==================================================================
        // SENSORS
        // ==================================================================
        static void BuildSensors(GameObject root, FFShipSpec spec, Dictionary<string, ShipPart> sections)
        {
            var ship = root.GetComponent<Ship>();

            // primary radar on its own mast part
            var mast = new GameObject("FF_" + spec.id + "_Radar");
            mast.transform.SetParent(root.transform, false);
            mast.transform.localPosition = new Vector3(0, spec.radarY, spec.radarZ);
            var radar = mast.AddComponent<Radar>();
            var scanner = Anchor(mast, "Scanner", 0, 1f, 0);
            var rso = new SerializedObject(radar);
            rso.FindProperty("scanner").objectReferenceValue = scanner;
            rso.FindProperty("attachedUnit").objectReferenceValue = ship;
            rso.FindProperty("checkInterval").floatValue = 3f;
            rso.FindProperty("alertCheckInterval").floatValue = 3f;
            rso.FindProperty("visualRange").floatValue = 8000f;
            rso.FindProperty("magnification").floatValue = 3f;
            rso.FindProperty("maxSpeed").floatValue = 3000f;
            rso.FindProperty("jamTolerance").floatValue = 0.7f;
            rso.FindProperty("radarCone").floatValue = 360f;
            var rp = rso.FindProperty("RadarParameters");
            if (rp != null)
            {
                rp.FindPropertyRelative("maxRange").floatValue = spec.radarMaxRange;
                rp.FindPropertyRelative("maxSignal").floatValue = 4f;
                rp.FindPropertyRelative("minSignal").floatValue = 0.5f;
                rp.FindPropertyRelative("clutterFactor").floatValue = 2f;
                rp.FindPropertyRelative("dopplerFactor").floatValue = 0.1f;
            }
            rso.ApplyModifiedProperties();

            // bridge lookout
            var bridge = new GameObject("FF_" + spec.id + "_Bridge");
            bridge.transform.SetParent(root.transform, false);
            bridge.transform.localPosition = new Vector3(0, spec.lookoutY, spec.lookoutZ);
            var det = bridge.AddComponent<TargetDetector>();
            var lookout = Anchor(bridge, "Lookout", 0, 1f, 0);
            var dso = new SerializedObject(det);
            dso.FindProperty("scanner").objectReferenceValue = lookout;
            dso.FindProperty("attachedUnit").objectReferenceValue = ship;
            dso.FindProperty("checkInterval").floatValue = 3f;
            dso.FindProperty("alertCheckInterval").floatValue = 3f;
            dso.FindProperty("visualRange").floatValue = 9000f;
            dso.FindProperty("magnification").floatValue = 2.5f;
            dso.FindProperty("maxSpeed").floatValue = 2500f;
            dso.ApplyModifiedProperties();

            // Ship.radar -> primary radar
            var so = new SerializedObject(ship);
            so.FindProperty("radar").objectReferenceValue = radar;
            var oso = new SerializedObject(ship);
            var ost = oso.FindProperty("obstacleTopTransform");
            if (ost != null) ost.objectReferenceValue = mast.transform;
            oso.ApplyModifiedProperties();
            so.ApplyModifiedProperties();
        }

        // ==================================================================
        // PROPULSION
        // ==================================================================
        static void BuildPropulsion(GameObject root, FFShipSpec spec, Dictionary<string, ShipPart> sections)
        {
            var sternLabel = spec.sections[spec.sections.Count - 1].label; // sections list is bow->stern
            ShipPart sternPart = null;
            // stern = the band furthest aft in canonical space; find by label containing "Stern" or "FlightDeck"
            sternPart = sections.Values.FirstOrDefault(p => p.name.Contains("Stern"))
                        ?? sections.Values.FirstOrDefault(p => p.name.Contains("FlightDeck"))
                        ?? sections.Values.Last();
            var host = sternPart != null ? sternPart.gameObject : root;
            var prop = host.AddComponent<ShipPropulsion>();
            var forceT = Anchor(host, "Forcepoint", 0, -1f, 0);
            var so = new SerializedObject(prop);
            so.FindProperty("thrust").floatValue = 2.4e7f * (spec.topSpeed / 30f);
            so.FindProperty("steeringThrust").floatValue = 1.6e7f * (spec.topSpeed / 30f);
            so.FindProperty("momentumFactor").floatValue = 0.05f;
            so.FindProperty("damageThreshold").floatValue = 30f;
            so.FindProperty("inputSmoothing").floatValue = 0.25f;
            so.FindProperty("underwater").boolValue = true;
            so.FindProperty("thrustTransform").objectReferenceValue = forceT;
            if (sternPart != null) so.FindProperty("part").objectReferenceValue = sternPart;
            so.ApplyModifiedProperties();
        }

        // ==================================================================
        // FIRE CONTROL
        // ==================================================================
        static FireControl BuildFireControl(GameObject root)
        {
            return root.GetComponent<FireControl>();
        }

        // ==================================================================
        // WEAPONS
        // ==================================================================
        static Radar BuildWeapons(GameObject root, FFShipSpec spec,
            Dictionary<string, ShipPart> sections, FireControl fc)
        {
            var ship = root.GetComponent<Ship>();
            var radar = root.GetComponentInChildren<Radar>(true);
            var lookout = root.GetComponentInChildren<TargetDetector>(true);
            var turrets = new List<Turret>();

            foreach (var w in spec.weapons)
            {
                GameObject donorGo = null;
                if (w.role == "GUN" || w.role == "CIWS" || w.role == "RAILGUN")
                    donorGo = FF_AssetResolver.FindGunDonor(w.donorPrefab, w.role == "CIWS");
                else
                    donorGo = FF_AssetResolver.FindLauncherDonor(w.donorPrefab, w.role);
                if (donorGo == null)
                {
                    Warn($"weapon {w.name}: no donor prefab found for '{w.donorPrefab}' ({w.role}) - skipped. " +
                         "Run FF/Dump Game Assets and update FF_ShipSpec donor names.");
                    continue;
                }

                var inst = (GameObject)PrefabUtility.InstantiatePrefab(donorGo);
                if (inst == null) inst = UnityEngine.Object.Instantiate(donorGo);
                PrefabUtility.UnpackPrefabInstance(inst, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                inst.name = w.name;
                inst.transform.SetParent(root.transform, false);
                inst.transform.localPosition = new Vector3(w.x, w.y, w.z);
                inst.transform.localRotation = Quaternion.Euler(0, w.yaw, 0);

                var turret = inst.GetComponentInChildren<Turret>(true);
                if (turret != null)
                {
                    turrets.Add(turret);
                    var tso = new SerializedObject(turret);
                    tso.FindProperty("attachedUnit").objectReferenceValue = ship;
                    tso.FindProperty("fireControl").objectReferenceValue = fc;
                    tso.FindProperty("traverseRate").floatValue = w.traverseRate;
                    tso.FindProperty("minElevation").floatValue = w.minElevation;
                    tso.FindProperty("maxElevation").floatValue = w.maxElevation;
                    tso.FindProperty("lockTime").floatValue = w.lockTime;
                    // detectors: our radar + lookout
                    var td = tso.FindProperty("targetDetectors");
                    if (td != null && td.isArray)
                    {
                        td.arraySize = (radar != null ? 1 : 0) + (lookout != null ? 1 : 0);
                        int i = 0;
                        if (radar != null) td.GetArrayElementAtIndex(i++).objectReferenceValue = radar;
                        if (lookout != null) td.GetArrayElementAtIndex(i++).objectReferenceValue = lookout;
                    }
                    tso.ApplyModifiedProperties();
                }
                else Warn($"weapon {w.name}: donor has no Turret component.");

                var launcher = inst.GetComponentInChildren<MissileLauncher>(true);
                if (launcher != null && (w.cellColumns * w.cellRows > 1 || w.role == "SAM" || w.role == "ASHM" || w.role == "ASW"))
                {
                    BuildLaunchCells(inst, launcher, w);
                    var lso = new SerializedObject(launcher);
                    lso.FindProperty("attachedUnit").objectReferenceValue = ship;
                    lso.FindProperty("ammo").intValue = w.ammo;
                    lso.FindProperty("fireInterval").floatValue = w.fireInterval;
                    lso.FindProperty("reloadTime").floatValue = w.reloadTime;
                    var ev = lso.FindProperty("ejectionVelocity");
                    if (ev != null) ev.vector3Value = new Vector3(0, 0, w.ejectionVelocityZ);
                    lso.ApplyModifiedProperties();
                }
                else if (launcher != null)
                {
                    var lso = new SerializedObject(launcher);
                    lso.FindProperty("attachedUnit").objectReferenceValue = ship;
                    lso.FindProperty("ammo").intValue = w.ammo;
                    lso.FindProperty("fireInterval").floatValue = w.fireInterval;
                    lso.FindProperty("reloadTime").floatValue = w.reloadTime;
                    lso.ApplyModifiedProperties();
                }
            }

            // FireControl.turrets
            if (fc != null)
            {
                var fso = new SerializedObject(fc);
                var tp = fso.FindProperty("turrets");
                if (tp != null && tp.isArray)
                {
                    tp.arraySize = turrets.Count;
                    for (int i = 0; i < turrets.Count; i++)
                        tp.GetArrayElementAtIndex(i).objectReferenceValue = turrets[i];
                }
                fso.ApplyModifiedProperties();
            }
            return radar;
        }

        /// <summary>Generates a full-count VLS cell grid of launch transforms
        /// (exactly the game convention: cell local +Z points up, ejection
        /// along it). Columns run across the launcher local X, rows along Z.</summary>
        static void BuildLaunchCells(GameObject launcherGo, MissileLauncher launcher, FFWeaponSpec w)
        {
            // wipe donor launch transforms (visual cells replaced by our grid)
            var cellsRoot = launcherGo.transform.Find("FF_Cells");
            if (cellsRoot != null) UnityEngine.Object.DestroyImmediate(cellsRoot.gameObject);
            // remove old launch-point children of donor (name pattern Launch/R45/tube/vls)
            foreach (Transform child in launcherGo.transform.Cast<Transform>().ToList())
            {
                var n = child.name.ToLowerInvariant();
                if (n.Contains("launchp") || n.Contains("launch_p") || n.StartsWith("r45") ||
                    n.StartsWith("vls") || n.StartsWith("tube"))
                    UnityEngine.Object.DestroyImmediate(child.gameObject);
            }
            cellsRoot = new GameObject("FF_Cells").transform;
            cellsRoot.SetParent(launcherGo.transform, false);

            int count = w.cellColumns * w.cellRows;
            var cells = new List<Transform>();
            int idx = 0;
            float wSpan = (w.cellColumns - 1) * w.cellSpacing;
            float dSpan = (w.cellRows - 1) * w.cellSpacing;
            for (int r = 0; r < w.cellRows; r++)
            {
                for (int c = 0; c < w.cellColumns; c++)
                {
                    var cell = new GameObject($"LaunchP_{idx:00}").transform;
                    cell.SetParent(cellsRoot, false);
                    cell.localPosition = new Vector3(
                        -wSpan / 2f + c * w.cellSpacing, 0f, -dSpan / 2f + r * w.cellSpacing);
                    cell.localRotation = Quaternion.Euler(-90f, 0f, 0f); // +Z -> world up
                    cells.Add(cell);
                    idx++;
                }
            }
            var lso = new SerializedObject(launcher);
            var lt = lso.FindProperty("launchTransforms");
            if (lt != null && lt.isArray)
            {
                lt.arraySize = cells.Count;
                for (int i = 0; i < cells.Count; i++)
                    lt.GetArrayElementAtIndex(i).objectReferenceValue = cells[i];
            }
            else Warn($"{w.name}: MissileLauncher.launchTransforms property not found!");
            lso.FindProperty("cellColumns").intValue = w.cellColumns;
            lso.FindProperty("cellRows").intValue = w.cellRows;
            lso.FindProperty("cellSeperation").floatValue = w.cellSpacing;
            lso.ApplyModifiedProperties();
            Say($"{w.name}: {count} VLS cells generated ({w.cellColumns}x{w.cellRows}).");
        }

        // ==================================================================
        // HANGAR (functional: Hangar + Airbase + vertical landing + rearm)
        // ==================================================================
        const bool SKIP_HANGAR = true; // TEST: set false to build hangars again

        static void BuildHangar(GameObject root, FFShipSpec spec, Dictionary<string, ShipPart> sections)
        {
            var ship = root.GetComponent<Ship>();
            var airbase = root.GetComponent<Airbase>();

            // hangar mouth + spawn transform
            var mouth = new GameObject("FF_" + spec.id + "_Hangar");
            mouth.transform.SetParent(root.transform, false);
            mouth.transform.localPosition = new Vector3(0, spec.hangarY, spec.hangarZ);
            var hangar = mouth.AddComponent<Hangar>();
            var spawnT = Anchor(mouth, "SpawnTransform", 0, 0.5f, spec.hangarDepth * 0.4f);

            var aircraft = FF_AssetResolver.FindAll<AircraftDefinition>().Take(6).ToList();
            var hso = new SerializedObject(hangar);
            hso.FindProperty("attachedUnit").objectReferenceValue = ship;
            hso.FindProperty("priority").floatValue = 1f;
            hso.FindProperty("waitForOpenBeforeSpawn").boolValue = true;
            hso.FindProperty("doorSpeed").floatValue = 0.25f;
            hso.FindProperty("clearDistance").floatValue = 30f;
            hso.FindProperty("spawnTransform").objectReferenceValue = spawnT;
            hso.FindProperty("elevator").boolValue = false;
            var avail = hso.FindProperty("availableAircraft");
            if (avail != null && avail.isArray)
            {
                avail.arraySize = aircraft.Count;
                for (int i = 0; i < aircraft.Count; i++)
                    avail.GetArrayElementAtIndex(i).objectReferenceValue = aircraft[i];
            }
            else Warn("Hangar.availableAircraft property not found - helicopters will still be spawnable via airbase.");
            var abRef = hso.FindProperty("parentAirbase");
            if (abRef != null) abRef.objectReferenceValue = airbase;
            hso.ApplyModifiedProperties();
            Say($"hangar wired: {aircraft.Count} aircraft available (vanilla list).");

            // airbase settings
            var aso = new SerializedObject(airbase);
            aso.FindProperty("attachedUnit").objectReferenceValue = ship;
            var settings = aso.FindProperty("airbaseSettings");
            if (settings != null)
            {
                settings.FindPropertyRelative("UniqueName").stringValue = spec.unitName;
                settings.FindPropertyRelative("DisplayName").stringValue = spec.unitName;
                settings.FindPropertyRelative("Capturable").boolValue = false;
                settings.FindPropertyRelative("CaptureRange").floatValue = 150f;
            }
            var centre = root.transform.Find("AirbaseCentre");
            if (centre == null) centre = Anchor(root, "AirbaseCentre", 0, spec.hangarY, spec.hangarZ).transform;
            aso.FindProperty("center").objectReferenceValue = centre;
            aso.FindProperty("aircraftSelectionTransform").objectReferenceValue = mouth.transform;
            var camT = root.transform.Find("CameraTransform");
            if (camT == null) camT = Anchor(root, "CameraTransform", 0, spec.hangarY + 6, spec.hangarZ - 4).transform;
            aso.FindProperty("fixedCameraTransform").objectReferenceValue = camT;

            // vertical landing point on the flight deck
            var deck = new GameObject("FF_" + spec.id + "_VertLanding").transform;
            deck.SetParent(root.transform, false);
            deck.localPosition = new Vector3(0, spec.flightDeckY, spec.flightDeckZ);
            var vlp = aso.FindProperty("verticalLandingPoints");
            if (vlp != null && vlp.isArray)
            {
                vlp.arraySize = 1;
                var e0 = vlp.GetArrayElementAtIndex(0);
                e0.FindPropertyRelative("point").objectReferenceValue = deck;
                e0.FindPropertyRelative("approachAngleRange").floatValue = 45f;
                e0.FindPropertyRelative("size").floatValue = spec.flightDeckSize;
            }
            aso.ApplyModifiedProperties();

            // rearmer access on deck edge
            var rearmer = root.GetComponent<Rearmer>();
            var rso = new SerializedObject(rearmer);
            var access = root.transform.Find("RearmPoint");
            if (access == null) access = Anchor(root, "RearmPoint", 0, spec.flightDeckY + 2, spec.flightDeckZ + 10).transform;
            rso.FindProperty("accessTransform").objectReferenceValue = access;
            rso.FindProperty("Unit").objectReferenceValue = ship;
            rso.FindProperty("Range").floatValue = 1000f;
            rso.FindProperty("Capacity").floatValue = 500000f;
            rso.ApplyModifiedProperties();
        }

        // ==================================================================
        // AMMO RACKS (cook-off sections)
        // ==================================================================
        static void BuildAmmoRacks(GameObject root, FFShipSpec spec, Dictionary<string, ShipPart> sections)
        {
            foreach (var s in spec.sections.Where(x => x.ammoRack))
            {
                if (!sections.TryGetValue(s.label, out var part)) continue;
                var rack = new GameObject("FF_" + spec.id + "_AmmoRack_" + s.label);
                rack.transform.SetParent(part.gameObject.transform, false);
                // put the rack box amid the band, on deck level
                rack.transform.localPosition = new Vector3(0, 2.5f, 0);
                var bc = rack.AddComponent<BoxCollider>();
                bc.size = new Vector3(6, 3, 12);
                var up = rack.AddComponent<UnitPart>();
                var uso = new SerializedObject(up);
                uso.FindProperty("hitPoints").floatValue = 35f; // fragile -> cooks off
                uso.ApplyModifiedProperties();
                Say($"ammo rack added to {s.label} (cook-off risk).");
            }
        }

        // ==================================================================
        // WAKE FX + AUDIO (best effort from game assets)
        // ==================================================================
        static void BuildWakeAndAudio(GameObject root, FFShipSpec spec)
        {
            var ship = root.GetComponent<Ship>();
            var wakeSystems = new List<ParticleSystem>();

            // try to copy a wake particle from game ships
            GameObject wakeDonor = null;
            foreach (var g in AssetDatabase.FindAssets("t:Prefab"))
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var p = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (p == null) continue;
                if (p.name.ToLowerInvariant().Contains("wake") || p.name.ToLowerInvariant().Contains("foam"))
                { wakeDonor = p; break; }
            }
            if (wakeDonor != null)
            {
                var wake = (GameObject)PrefabUtility.InstantiatePrefab(wakeDonor);
                if (wake == null) wake = UnityEngine.Object.Instantiate(wakeDonor);
                PrefabUtility.UnpackPrefabInstance(wake, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
                wake.name = "FF_Wake";
                wake.transform.SetParent(root.transform, false);
                wake.transform.localPosition = new Vector3(0, -1.5f, -spec.sections.Count); // aft
                wakeSystems.AddRange(wake.GetComponentsInChildren<ParticleSystem>(true));
                Say("wake FX cloned from " + wakeDonor.name);
            }
            else Warn("no wake particle prefab found in game assets - Ship.wakeParticles stays empty.");

            // sounds
            var engineClip = FF_AssetResolver.FindAudioLike(new[] { "engine", "ship" });
            var wakeClip = FF_AssetResolver.FindAudioLike(new[] { "wake", "water", "ocean" });
            var so = new SerializedObject(ship);
            var ws = so.FindProperty("waterSounds");
            if (ws != null && ws.isArray && wakeClip != null)
            {
                ws.arraySize = 1;
                ws.GetArrayElementAtIndex(0).objectReferenceValue = wakeClip.clip;
            }
            var hs = so.FindProperty("hullSounds");
            if (hs != null && hs.isArray && engineClip != null)
            {
                hs.arraySize = 1;
                hs.GetArrayElementAtIndex(0).objectReferenceValue = engineClip.clip;
            }
            var wp = so.FindProperty("wakeParticles");
            if (wp != null && wp.isArray)
            {
                wp.arraySize = wakeSystems.Count;
                for (int i = 0; i < wakeSystems.Count; i++)
                    wp.GetArrayElementAtIndex(i).objectReferenceValue = wakeSystems[i];
            }
            so.ApplyModifiedProperties();

            if (engineClip != null)
            {
                var src = root.AddComponent<AudioSource>();
                src.clip = engineClip.clip; src.loop = true; src.spatialBlend = 1f;
                src.minDistance = 30f; src.maxDistance = 1500f; src.volume = 0.4f; src.playOnAwake = true;
            }
        }

        // ==================================================================
        // MOD SCRIPTS (from the compiled plugin DLL in Assets/Plugins)
        // ==================================================================
        static void AttachModScripts(GameObject root, FFShipSpec spec)
        {
            TryAddModScript(root, "FlashpointFleets.FFNoisemakerRack, FlashpointFleets2035",
                "noisemaker rack (torpedo soft-kill decoys)");
            TryAddModScript(root, "FlashpointFleets.FFResupplyShip, FlashpointFleets2035",
                "resupply-ship logic (optional)");
        }

        static void TryAddModScript(GameObject go, string typeName, string what)
        {
            var t = Type.GetType(typeName);
            if (t == null || !typeof(Component).IsAssignableFrom(t))
            {
                Warn($"{what}: type not found ({typeName}). Build the plugin DLL and copy it into " +
                     "Assets/Plugins before building ships for full functionality.");
                return;
            }
            try
            {
                go.AddComponent(t);
                Say(what + " attached.");
            }
            catch (Exception e) { Warn(what + " failed: " + e.Message); }
        }

        // ==================================================================
        // SHIP DEFINITION ASSET
        // ==================================================================
        static ShipDefinition BuildDefinition(FFShipSpec spec, GameObject root)
        {
            var def = ScriptableObject.CreateInstance<ShipDefinition>();
            def.name = "FF_" + spec.id + "_Definition";
            var so = new SerializedObject(def);

            so.FindProperty("jsonKey").stringValue = spec.jsonKey;
            so.FindProperty("unitName").stringValue = spec.unitName;
            so.FindProperty("description").stringValue = spec.description;
            so.FindProperty("code").stringValue = spec.code;
            so.FindProperty("visibleRange").floatValue = 120000f;
            so.FindProperty("iconRange").floatValue = 40000f;
            so.FindProperty("radarSize").floatValue = 1.2f;
            so.FindProperty("IsObstacle").boolValue = true;
            so.FindProperty("iconSize").floatValue = 1f;
            so.FindProperty("mapIconSize").floatValue = 2.2f;
            so.FindProperty("captureCapacity").intValue = 25;
            so.FindProperty("captureStrength").floatValue = 100f;
            so.FindProperty("value").floatValue = spec.value;
            so.FindProperty("manpower").floatValue = spec.manpower;
            so.FindProperty("armorTier").floatValue = spec.armorTier;
            so.FindProperty("damageTolerance").floatValue = spec.damageTolerance;
            so.FindProperty("disabled").boolValue = false;
            so.FindProperty("dontAutomaticallyAddToEncyclopedia").boolValue = false;

            // dims from the actual hull
            var bounds = CalcBounds(root);
            so.FindProperty("length").floatValue = bounds.size.z;
            so.FindProperty("width").floatValue = bounds.size.x;
            so.FindProperty("height").floatValue = bounds.size.y;
            var off = so.FindProperty("spawnOffset");
            if (off != null) off.vector3Value = new Vector3(0, bounds.extents.y * 0.25f, 0);

            var ti = so.FindProperty("typeIdentity");
            if (ti != null)
            {
                ti.FindPropertyRelative("surface").floatValue = 1f;
                ti.FindPropertyRelative("air").floatValue = 0f;
                ti.FindPropertyRelative("missile").floatValue = 0f;
                ti.FindPropertyRelative("radar").floatValue = 0f;
                ti.FindPropertyRelative("strategic").floatValue = 0.3f;
            }
            var ri = so.FindProperty("roleIdentity");
            if (ri != null)
            {
                ri.FindPropertyRelative("antiSurface").floatValue = 0.9f;
                ri.FindPropertyRelative("antiAir").floatValue = 0.9f;
                ri.FindPropertyRelative("antiMissile").floatValue = 0.8f;
                ri.FindPropertyRelative("antiRadar").floatValue = 0f;
            }
            so.FindProperty("shipType").intValue = spec.shipType;
            var si = so.FindProperty("shipInfo");
            if (si != null)
            {
                si.FindPropertyRelative("topSpeed").floatValue = spec.topSpeed;
                si.FindPropertyRelative("mass").floatValue = TotalMass(spec);
            }

            // icons: reuse vanilla ship sprites where findable
            var friendly = FF_AssetResolver.FindFirst<Sprite>("Ship") ?? FF_AssetResolver.FindFirst<Sprite>("ship*");
            var hostile = friendly;
            var map = FF_AssetResolver.FindFirst<Sprite>("Ship") ?? friendly;
            if (friendly != null)
            {
                so.FindProperty("friendlyIcon").objectReferenceValue = friendly;
                so.FindProperty("hostileIcon").objectReferenceValue = hostile;
                so.FindProperty("mapIcon").objectReferenceValue = map;
            }
            else Warn("no ship icon sprite found - game default will be used.");

            so.ApplyModifiedProperties();

            var path = FF_ShipSpec.ModRoot + "/Definitions/FF_" + spec.id + "_Definition.asset";
            EnsureFolder(FF_ShipSpec.ModRoot + "/Definitions");
            AssetDatabase.CreateAsset(def, path);
            AssetDatabase.SaveAssets();
            Say("ShipDefinition asset: " + path);
            return def;
        }

        static Bounds CalcBounds(GameObject root)
        {
            var b = new Bounds();
            bool first = true;
            foreach (var r in root.GetComponentsInChildren<Renderer>(true))
            {
                var e = r.bounds;
                if (first) { b = e; first = false; }
                else b.Encapsulate(e);
            }
            return b;
        }

        // ==================================================================
        // helpers
        // ==================================================================
        static void Set(Component c, string field, object value)
        {
            var so = new SerializedObject(c);
            var p = so.FindProperty(field);
            if (p == null) { Warn($"{c.GetType().Name}.{field} not found (skipped)"); return; }
            switch (value)
            {
                case float f: p.floatValue = f; break;
                case int i: p.intValue = i; break;
                case bool b: p.boolValue = b; break;
                default: p.boxedValue = value; break;
            }
            so.ApplyModifiedProperties();
        }

        static void SetProp(SerializedObject so, string field, object value)
        {
            var p = so.FindProperty(field);
            if (p == null) { Warn($"property {field} not found"); return; }
            switch (value)
            {
                case float f: p.floatValue = f; break;
                case int i: p.intValue = i; break;
                case bool b: p.boolValue = b; break;
            }
            so.ApplyModifiedProperties();
        }

        static void AddIfExists(GameObject go, string componentTypeName)
        {
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                var t = asm.GetType(componentTypeName) ?? asm.GetType("NuclearOption." + componentTypeName);
                if (t != null && typeof(Component).IsAssignableFrom(t))
                {
                    try { go.AddComponent(t); Say(componentTypeName + " added"); } catch { }
                    return;
                }
            }
            Warn(componentTypeName + " type not found in imported game assemblies (skipped).");
        }
    }
}
