// ============================================================================
// Flashpoint Fleets 2035 - FF_ImportPostprocessor.cs
// Forces correct import settings for the prepared ship models:
//  - real-world scale (no unit conversion), 1 unit = 1 m
//  - readable meshes for colliders
//  - materials converted to URP Lit with their OBJ albedo colors/maps
// ============================================================================

using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace FlashpointFleets.EditorTools
{
    public class FF_ImportPostprocessor : AssetPostprocessor
    {
        void OnPreprocessModel()
        {
            if (!assetPath.Contains("/Mods/FlashpointFleets2035/Models/")) return;
            var mi = (ModelImporter)assetImporter;
            mi.useFileUnits = false;   // models are authored in meters; no rescale
            mi.globalScale = 1f;
            mi.importBlendShapes = false;
            mi.isReadable = true;      // colliders need CPU mesh data
            mi.meshCompression = ModelImporterMeshCompression.Off;
        }

        static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] moved, string[] movedFrom)
        {
            foreach (var path in imported)
            {
                if (!path.Contains("/Mods/FlashpointFleets2035/Models/")) continue;
                if (!path.EndsWith(".obj")) continue;
                FixMaterials(path);
            }
        }

        static void FixMaterials(string modelPath)
        {
            var urpLit = Shader.Find("Universal Render Pipeline/Lit")
                         ?? Shader.Find("Universal Render Pipeline/Simple Lit")
                         ?? Shader.Find("Standard");
            var materials = new List<Material>();
            foreach (var o in AssetDatabase.LoadAllAssetsAtPath(modelPath))
                if (o is Material m) materials.Add(m);

            foreach (var mat in materials)
            {
                if (mat == null) continue;
                var tex = mat.HasProperty("_MainTex") ? mat.GetTexture("_MainTex") : null;
                var col = mat.HasProperty("_Color") ? mat.GetColor("_Color") : Color.gray;
                if (mat.shader == null || !mat.shader.name.StartsWith("Universal Render Pipeline"))
                    mat.shader = urpLit;
                if (tex != null) mat.SetTexture("_BaseMap", tex);
                if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", col);
                if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", 0.25f);
                EditorUtility.SetDirty(mat);
            }
        }
    }
}
