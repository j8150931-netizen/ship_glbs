// ============================================================================
// Flashpoint Fleets 2035 - FF_AssetResolver.cs
// Locates game assets (ripped into the Blueprinter "_donotship" folder) for
// use as weapon donors, FX and icons. Includes the discovery dump used to
// verify donor names before building.
// ============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace FlashpointFleets.EditorTools
{
    public static class FF_AssetResolver
    {
        // ------------------------------------------------------------------
        // Generic search: all assets of type T whose name matches a pattern.
        // ------------------------------------------------------------------
        public static List<T> FindAll<T>(params string[] nameFilters) where T : UnityEngine.Object
        {
            var results = new List<T>();
            var guids = AssetDatabase.FindAssets("t:" + typeof(T).Name);
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship") && !path.Contains("/Mods/"))
                    continue; // prefer game assets + our own mod folder only
                var assets = AssetDatabase.LoadAllAssetsAtPath(path).OfType<T>();
                foreach (var a in assets)
                {
                    if (a == null) continue;
                    if (nameFilters.Length == 0 || nameFilters.Any(f => NameMatches(a.name, f)))
                        results.Add(a);
                }
            }
            return results;
        }

        public static bool NameMatches(string assetName, string filter)
        {
            if (string.IsNullOrEmpty(filter)) return true;
            assetName = assetName ?? "";
            if (filter.EndsWith("*")) return assetName.StartsWith(filter.Substring(0, filter.Length - 1), StringComparison.OrdinalIgnoreCase);
            if (filter.StartsWith("*")) return assetName.EndsWith(filter.Substring(1), StringComparison.OrdinalIgnoreCase);
            return string.Equals(assetName, filter, StringComparison.OrdinalIgnoreCase);
        }

        // ------------------------------------------------------------------
        // Donor launcher: a GameObject (from the game's ripped assets) that
        // carries a MissileLauncher. We clone it for visual + pre-wired Turret
        // internals, then re-grid its launch transforms.
        // ------------------------------------------------------------------
        public static GameObject FindLauncherDonor(string donorName, string role)
        {
            // 1) exact-ish name match on launcher prefabs
            var candidates = new List<GameObject>();
            var guids = AssetDatabase.FindAssets("t:Prefab t:Model");
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var root = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (root == null) continue;
                if (NameMatches(root.name, donorName) && root.GetComponentInChildren<MissileLauncher>(true) != null)
                    return root;
                if (root.GetComponentsInChildren<MissileLauncher>(true).Length > 0 &&
                    (NameMatches(root.name, donorName) || donorName == "*"))
                    candidates.Add(root);
            }
            // 2) any launcher with a matching-ish name
            foreach (var c in candidates) return c;
            // 3) last resort: any MissileLauncher in game assets
            guids = AssetDatabase.FindAssets("t:Prefab t:Model");
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var root = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (root != null && root.GetComponentInChildren<MissileLauncher>(true) != null)
                {
                    Debug.LogWarning($"[FF] Launcher donor '{donorName}' not found by name; falling back to '{root.name}' for role {role}.");
                    return root;
                }
            }
            return null;
        }

        // Gun/CIWS donor: GameObject with a Gun component.
        public static GameObject FindGunDonor(string donorName, bool ciws)
        {
            var guids = AssetDatabase.FindAssets("t:Prefab t:Model");
            GameObject fallback = null;
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var root = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (root == null) continue;
                var guns = root.GetComponentsInChildren<Gun>(true);
                if (guns.Length == 0) continue;
                var nm = root.name.ToLowerInvariant();
                if (NameMatches(root.name, donorName)) return root;
                if (ciws && (nm.Contains("ciws") || nm.Contains("phalanx") || nm.Contains("goalkeeper") || nm.Contains("kashtan")))
                    return root;
                if (fallback == null && !ciws) fallback = root;
                if (fallback == null) fallback = root;
            }
            if (fallback != null)
                Debug.LogWarning($"[FF] Gun donor '{donorName}' not found by name; falling back to '{fallback.name}'.");
            return fallback;
        }

        // ------------------------------------------------------------------
        // Sounds / particles / icons
        // ------------------------------------------------------------------
        public static T FindFirst<T>(string nameFilter) where T : UnityEngine.Object
        {
            var guids = AssetDatabase.FindAssets("t:" + typeof(T).Name);
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                foreach (var a in AssetDatabase.LoadAllAssetsAtPath(path).OfType<T>())
                    if (NameMatches(a.name, nameFilter)) return a;
            }
            return null;
        }

        public static AudioSourceProbe FindAudioLike(string[] patterns)
        {
            // Returns an AudioClip whose name matches any pattern
            var guids = AssetDatabase.FindAssets("t:AudioClip");
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(path);
                if (clip == null) continue;
                var nm = clip.name.ToLowerInvariant();
                foreach (var p in patterns)
                    if (nm.Contains(p)) return new AudioSourceProbe { clip = clip, name = clip.name };
            }
            return null;
        }

        public struct AudioSourceProbe { public AudioClip clip; public string name; }

        // ------------------------------------------------------------------
        // DISCOVERY DUMP - writes a report of every game MissileDefinition,
        // WeaponMount, ShipDefinition and launcher/gun prefab found, so donor
        // names in FF_ShipSpec can be verified/corrected in one place.
        // ------------------------------------------------------------------
        [MenuItem("FF/Dump Game Assets (report)")]
        public static void DumpGameAssets()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Flashpoint Fleets - game asset report");
            sb.AppendLine("Generated " + DateTime.Now);
            sb.AppendLine();

            Action<string, IEnumerable<string>> section = (title, rows) =>
            {
                sb.AppendLine("=== " + title + " ===");
                foreach (var r in rows) sb.AppendLine("  " + r);
                sb.AppendLine();
            };

            var missiles = FindAll<MissileDefinition>();
            section("MissileDefinitions (" + missiles.Count + ")",
                missiles.Select(m => m.name + "  unitName='" + m.unitName + "'  jsonKey=" + m.jsonKey));

            var mounts = FindAll<WeaponMount>();
            section("WeaponMounts (" + mounts.Count + ")",
                mounts.Select(m => m.name + "  mountName='" + m.mountName + "'"));

            var ships = FindAll<ShipDefinition>();
            section("ShipDefinitions (" + ships.Count + ")",
                ships.Select(s => s.name + "  unitName='" + s.unitName + "'  shipType=" + s.shipType + "  topSpeed=" + s.shipInfo.topSpeed));

            var aircraft = FindAll<AircraftDefinition>();
            section("AircraftDefinitions (" + aircraft.Count + ") (for hangars)",
                aircraft.Select(a => a.name + "  unitName='" + a.unitName + "'"));

            var guids = AssetDatabase.FindAssets("t:Prefab t:Model");
            var launchers = new List<string>();
            var guns = new List<string>();
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path) || !path.Contains("_donotship")) continue;
                var root = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (root == null) continue;
                if (root.GetComponentInChildren<MissileLauncher>(true) != null)
                    launchers.Add(root.name + "   (path: " + path + ")");
                if (root.GetComponentInChildren<Gun>(true) != null)
                    guns.Add(root.name + "   (path: " + path + ")");
            }
            section("Prefabs with MissileLauncher (" + launchers.Count + ")", launchers);
            section("Prefabs with Gun (" + guns.Count + ")", guns);

            var sprites = FindAll<Sprite>();
            section("Sprites (" + sprites.Count + ") (icons)",
                sprites.Select(s => s.name).Take(200));

            File.WriteAllText("ff_game_assets_report.txt", sb.ToString());
            EditorUtility.RevealInFinder("ff_game_assets_report.txt");
            Debug.Log("[FF] Asset report written: ff_game_assets_report.txt (root of project)");
        }
    }
}
