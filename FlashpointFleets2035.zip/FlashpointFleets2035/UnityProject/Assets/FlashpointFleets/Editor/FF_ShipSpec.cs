// ============================================================================
// Flashpoint Fleets 2035 - FF_ShipSpec.cs
// Declarative specification of all four warships.
//
// All coordinates are in CANONICAL SHIP SPACE (matches the prepared models):
//   +Z = bow        +X = starboard      +Y = up, 0 = design waterline
//   1 unit = 1 meter. Origin = center of ship at the waterline.
//
// The prefab factory (FF_PrefabFactory) consumes these tables and assembles
// fully-functional Nuclear Option ships: Ship + ShipAI + ShipPart damage
// sections, Radar, TargetDetectors, Turrets/MissileLaunchers with full-count
// VLS cell grids, functional Hangars (Airbase + Rearmer), wake FX, sounds
// and the ShipDefinition asset.
//
// Every position below was derived from the prepared hull mesh profiles
// (see Models/<Ship>/manifest.json + preview.png) and can be tweaked freely.
// ============================================================================

using System.Collections.Generic;

namespace FlashpointFleets.EditorTools
{
    // ------------------------------------------------------------------
    // Weapon mount descriptor. 'grid' generates a full-count VLS cell field
    // (the game's MissileLauncher supports cellColumns/cellRows natively);
    // 'donorPrefab' names the vanilla launcher/CIWS/gun GameObject that is
    // cloned to provide the visual + pre-wired Turret internals.
    // ------------------------------------------------------------------
    public class FFWeaponSpec
    {
        public string name;              // final GameObject name, "FF_<ship>_..." (runtime patches key on this)
        public string role;              // SAM | ASHM | LACM | CIWS | GUN | RAM | ASW | RAILGUN
        public string donorPrefab;       // vanilla GameObject name (see FF_AssetResolver.DumpGameAssets)
        public string missileKey;        // WeaponCatalog key assigned at runtime (FF_ prefixed new missiles)

        // placement
        public float x, y, z;            // position in canonical ship space
        public float yaw;                // deg; 0 = facing bow

        // full-count VLS grid
        public int cellColumns = 1;      // across (port-starboard)
        public int cellRows = 1;         // deep (fore-aft)
        public float cellSpacing = 2.3f; // meters
        public float cellSize = 1.6f;

        // launcher tuning (fields exist on MissileLauncher)
        public int ammo = 8;
        public float fireInterval = 1.5f;
        public float reloadTime = 10f;
        public float ejectionVelocityZ = 12f; // cold launch

        // turret tuning
        public float traverseRate = 120f;
        public float minElevation = 0f;
        public float maxElevation = 85f;
        public float lockTime = 0.5f;
    }

    // ------------------------------------------------------------------
    // Damage-model section. Split bands come from the prepared OBJ groups
    // (Section00 = stern ... SectionNN = bow); here we give each band its
    // gameplay identity, buoyancy and armor.
    // ------------------------------------------------------------------
    public class FFSectionSpec
    {
        public int modelSection;         // SectionNN index in the imported model
        public string label;             // gameplay name, e.g. "BowGunDeck"
        public bool critical;            // criticalPart of the Ship
        public float hitPoints = 120f;   // ShipPart.hitPoints
        public float massTons = 900f;    // ShipPart.mass (kg = tons*1000)
        public float displacement = 3000f;   // ShipPart.displacement (m^3) - buoyancy
        public float height = 18f;           // ShipPart.height - compartment height
        public float leakThreshold = 80f;
        public float leakRateMin = 1f, leakRateMax = 2.5f;
        public float sinkThreshold = 0.75f;
        public float breakJointStrength = 12000f;
        public float pierceArmor = 380f, blastArmor = 380f, fireArmor = 20f;
        public bool ammoRack;            // add explosive UnitPart ammo rack
    }

    // ------------------------------------------------------------------
    // One complete ship.
    // ------------------------------------------------------------------
    public class FFShipSpec
    {
        public string id;                // "T055" - used in prefab & definition names
        public string modelPath;         // "Assets/Blueprinter/Mods/FlashpointFleets2035/Models/Type055/OBJ/Type055.obj"
        public string jsonKey;           // ShipDefinition.jsonKey
        public string unitName;          // in-game encyclopedia name
        public string description;
        public string code = "SHP";
        public int shipType = 1;         // verify against vanilla with FF/Dump Game Assets
        public float topSpeed = 30f;     // knots-ish, ShipDefinition.shipInfo.topSpeed is in game units
        public float value = 2200f;      // encyclopedia value
        public float manpower = 280f;
        public float armorTier = 5f;
        public float damageTolerance = 45f;

        public List<FFSectionSpec> sections = new List<FFSectionSpec>();
        public List<FFWeaponSpec> weapons = new List<FFWeaponSpec>();

        // functional hangar / airbase
        public bool hasHangar = true;
        public float hangarZ, hangarY;               // hangar mouth center
        public float hangarWidth = 16f, hangarHeight = 8f, hangarDepth = 24f;
        public int hangarCapacity = 2;
        public float flightDeckZ, flightDeckY;       // vertical landing point
        public float flightDeckSize = 22f;

        // sensors
        public float radarZ, radarY;                 // primary radar masthead
        public float radarMaxRange = 25000f;
        public float lookoutZ, lookoutY;             // bridge TargetDetector
    }

    public static class FF_ShipSpec
    {
        public const string ModRoot = "Assets/Blueprinter/Mods/FlashpointFleets2035";
        public const string ModModels = ModRoot + "/Models";

        // ==================================================================
        // TYPE 055 RENHAI-CLASS GUIDED-MISSILE CRUISER (PLAN, 180 m)
        // ==================================================================
        public static FFShipSpec Type055() => new FFShipSpec
        {
            id = "T055",
            modelPath = ModModels + "/Type055/OBJ/Type055.obj",
            jsonKey = "FF_T055",
            unitName = "Renhai-class Cruiser (Type 055)",
            description =
                "The Renhai-class (Type 055) is the largest PLAN surface combatant of the flashpoint era - " +
                "a 112-cell universal VLS cruiser pairing HHQ-9B long-range air defense with YJ-18 anti-ship " +
                "strikes, a 130 mm main gun, Type 1130 CIWS and an HHQ-10 point-defense launcher over a " +
                "twin-spot hangar and flight deck. Multi-function dual-band radar mast, full sectioned " +
                "damage model with progressive flooding, ammunition racks that cook off, and a torpedo " +
                "defense suite (noisemakers + ASW weapons via the Flashpoint weapon catalog).",
            shipType = 1,
            topSpeed = 32f,
            value = 2600f, manpower = 400f, armorTier = 6f, damageTolerance = 55f,

            hangarZ = -56f, hangarY = 15f, hangarWidth = 18f, hangarHeight = 9f, hangarDepth = 26f, hangarCapacity = 2,
            flightDeckZ = -80f, flightDeckY = 7.6f, flightDeckSize = 24f,
            radarZ = 9f, radarY = 33f, radarMaxRange = 30000f,
            lookoutZ = 30f, lookoutY = 12f,

            sections = new List<FFSectionSpec>
            {
                new FFSectionSpec { modelSection = 8, label = "Bow",            critical = false, hitPoints = 110, massTons = 1100, displacement = 2600, height = 12, leakThreshold = 85, sinkThreshold = 0.8f, pierceArmor = 420, blastArmor = 420 },
                new FFSectionSpec { modelSection = 7, label = "ForeVLS",        critical = false, hitPoints = 130, massTons = 1500, displacement = 4200, height = 18, ammoRack = true },
                new FFSectionSpec { modelSection = 6, label = "Bridge",         critical = true,  hitPoints = 120, massTons = 1200, displacement = 3000, height = 16 },
                new FFSectionSpec { modelSection = 5, label = "MastFunnel",     critical = false, hitPoints = 110, massTons = 1000, displacement = 3200, height = 16 },
                new FFSectionSpec { modelSection = 4, label = "Midships",       critical = false, hitPoints = 150, massTons = 1800, displacement = 5000, height = 18 },
                new FFSectionSpec { modelSection = 3, label = "AftVLS",         critical = false, hitPoints = 130, massTons = 1400, displacement = 3800, height = 16, ammoRack = true },
                new FFSectionSpec { modelSection = 2, label = "HangarBlock",    critical = false, hitPoints = 140, massTons = 1500, displacement = 4000, height = 20 },
                new FFSectionSpec { modelSection = 1, label = "HangarMouth",    critical = false, hitPoints = 120, massTons = 900,  displacement = 2400, height = 14 },
                new FFSectionSpec { modelSection = 0, label = "FlightDeckStern",critical = false, hitPoints = 110, massTons = 1000, displacement = 2600, height = 12, breakJointStrength = 8000 },
            },

            weapons = new List<FFWeaponSpec>
            {
                // --- full-count 112-cell universal VLS --------------------------------
                new FFWeaponSpec { name = "FF_T055_VLS_Fore_FF_HHQ9B",  role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_HHQ9B",
                    x = 0,  y = 10.6f, z = 55,  cellColumns = 8, cellRows = 8, cellSpacing = 2.35f,
                    ammo = 64, fireInterval = 1.2f, reloadTime = 14f, ejectionVelocityZ = 14f, lockTime = 0.35f },
                new FFWeaponSpec { name = "FF_T055_VLS_Aft_FF_HHQ9B",   role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_HHQ9B",
                    x = 0,  y = 10.8f, z = -22, cellColumns = 8, cellRows = 4, cellSpacing = 2.35f,
                    ammo = 32, fireInterval = 1.2f, reloadTime = 14f, ejectionVelocityZ = 14f, lockTime = 0.35f },
                new FFWeaponSpec { name = "FF_T055_VLS_Aft_FF_YJ18A",   role = "ASHM", donorPrefab = "AShM2", missileKey = "FF_YJ18A",
                    x = 0,  y = 10.8f, z = -38, cellColumns = 8, cellRows = 2, cellSpacing = 2.35f,
                    ammo = 16, fireInterval = 2.5f, reloadTime = 20f, ejectionVelocityZ = 14f },
                // --- point defense -----------------------------------------------------
                new FFWeaponSpec { name = "FF_T055_HQ10_FF_HHQ10",           role = "RAM",  donorPrefab = "R-45", missileKey = "FF_HHQ10",
                    x = 0,  y = 13.4f, z = -68, yaw = 180, ammo = 24, fireInterval = 0.8f, reloadTime = 12f, lockTime = 0.3f },
                new FFWeaponSpec { name = "FF_T055_CIWS_Port",      role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = -7.5f, y = 12.6f, z = 28, yaw = 0,  traverseRate = 300, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
                new FFWeaponSpec { name = "FF_T055_CIWS_Stbd",      role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = 7.5f,  y = 12.6f, z = -62, yaw = 180, traverseRate = 300, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
                // --- main gun + ASW ----------------------------------------------------
                new FFWeaponSpec { name = "FF_T055_Gun130",         role = "GUN",  donorPrefab = "Gun", missileKey = null,
                    x = 0,  y = 10.6f, z = 74, traverseRate = 40, minElevation = -5, maxElevation = 65, lockTime = 0.8f },
                new FFWeaponSpec { name = "FF_T055_ASROC_FF_Yu8",          role = "ASW",  donorPrefab = "AShM1", missileKey = "FF_Yu8",
                    x = -9f, y = 13.2f, z = 12, yaw = 0, cellColumns = 2, cellRows = 1, ammo = 6, fireInterval = 4f, reloadTime = 25f, lockTime = 0.5f },
            },
        };

        // ==================================================================
        // TYPE 054A JIANGKAI II-CLASS FRIGATE (PLAN, 134 m)
        // ==================================================================
        public static FFShipSpec Type054A() => new FFShipSpec
        {
            id = "T054A",
            modelPath = ModModels + "/Type054A/OBJ/Type054A.obj",
            jsonKey = "FF_T054A",
            unitName = "Jiangkai II-class Frigate (Type 054A)",
            description =
                "The workhorse PLAN escort. 32-cell HHQ-16 VLS, eight inclined YJ-83K sea-skimmers, a 76 mm " +
                "rapid-fire main gun, twin Type 730 CIWS over the hangar, light Yu-8 ASW torpedo tubes and a " +
                "single-helicopter hangar with flight deck. Sectioned damage model with VLS ammo-rack cook-off " +
                "and progressive flooding; torpedo defenses handled by the Flashpoint catalog and TorpedoShield.",
            shipType = 1,
            topSpeed = 27f,
            value = 900f, manpower = 190f, armorTier = 3f, damageTolerance = 30f,

            hangarZ = -40f, hangarY = 12.5f, hangarWidth = 12f, hangarHeight = 7f, hangarDepth = 20f, hangarCapacity = 1,
            flightDeckZ = -57f, flightDeckY = 5.2f, flightDeckSize = 18f,
            radarZ = 7f, radarY = 27.5f, radarMaxRange = 18000f,
            lookoutZ = 22f, lookoutY = 11f,

            sections = new List<FFSectionSpec>
            {
                new FFSectionSpec { modelSection = 7, label = "Bow",        critical = false, hitPoints = 80,  massTons = 550,  displacement = 1200, height = 10, leakThreshold = 85 },
                new FFSectionSpec { modelSection = 6, label = "ForeVLS",    critical = false, hitPoints = 95,  massTons = 750,  displacement = 1700, height = 12, ammoRack = true },
                new FFSectionSpec { modelSection = 5, label = "Bridge",     critical = true,  hitPoints = 85,  massTons = 600,  displacement = 1300, height = 11 },
                new FFSectionSpec { modelSection = 4, label = "MastBlock",  critical = false, hitPoints = 85,  massTons = 650,  displacement = 1500, height = 12 },
                new FFSectionSpec { modelSection = 3, label = "Midships",   critical = false, hitPoints = 100, massTons = 850,  displacement = 2000, height = 12, ammoRack = true },
                new FFSectionSpec { modelSection = 2, label = "Funnel",     critical = false, hitPoints = 90,  massTons = 700,  displacement = 1600, height = 12 },
                new FFSectionSpec { modelSection = 1, label = "Hangar",     critical = false, hitPoints = 95,  massTons = 750,  displacement = 1700, height = 12 },
                new FFSectionSpec { modelSection = 0, label = "SternDeck",  critical = false, hitPoints = 80,  massTons = 550,  displacement = 1200, height = 9, breakJointStrength = 7000 },
            },

            weapons = new List<FFWeaponSpec>
            {
                new FFWeaponSpec { name = "FF_T054A_VLS_FF_HHQ16",  role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_HHQ16",
                    x = 0, y = 6.8f, z = 41, cellColumns = 4, cellRows = 8, cellSpacing = 2.2f,
                    ammo = 32, fireInterval = 1.4f, reloadTime = 15f, ejectionVelocityZ = 13f, lockTime = 0.4f },
                new FFWeaponSpec { name = "FF_T054A_YJ83P_FF_YJ83K",  role = "ASHM", donorPrefab = "AShM2", missileKey = "FF_YJ83K",
                    x = -5.5f, y = 10.4f, z = -12, yaw = 205, ammo = 4, fireInterval = 2.2f, reloadTime = 22f },
                new FFWeaponSpec { name = "FF_T054A_YJ83S_FF_YJ83K",  role = "ASHM", donorPrefab = "AShM2", missileKey = "FF_YJ83K",
                    x = 5.5f,  y = 10.4f, z = -12, yaw = 155, ammo = 4, fireInterval = 2.2f, reloadTime = 22f },
                new FFWeaponSpec { name = "FF_T054A_CIWS_Port",  role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = -6.2f, y = 15.6f, z = -34, yaw = 180, traverseRate = 300, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
                new FFWeaponSpec { name = "FF_T054A_CIWS_Stbd",  role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = 6.2f,  y = 15.6f, z = -34, yaw = 180, traverseRate = 300, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
                new FFWeaponSpec { name = "FF_T054A_Gun76",      role = "GUN",  donorPrefab = "Gun", missileKey = null,
                    x = 0, y = 7.2f, z = 56, traverseRate = 65, minElevation = -10, maxElevation = 75, lockTime = 0.5f },
                new FFWeaponSpec { name = "FF_T054A_Torps_FF_Yu8",      role = "ASW",  donorPrefab = "AShM1", missileKey = "FF_Yu8",
                    x = -4.5f, y = 8.5f, z = -8, yaw = 90, cellColumns = 2, cellRows = 1, ammo = 4, fireInterval = 5f, reloadTime = 30f, lockTime = 0.5f },
            },
        };

        // ==================================================================
        // ADMIRAL NAKHIMOV (KIROV-CLASS, 2035 REFIT, 252 m)
        // ==================================================================
        public static FFShipSpec Nakhimov() => new FFShipSpec
        {
            id = "NAKH",
            modelPath = ModModels + "/Nakhimov/OBJ/Nakhimov.obj",
            jsonKey = "FF_NAKH",
            unitName = "Admiral Nakhimov (2035 Refit)",
            description =
                "The nuclear-powered Kirov-class battlecruiser after her deep 2035 refit: the twenty Granit " +
                " tubes are gone, replaced by 48 UKSK cells for P-800 Oniks and 3M-54 Kalibr, an S-400 field " +
                "with 48N6DM interceptors forward and 32 Redut 9M96E2 cells aft, four Kashtan-M gun/missile " +
                "CIWS, twin 130 mm mounts and a twin-helicopter hangar (Ka-27 detartan carried on deck). " +
                "Full sectioned damage model: the UKSK deck and VLS fields are ammunition racks that cook off " +
                "spectacularly, the tower is a critical part, and progressive flooding will send 28,000 tons " +
                "to the bottom section by section. Torpedo defenses: noisemakers + ASW rocket salvos.",
            shipType = 1,
            topSpeed = 31f,
            value = 4200f, manpower = 760f, armorTier = 8f, damageTolerance = 70f,

            hangarZ = -108f, hangarY = 16.2f, hangarWidth = 16f, hangarHeight = 8.5f, hangarDepth = 26f, hangarCapacity = 2,
            flightDeckZ = -122f, flightDeckY = 15.5f, flightDeckSize = 26f,
            radarZ = -12f, radarY = 47f, radarMaxRange = 32000f,
            lookoutZ = -12f, lookoutY = 33f,

            sections = new List<FFSectionSpec>
            {
                new FFSectionSpec { modelSection = 9, label = "Bow",        critical = false, hitPoints = 160, massTons = 2400, displacement = 5200, height = 16, leakThreshold = 85, pierceArmor = 520, blastArmor = 520 },
                new FFSectionSpec { modelSection = 8, label = "GunMounts",  critical = false, hitPoints = 170, massTons = 2600, displacement = 5600, height = 16, ammoRack = true },
                new FFSectionSpec { modelSection = 7, label = "S400Field",  critical = false, hitPoints = 190, massTons = 3000, displacement = 6400, height = 18, ammoRack = true, pierceArmor = 450, blastArmor = 450 },
                new FFSectionSpec { modelSection = 6, label = "ForeDeck",   critical = false, hitPoints = 180, massTons = 2800, displacement = 6000, height = 18 },
                new FFSectionSpec { modelSection = 5, label = "Tower",      critical = true,  hitPoints = 165, massTons = 2600, displacement = 5200, height = 26 },
                new FFSectionSpec { modelSection = 4, label = "UKSKDeck",   critical = false, hitPoints = 185, massTons = 2900, displacement = 6200, height = 18, ammoRack = true, pierceArmor = 420, blastArmor = 420 },
                new FFSectionSpec { modelSection = 3, label = "FunnelBlock",critical = false, hitPoints = 175, massTons = 2700, displacement = 5800, height = 18 },
                new FFSectionSpec { modelSection = 2, label = "AftVLS",     critical = false, hitPoints = 170, massTons = 2600, displacement = 5600, height = 16, ammoRack = true },
                new FFSectionSpec { modelSection = 1, label = "Hangar",     critical = false, hitPoints = 165, massTons = 2400, displacement = 5000, height = 18 },
                new FFSectionSpec { modelSection = 0, label = "SternDeck",  critical = false, hitPoints = 150, massTons = 2200, displacement = 4600, height = 16, breakJointStrength = 11000 },
            },

            weapons = new List<FFWeaponSpec>
            {
                // S-400 forward field (48)
                new FFWeaponSpec { name = "FF_NAKH_S400_L_FF_48N6DM",     role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_48N6DM",
                    x = -7f, y = 16.2f, z = 55, cellColumns = 4, cellRows = 12, cellSpacing = 2.6f,
                    ammo = 24, fireInterval = 1.1f, reloadTime = 16f, ejectionVelocityZ = 15f, lockTime = 0.3f },
                new FFWeaponSpec { name = "FF_NAKH_S400_R_FF_48N6DM",     role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_48N6DM",
                    x = 7f,  y = 16.2f, z = 55, cellColumns = 4, cellRows = 12, cellSpacing = 2.6f,
                    ammo = 24, fireInterval = 1.1f, reloadTime = 16f, ejectionVelocityZ = 15f, lockTime = 0.3f },
                // UKSK amidships (48: Oniks + Kalibr)
                new FFWeaponSpec { name = "FF_NAKH_UKSK_FF_Oniks", role = "ASHM", donorPrefab = "AShM2", missileKey = "FF_Oniks",
                    x = -6f, y = 16.2f, z = -14, cellColumns = 4, cellRows = 12, cellSpacing = 2.6f,
                    ammo = 24, fireInterval = 1.8f, reloadTime = 22f, ejectionVelocityZ = 15f },
                new FFWeaponSpec { name = "FF_NAKH_UKSK_FF_Kalibr",role = "ASHM", donorPrefab = "AShM2", missileKey = "FF_Kalibr",
                    x = 6f,  y = 16.2f, z = -14, cellColumns = 4, cellRows = 12, cellSpacing = 2.6f,
                    ammo = 24, fireInterval = 1.8f, reloadTime = 22f, ejectionVelocityZ = 15f },
                // Redut aft (32)
                new FFWeaponSpec { name = "FF_NAKH_Redut_FF_9M96E2",      role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_9M96E2",
                    x = 0, y = 16.0f, z = -62, cellColumns = 8, cellRows = 4, cellSpacing = 2.4f,
                    ammo = 32, fireInterval = 1.2f, reloadTime = 14f, ejectionVelocityZ = 14f, lockTime = 0.35f },
                // Kashtan-M x4 (model geometry places them at the bow break + aft)
                new FFWeaponSpec { name = "FF_NAKH_Kashtan_FL", role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = -7.5f, y = 13.5f, z = 50, traverseRate = 280, minElevation = -12, maxElevation = 88, lockTime = 0.15f },
                new FFWeaponSpec { name = "FF_NAKH_Kashtan_FR", role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = 7.5f,  y = 13.5f, z = 50, traverseRate = 280, minElevation = -12, maxElevation = 88, lockTime = 0.15f },
                new FFWeaponSpec { name = "FF_NAKH_Kashtan_AL", role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = -10f, y = 15.8f, z = -88, yaw = 180, traverseRate = 280, minElevation = -12, maxElevation = 88, lockTime = 0.15f },
                new FFWeaponSpec { name = "FF_NAKH_Kashtan_AR", role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = 10f,  y = 15.8f, z = -88, yaw = 180, traverseRate = 280, minElevation = -12, maxElevation = 88, lockTime = 0.15f },
                // twin 130mm + ASW
                new FFWeaponSpec { name = "FF_NAKH_Gun130_1",   role = "GUN",  donorPrefab = "Gun", missileKey = null,
                    x = 0, y = 12.0f, z = 96, traverseRate = 40, minElevation = -5, maxElevation = 60, lockTime = 0.8f },
                new FFWeaponSpec { name = "FF_NAKH_Gun130_2",   role = "GUN",  donorPrefab = "Gun", missileKey = null,
                    x = 0, y = 13.2f, z = 78, traverseRate = 40, minElevation = -5, maxElevation = 60, lockTime = 0.8f },
                new FFWeaponSpec { name = "FF_NAKH_RBU_FF_Yu8",        role = "ASW",  donorPrefab = "AShM1", missileKey = "FF_Yu8",
                    x = -9f, y = 16.2f, z = 30, cellColumns = 2, cellRows = 1, ammo = 8, fireInterval = 3.5f, reloadTime = 24f, lockTime = 0.5f },
            },
        };

        // ==================================================================
        // USS HAWAII (CSGN 2030 REFIT - AEGIS STRIKE CRUISER, 240 m)
        // ==================================================================
        public static FFShipSpec Hawaii() => new FFShipSpec
        {
            id = "HAW",
            modelPath = ModModels + "/Hawaii/OBJ/Hawaii.obj",
            jsonKey = "FF_HAW",
            unitName = "USS Hawaii (CSGN 2030 Refit)",
            description =
                "A nuclear strike-cruiner concept refit for 2030: 96 Mk41-style cells forward and aft carrying " +
                "SM-6 dual-role interceptors, SM-2MR and quad-pack ESSM, twin electromagnetic railguns forward " +
                "for over-the-horizon bombardment, two RAM launchers and two CIWS, 16 VLA cells with Mk54 " +
                "MAKO lightweight ASW torpedoes, and a two-spot flight deck over the hangar. Sectioned damage " +
                "model: VLS fields cook off, the Aegis tower is a critical part, progressive flooding splits " +
                "the hull. Torpedo defenses: noisemakers + hard-kill interceptors (TorpedoShield).",
            shipType = 1,
            topSpeed = 30f,
            value = 3600f, manpower = 520f, armorTier = 6f, damageTolerance = 60f,

            hangarZ = -95f, hangarY = 14.8f, hangarWidth = 20f, hangarHeight = 9f, hangarDepth = 28f, hangarCapacity = 2,
            flightDeckZ = -112f, flightDeckY = 14.5f, flightDeckSize = 26f,
            radarZ = -12f, radarY = 47f, radarMaxRange = 34000f,
            lookoutZ = -12f, lookoutY = 30f,

            sections = new List<FFSectionSpec>
            {
                new FFSectionSpec { modelSection = 9, label = "Bow",         critical = false, hitPoints = 150, massTons = 2100, displacement = 4600, height = 16, leakThreshold = 85, pierceArmor = 480, blastArmor = 480 },
                new FFSectionSpec { modelSection = 8, label = "RailgunDeck", critical = false, hitPoints = 160, massTons = 2300, displacement = 5000, height = 16, ammoRack = true },
                new FFSectionSpec { modelSection = 7, label = "ForeVLS",     critical = false, hitPoints = 180, massTons = 2600, displacement = 5600, height = 18, ammoRack = true },
                new FFSectionSpec { modelSection = 6, label = "Bridge",      critical = true,  hitPoints = 160, massTons = 2400, displacement = 5000, height = 22 },
                new FFSectionSpec { modelSection = 5, label = "AegisTower",  critical = false, hitPoints = 165, massTons = 2500, displacement = 5200, height = 24 },
                new FFSectionSpec { modelSection = 4, label = "Midships",    critical = false, hitPoints = 175, massTons = 2700, displacement = 5800, height = 18 },
                new FFSectionSpec { modelSection = 3, label = "AftVLS",      critical = false, hitPoints = 170, massTons = 2500, displacement = 5400, height = 16, ammoRack = true },
                new FFSectionSpec { modelSection = 2, label = "HangarBlock", critical = false, hitPoints = 165, massTons = 2400, displacement = 5000, height = 18 },
                new FFSectionSpec { modelSection = 1, label = "HangarMouth", critical = false, hitPoints = 150, massTons = 2100, displacement = 4400, height = 16 },
                new FFSectionSpec { modelSection = 0, label = "SternDeck",   critical = false, hitPoints = 145, massTons = 2000, displacement = 4200, height = 16, breakJointStrength = 10000 },
            },

            weapons = new List<FFWeaponSpec>
            {
                // forward 64-cell field: SM-6 + ESSM
                new FFWeaponSpec { name = "FF_HAW_VLS_Fore_FF_SM6",  role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_SM6",
                    x = -4.5f, y = 14.6f, z = 62, cellColumns = 4, cellRows = 8, cellSpacing = 2.4f,
                    ammo = 32, fireInterval = 1.1f, reloadTime = 14f, ejectionVelocityZ = 15f, lockTime = 0.3f },
                new FFWeaponSpec { name = "FF_HAW_VLS_Fore_FF_ESSM", role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_ESSM",
                    x = 4.5f,  y = 14.6f, z = 62, cellColumns = 4, cellRows = 8, cellSpacing = 2.4f,
                    ammo = 32, fireInterval = 0.9f, reloadTime = 12f, ejectionVelocityZ = 15f, lockTime = 0.25f },
                // aft 32-cell field: SM-2 + VLA ASW
                new FFWeaponSpec { name = "FF_HAW_VLS_Aft_FF_SM2",  role = "SAM",  donorPrefab = "AShM1", missileKey = "FF_SM2",
                    x = -4.5f, y = 14.2f, z = -52, cellColumns = 4, cellRows = 4, cellSpacing = 2.4f,
                    ammo = 16, fireInterval = 1.2f, reloadTime = 14f, ejectionVelocityZ = 14f, lockTime = 0.35f },
                new FFWeaponSpec { name = "FF_HAW_VLS_Aft_VLA_FF_Mk54",  role = "ASW",  donorPrefab = "AShM1", missileKey = "FF_Mk54",
                    x = 4.5f,  y = 14.2f, z = -52, cellColumns = 4, cellRows = 4, cellSpacing = 2.4f,
                    ammo = 16, fireInterval = 2.5f, reloadTime = 20f, ejectionVelocityZ = 14f, lockTime = 0.5f },
                // railguns + RAM + CIWS
                new FFWeaponSpec { name = "FF_HAW_Railgun_P",    role = "RAILGUN", donorPrefab = "Gun", missileKey = null,
                    x = -4.6f, y = 12.6f, z = 92, traverseRate = 30, minElevation = 0, maxElevation = 55, lockTime = 1.2f },
                new FFWeaponSpec { name = "FF_HAW_Railgun_S",    role = "RAILGUN", donorPrefab = "Gun", missileKey = null,
                    x = 4.6f,  y = 12.6f, z = 92, traverseRate = 30, minElevation = 0, maxElevation = 55, lockTime = 1.2f },
                new FFWeaponSpec { name = "FF_HAW_RAM_Fwd_FF_RIM116",      role = "RAM",  donorPrefab = "R-45", missileKey = "FF_RIM116",
                    x = 0, y = 16.4f, z = 34, ammo = 21, fireInterval = 0.7f, reloadTime = 12f, lockTime = 0.25f },
                new FFWeaponSpec { name = "FF_HAW_RAM_Aft_FF_RIM116",      role = "RAM",  donorPrefab = "R-45", missileKey = "FF_RIM116",
                    x = 0, y = 15.6f, z = -76, yaw = 180, ammo = 21, fireInterval = 0.7f, reloadTime = 12f, lockTime = 0.25f },
                new FFWeaponSpec { name = "FF_HAW_CIWS_Port",    role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = -11f, y = 17.0f, z = 20, traverseRate = 320, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
                new FFWeaponSpec { name = "FF_HAW_CIWS_Stbd",    role = "CIWS", donorPrefab = "CIWS", missileKey = null,
                    x = 11f,  y = 15.0f, z = -70, yaw = 180, traverseRate = 320, minElevation = -12, maxElevation = 88, lockTime = 0.1f },
            },
        };

        public static List<FFShipSpec> All()
        {
            return new List<FFShipSpec> { Type055(), Type054A(), Nakhimov(), Hawaii() };
        }
    }
}
