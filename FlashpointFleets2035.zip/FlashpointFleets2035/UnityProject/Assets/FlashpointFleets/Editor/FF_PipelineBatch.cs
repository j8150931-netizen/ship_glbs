// ============================================================================
// Flashpoint Fleets 2035 - FF_PipelineBatch.cs
// Headless batch entry points (Unity -batchmode -executeMethod ...).
// Keeps interactive dialogs out of the pipeline; logs progress instead.
// ============================================================================

using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace FlashpointFleets.EditorTools
{
    public static class FF_PipelineBatch
    {
        public static void RunAll()
        {
            Debug.Log("[FF][BATCH] RunAll start");
            BuildShipsBatch();
            DumpGameAssetsBatch();
            BuildNobpBatch();
            Debug.Log("[FF][BATCH] RunAll complete");
        }

        public static void BuildShipsBatch()
        {
            int ok = 0, total = 0;
            foreach (var spec in FF_ShipSpec.All())
            {
                total++;
                try
                {
                    var prefab = FF_PrefabFactory.Build(spec);
                    if (prefab != null) ok++;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"[FF][BATCH] FAILED {spec.id}: {e}");
                }
            }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log($"[FF][BATCH] BuildShipsBatch done: {ok}/{total} ships built.");
        }

        public static void DumpGameAssetsBatch()
        {
            try { FF_AssetResolver.DumpGameAssets(); }
            catch (System.Exception e) { Debug.LogError($"[FF][BATCH] DumpGameAssets failed: {e}"); }
        }

        public static void BuildNobpBatch()
        {
            var outDir = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "..", "FlashpointFleets2035_dist"));
            Directory.CreateDirectory(outDir);

            // Blueprinter.ModBuilder lives in the package asmdef, which predefined
            // assemblies cannot reference directly - invoke it via reflection.
            System.Type mbType = null;
            foreach (var asm in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                mbType = asm.GetType("Blueprinter.ModBuilder");
                if (mbType != null) break;
            }
            if (mbType == null)
            {
                Debug.LogError("[FF][BATCH] Blueprinter.ModBuilder type not found - is the Blueprinter package loaded?");
                return;
            }
            var buildMethod = mbType.GetMethod("Build", BindingFlags.Public | BindingFlags.Static);
            if (buildMethod == null)
            {
                Debug.LogError("[FF][BATCH] Blueprinter.ModBuilder.Build method not found");
                return;
            }
            buildMethod.Invoke(null, new object[] { "FlashpointFleets2035", "Flashpoint Fleets 2035", "0.9.0", outDir });
            Debug.Log($"[FF][BATCH] BuildNobpBatch done -> {outDir}");
        }
    }
}
