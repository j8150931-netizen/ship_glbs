// ============================================================================
// Flashpoint Fleets 2035 - FF_Types.cs
// Compile-time-free access to Nuclear Option game types.
//
// The game assemblies are imported by Blueprinter as plugins (Packages/
// nuclearoption) and are LOADED in the editor domain, but they must not be
// compile-time referenced: a game-assembly reference pollutes every package
// assembly that compiles against it (global-namespace DebugUI/PlayerSettings
// collisions in URP/Burst/Rider), and asmdef precompiledReferences do not
// match explicitly-referenced package plugins in 2022.3.
//
// So - exactly like Blueprinter's own FFDump tool - the FF editor scripts
// resolve game types by name from the loaded assemblies at editor runtime.
// ============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace FlashpointFleets.EditorTools
{
    internal static class FF_Types
    {
        static readonly Dictionary<string, Type> cache = new Dictionary<string, Type>();

        internal static readonly Type Ship               = Get("Ship");
        internal static readonly Type ShipPart           = Get("ShipPart");
        internal static readonly Type UnitPart           = Get("UnitPart");
        internal static readonly Type MissileLauncher    = Get("MissileLauncher");
        internal static readonly Type Turret             = Get("Turret");
        internal static readonly Type Radar              = Get("Radar");
        internal static readonly Type TargetDetector     = Get("TargetDetector");
        internal static readonly Type FireControl        = Get("FireControl");
        internal static readonly Type ShipAI             = Get("ShipAI");
        internal static readonly Type UnitCommand        = Get("UnitCommand");
        internal static readonly Type ShipNetworkTransform = Get("NuclearOption.NetworkTransforms.ShipNetworkTransform");
        internal static readonly Type SetGlobalParticles = Get("SetGlobalParticles");
        internal static readonly Type Capture            = Get("Capture");
        internal static readonly Type Airbase            = Get("Airbase");
        internal static readonly Type Rearmer            = Get("Rearmer");
        internal static readonly Type Hangar             = Get("Hangar");
        internal static readonly Type ShipPropulsion     = Get("ShipPropulsion");
        internal static readonly Type ShipDefinition     = Get("ShipDefinition");
        internal static readonly Type AircraftDefinition = Get("AircraftDefinition");
        internal static readonly Type MissileDefinition  = Get("MissileDefinition");
        internal static readonly Type WeaponMount        = Get("WeaponMount");
        internal static readonly Type Gun                = Get("Gun");
        internal static readonly Type NetworkIdentity    = Get("Mirage.NetworkIdentity");

        internal static Type Get(string fullName)
        {
            Type t;
            if (cache.TryGetValue(fullName, out t)) return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try { t = asm.GetType(fullName, false); } catch { t = null; }
                if (t != null) break;
            }
            cache[fullName] = t;
            if (t == null) Debug.LogWarning("[FF] Game type not found in loaded assemblies: " + fullName);
            return t;
        }

        // Reflection helpers shared by the editor scripts -------------------
        internal static object GetProp(object obj, string name)
        {
            if (obj == null) return null;
            var t = obj.GetType();
            const BindingFlags F = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            var f = t.GetField(name, F);
            if (f != null) return f.GetValue(obj);
            var p = t.GetProperty(name, F);
            return p != null ? p.GetValue(obj, null) : null;
        }
    }
}
