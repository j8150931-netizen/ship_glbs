// ============================================================================
// Flashpoint Fleets 2035 - FF_ShipBuilder.cs
// Menu-driven entry points. Everything is one click:
//   FF / Build All Ships     - builds the 4 ship prefabs + definitions
//   FF / Validate Mod        - checks the mod folder for completeness
//   FF / Dump Game Assets    - discovery report for donor-name verification
// Then use Blueprinter > Mod Builder to produce the .nobp.
// ============================================================================

using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace FlashpointFleets.EditorTools
{
    public static class FF_ShipBuilder
    {
        [MenuItem("FF/Build All Ships")]
        public static void BuildAll()
        {
            var specs = FF_ShipSpec.All();
            int ok = 0;
            foreach (var spec in specs)
            {
                try
                {
                    var prefab = FF_PrefabFactory.Build(spec);
                    if (prefab != null) ok++;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"[FF] FAILED {spec.id}: {e}");
                }
            }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("Flashpoint Fleets",
                $"Built {ok}/{specs.Count} ships.\n\nNext: Blueprinter > Mod Builder > select " +
                "'FlashpointFleets2035' > Build Mod.", "OK");
        }

        [MenuItem("FF/Build Ship/Type 055 Renhai")] public static void B1() => BuildOne("T055");
        [MenuItem("FF/Build Ship/Type 054A Jiangkai II")] public static void B2() => BuildOne("T054A");
        [MenuItem("FF/Build Ship/Admiral Nakhimov 2035")] public static void B3() => BuildOne("NAKH");
        [MenuItem("FF/Build Ship/USS Hawaii CSGN 2030")] public static void B4() => BuildOne("HAW");

        static void BuildOne(string id)
        {
            var spec = FF_ShipSpec.All().First(s => s.id == id);
            try
            {
                FF_PrefabFactory.Build(spec);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
            catch (System.Exception e) { Debug.LogError($"[FF] FAILED {id}: {e}"); }
        }

        [MenuItem("FF/Validate Mod")]
        public static void Validate()
        {
            var issues = new System.Collections.Generic.List<string>();
            var root = FF_ShipSpec.ModRoot;

            if (!Directory.Exists(root)) issues.Add("Mod folder missing: " + root);
            if (!File.Exists(root + "/ModInfo.json")) issues.Add("ModInfo.json missing");
            foreach (var spec in FF_ShipSpec.All())
            {
                if (!File.Exists(spec.modelPath))
                    issues.Add($"{spec.id}: model missing at {spec.modelPath}");
                else if (AssetDatabase.LoadAssetAtPath<GameObject>(spec.modelPath) == null)
                    issues.Add($"{spec.id}: model not importable: {spec.modelPath}");
                var prefabPath = root + $"/Prefabs/FF_{spec.id}.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
                if (prefab == null) { issues.Add($"{spec.id}: prefab not built yet"); continue; }
                var ship = prefab.GetComponent<Ship>();
                if (ship == null) issues.Add($"{spec.id}: prefab has no Ship component");
                var def = AssetDatabase.LoadAssetAtPath<ShipDefinition>(
                    root + $"/Definitions/FF_{spec.id}_Definition.asset");
                if (def == null) issues.Add($"{spec.id}: ShipDefinition asset missing");
                var launchers = prefab.GetComponentsInChildren<MissileLauncher>(true);
                var turrets = prefab.GetComponentsInChildren<Turret>(true);
                var parts = prefab.GetComponentsInChildren<ShipPart>(true);
                var hangar = prefab.GetComponentsInChildren<Hangar>(true);
                Debug.Log($"[FF] {spec.id}: {launchers.Length} launchers, {turrets.Length} turrets, " +
                          $"{parts.Length} ship parts, {hangar.Length} hangars");
                if (launchers.Length == 0) issues.Add($"{spec.id}: no missile launchers (donor resolution failed?)");
                if (parts.Length < 5) issues.Add($"{spec.id}: too few ShipParts");
            }

            // plugin DLL check
            var dllOk = System.Type.GetType("FlashpointFleets.FFNoisemakerRack, FlashpointFleets2035") != null;
            if (!dllOk) issues.Add("Plugin DLL (FlashpointFleets2035.dll) not present in Assets/Plugins - " +
                "noisemakers/weapon swapping will be missing until built (see docs/BUILD.md).");

            if (issues.Count == 0)
                EditorUtility.DisplayDialog("FF Validate", "All checks passed. Ready for Blueprinter > Mod Builder.", "OK");
            else
            {
                Debug.LogWarning("[FF] Validation issues:\n" + string.Join("\n", issues));
                EditorUtility.DisplayDialog("FF Validate", issues.Count + " issue(s) - see Console.", "OK");
            }
        }
    }
}
