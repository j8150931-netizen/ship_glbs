// ============================================================================
// Flashpoint Fleets 2035 - WeaponCatalog.cs
// The complete Flashpoint missile catalog.
//
// Every entry is cloned at runtime from a vanilla missile GameObject
// (donor), then re-statted - the exact, battle-proven technique used by
// SonPamungkas' torpedo mod (client-side, multiplayer-safe, no asset
// redistribution). Donor names are vanilla prefab names; "SAM" donors
// resolve through a fallback chain because vanilla SAM prefab names vary
// by game version (verify with the FF/Dump Game Assets report).
// ============================================================================

using System.Collections.Generic;

namespace FlashpointFleets
{
    public class FFWeaponDef
    {
        public string key;              // "FF_HHQ9B" - unique
        public string donor;            // vanilla missile prefab name (primary)
        public string[] donorFallbacks; // tried in order if primary missing
        public string displayName;      // "HHQ-9B"
        public string shortName;        // "HQ-9B"
        public string description;
        public float mass = 300f;
        public float cost = 25f;
        public float speedMult = 1f;    // topSpeed/thrust multiplier (thrust = sqrt)
        public float burnTimeMult = 1f; // range
        public float blastMult = 1f;
        public float pierceBonus = 0f;
        public float skimAltitude = -1f;// >= 0 -> sea-skimmer terminal profile (meters)
        public bool antiAir;
        public bool antiMissile;
        public bool antiSurface;
    }

    public static class WeaponCatalog
    {
        // SAM donors: vanilla names differ between versions - chain covers
        // the common ones; AShM1 is the guaranteed-fallback workhorse.
        static readonly string[] SamDonors = { "SAM1", "SAM2", "SAM3", "R-45", "R45", "AShM1" };
        static readonly string[] AshmDonors = { "AShM2", "AShM1" };
        static readonly string[] CruiseDonors = { "CruiseMissile1", "CruiseMissile20kt", "AShM1" };

        public static readonly List<FFWeaponDef> All = new List<FFWeaponDef>
        {
            // ---------------- PLAN ----------------
            new FFWeaponDef {
                key = "FF_HHQ9B", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "HHQ-9B", shortName = "HQ-9B",
                description = "PLAN long-range fleet air-defense interceptor. Cold-launched from the Type 055's " +
                              "universal VLS, the HHQ-9B combines a powerful seeker with an extended-burn motor " +
                              "for area denial out past the radar horizon.",
                mass = 1300f, cost = 95f, speedMult = 0.96f, burnTimeMult = 1.45f, blastMult = 0.85f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_HHQ16", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "HHQ-16FE", shortName = "HQ-16",
                description = "Medium-range SAM for the Type 054A's 32-cell VLS. Fast to lock, ruthless against " +
                              "sea-skimmers and glide weapons inside 40 km.",
                mass = 620f, cost = 45f, speedMult = 1.02f, burnTimeMult = 1.0f, blastMult = 0.55f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_HHQ10", donor = "R-45", donorFallbacks = SamDonors,
                displayName = "HHQ-10", shortName = "HQ-10",
                description = "Rolling-airframe point-defense missile - the PLAN's answer to terminal-stage " +
                              "missiles and guided bombs. 24-round launcher over the Type 055's hangar.",
                mass = 90f, cost = 18f, speedMult = 1.1f, burnTimeMult = 0.55f, blastMult = 0.3f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_YJ18A", donor = "AShM1", donorFallbacks = AshmDonors,
                displayName = "YJ-18A", shortName = "YJ-18",
                description = "The Type 055's ship-killer: cruise out, then a supersonic sprint and a " +
                              "radar-hugging terminal run that gives CIWS crews nightmares.",
                mass = 1500f, cost = 120f, speedMult = 1.15f, burnTimeMult = 1.25f, blastMult = 1.35f,
                pierceBonus = 800f, skimAltitude = 6f, antiSurface = true
            },
            new FFWeaponDef {
                key = "FF_YJ83K", donor = "AShM1", donorFallbacks = AshmDonors,
                displayName = "YJ-83K", shortName = "YJ-83",
                description = "Subsonic sea-skimming anti-ship missile in inclined canisters - the Type 054A's " +
                              "eight-tube punch. Cheap enough to salvo.",
                mass = 715f, cost = 55f, speedMult = 0.88f, burnTimeMult = 1.1f, blastMult = 0.9f,
                pierceBonus = 400f, skimAltitude = 8f, antiSurface = true
            },
            new FFWeaponDef {
                key = "FF_Yu8", donor = "AShM1", donorFallbacks = AshmDonors,
                displayName = "Yu-8 ASW", shortName = "YU-8",
                description = "Lightweight anti-submarine/anti-torpedo weapon fired from ship tubes. Runs shallow; " +
                              "with SonPamungkas' Torpedo mod installed it converts to a true guided torpedo, " +
                              "otherwise it behaves as a short-range ASW standoff rocket.",
                mass = 210f, cost = 20f, speedMult = 0.8f, burnTimeMult = 0.6f, blastMult = 1.1f,
                antiSurface = true
            },

            // ---------------- RUSSIA (Nakhimov 2035) ----------------
            new FFWeaponDef {
                key = "FF_48N6DM", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "48N6DM (S-400)", shortName = "48N6",
                description = "Navalized S-400 long-range interceptor from Admiral Nakhimov's forward field. " +
                              "Enormous burn time; nothing escapes high.",
                mass = 1800f, cost = 110f, speedMult = 1.12f, burnTimeMult = 1.6f, blastMult = 1.0f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_9M96E2", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "9M96E2 (Redut)", shortName = "9M96",
                description = "Redut VLS medium-range interceptor - active-radar, agile, quad-packable, " +
                              "the Nakhimov's inner air-defense ring.",
                mass = 420f, cost = 40f, speedMult = 1.05f, burnTimeMult = 0.9f, blastMult = 0.5f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_Oniks", donor = "AShM1", donorFallbacks = AshmDonors,
                displayName = "P-800 Oniks", shortName = "P-800",
                description = "Supersonic ramjet sea-skimmer from the UKSK cells. Mach 2+ at wave-top height - " +
                              "reaction windows are measured in seconds.",
                mass = 2500f, cost = 160f, speedMult = 1.45f, burnTimeMult = 1.15f, blastMult = 1.5f,
                pierceBonus = 1500f, skimAltitude = 5f, antiSurface = true
            },
            new FFWeaponDef {
                key = "FF_Kalibr", donor = "CruiseMissile1", donorFallbacks = CruiseDonors,
                displayName = "3M-54 Kalibr", shortName = "KLBR",
                description = "The cruiser's land-attack and anti-ship workhorse: low, slow, far - then the " +
                              "terminal sprint. Twin-role UKSK loadout alongside the Oniks.",
                mass = 1600f, cost = 105f, speedMult = 0.92f, burnTimeMult = 1.5f, blastMult = 1.3f,
                pierceBonus = 900f, skimAltitude = 10f, antiSurface = true
            },

            // ---------------- USA (USS Hawaii) ----------------
            new FFWeaponDef {
                key = "FF_SM6", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "RIM-174 SM-6", shortName = "SM-6",
                description = "The Aegis cruiser's dual-role sword: area air defense today, over-the-horizon " +
                              "ship strike tomorrow. Active seeker, long legs.",
                mass = 660f, cost = 100f, speedMult = 1.08f, burnTimeMult = 1.35f, blastMult = 0.8f,
                antiAir = true, antiMissile = true, antiSurface = true
            },
            new FFWeaponDef {
                key = "FF_SM2", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "RIM-66 SM-2MR", shortName = "SM-2",
                description = "Classic Aegis medium-range SAM - semi-active, salvo-friendly, always ready.",
                mass = 510f, cost = 65f, speedMult = 1.0f, burnTimeMult = 1.05f, blastMult = 0.65f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_ESSM", donor = "SAM1", donorFallbacks = SamDonors,
                displayName = "RIM-162 ESSM", shortName = "ESSM",
                description = "Evolved Sea Sparrow - quad-packed, high-agility point/medium defense. " +
                              "The CIWS's favorite teammate.",
                mass = 230f, cost = 38f, speedMult = 1.15f, burnTimeMult = 0.75f, blastMult = 0.4f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_RIM116", donor = "R-45", donorFallbacks = SamDonors,
                displayName = "RIM-116 RAM", shortName = "RAM",
                description = "Rolling Airframe Missile launchers, bow and stern - last-ditch terminal defense " +
                              "with passive RF/IR dual guidance.",
                mass = 74f, cost = 15f, speedMult = 1.2f, burnTimeMult = 0.5f, blastMult = 0.3f,
                antiAir = true, antiMissile = true
            },
            new FFWeaponDef {
                key = "FF_Mk54", donor = "AShM1", donorFallbacks = AshmDonors,
                displayName = "Mk54 MAKO (VLA)", shortName = "MAKO",
                description = "Vertical-launch ASW carrying the Mk54 lightweight torpedo (modeled on the SCT-350 " +
                              "Mako). With the Torpedo mod installed it swims; without it, it brackets the " +
                              "datum with a shallow standoff attack.",
                mass = 280f, cost = 30f, speedMult = 0.85f, burnTimeMult = 0.65f, blastMult = 1.15f,
                antiSurface = true
            },
        };

        public static FFWeaponDef Find(string key)
        {
            for (int i = 0; i < All.Count; i++)
                if (All[i].key == key) return All[i];
            return null;
        }

        /// <summary>Sea-skimmer keys (used by SeaSkimmer.cs terminal patches).</summary>
        public static bool IsSeaSkimmer(string missileName)
        {
            for (int i = 0; i < All.Count; i++)
                if (All[i].skimAltitude >= 0f && All[i].key == missileName) return true;
            return false;
        }

        public static float SkimAltitude(string missileName)
        {
            for (int i = 0; i < All.Count; i++)
                if (All[i].skimAltitude >= 0f && All[i].key == missileName) return All[i].skimAltitude;
            return -1f;
        }
    }
}
