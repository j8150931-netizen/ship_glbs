// ============================================================================
// Flashpoint Fleets 2035 - Plugin.cs  (main BepInEx plugin)
//
// Responsibilities:
//   * load-time weapon catalog creation (HHQ / YJ / SM / Kalibr / ... clones
//     built from vanilla missiles exactly like SonPamungkas' torpedo mod)
//   * wiring the new weapons onto the FF_* ship launchers
//   * sea-skimmer terminal guidance for anti-ship missiles
//   * torpedo noisemaker racks on every FF ship
//
// The ships themselves (meshes, damage sections, turrets, hangars) come from
// the FlashpointFleets2035.nobp asset bundle, loaded by Nikkorap's
// Blueprinter. This DLL only needs to sit next to it in BepInEx/plugins.
// ============================================================================

using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace FlashpointFleets
{
    public static class MyPluginInfo
    {
        public const string PLUGIN_GUID = "com.flashpoint.fleets2035";
        public const string PLUGIN_NAME = "Flashpoint Fleets 2035";
        public const string PLUGIN_VERSION = "0.9.0";

        public const string BLUEPRINTER_GUID = "com.nikkorap.blueprinter";
        public const string TORPEDO_MOD_GUID = "com.sonpamungkas.torpedo"; // soft dependency
        public const string GOTH_GUID = "neutral.gothmommy";               // soft dependency
    }

    [BepInPlugin(MyPluginInfo.PLUGIN_GUID, MyPluginInfo.PLUGIN_NAME, MyPluginInfo.PLUGIN_VERSION)]
    [BepInDependency(MyPluginInfo.BLUEPRINTER_GUID)]
    [BepInDependency(MyPluginInfo.TORPEDO_MOD_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(MyPluginInfo.GOTH_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    public class Plugin : BaseUnityPlugin
    {
        internal static ManualLogSource Log;
        internal static Harmony Harmony;

        // ----- config -----
        internal static ConfigEntry<bool> CfgNewWeapons;
        internal static ConfigEntry<bool> CfgSeaSkimmers;
        internal static ConfigEntry<bool> CfgNoisemakers;
        internal static ConfigEntry<float> CfgNoisemakerRadius;
        internal static ConfigEntry<float> CfgNoisemakerCooldown;
        internal static ConfigEntry<bool> CfgVerboseWeapons;

        void Awake()
        {
            Log = Logger;
            CfgNewWeapons = Config.Bind("Weapons", "CreateFlashpointMissiles", true,
                "Create the Flashpoint missile catalog (HHQ-9B, HHQ-16, YJ-18A, SM-6, ESSM, Kalibr, ... " +
                "and wire them onto the ship launchers). Disable to sail the ships with pure vanilla weapons.");
            CfgSeaSkimmers = Config.Bind("Weapons", "SeaSkimmerTerminalProfile", true,
                "YJ-18A / YJ-83K / Oniks / Kalibr drop to a radar-hugging sea-skim run on terminal approach.");
            CfgNoisemakers = Config.Bind("TorpedoDefense", "AutoNoisemakers", true,
                "FF ships automatically launch acoustic noisemaker buoys when a torpedo closes inside the threat radius.");
            CfgNoisemakerRadius = Config.Bind("TorpedoDefense", "NoisemakerThreatRadius", 2200f,
                "Distance in meters at which an inbound torpedo triggers a noisemaker salvo.");
            CfgNoisemakerCooldown = Config.Bind("TorpedoDefense", "NoisemakerCooldown", 22f,
                "Seconds between noisemaker salvos per ship.");
            CfgVerboseWeapons = Config.Bind("Debug", "VerboseWeaponSetup", false,
                "Log every cloned missile and every launcher re-wire (large log).");

            Harmony = new Harmony(MyPluginInfo.PLUGIN_GUID);
            Harmony.PatchAll();

            Log.LogInfo($"Flashpoint Fleets 2035 {MyPluginInfo.PLUGIN_VERSION} loaded. " +
                        $"Torpedo mod detected: {HasTorpedoMod}; GOTH detected: {HasGoth}.");
        }

        void OnDestroy()
        {
            Harmony?.UnpatchSelf();
        }

        internal static bool HasTorpedoMod =>
            BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(MyPluginInfo.TORPEDO_MOD_GUID);
        internal static bool HasGoth =>
            BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(MyPluginInfo.GOTH_GUID);
    }
}
