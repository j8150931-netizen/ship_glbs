// ============================================================================
// Flashpoint Fleets 2035 - SeaSkimmer.cs
// Terminal sea-skim profile for YJ-18A / YJ-83K / P-800 Oniks / Kalibr:
// once inside the terminal window, the cruise seeker's altitude target is
// pulled down to the missile's skim altitude (5-10 m) so the weapon rides
// the wave-tops into the target's belt line - the classic CIWS nightmare.
//
// Implemented as a Harmony POSTFIX on Missile.SetAimpoint, only touching
// missiles whose names match the Flashpoint catalog - zero interference
// with vanilla missiles, other weapon packs, or the Torpedo mod (which
// uses a Prefix on a different name set).
// ============================================================================

using System;
using HarmonyLib;
using UnityEngine;

namespace FlashpointFleets
{
    [HarmonyPatch(typeof(Missile), "SetAimpoint")]
    public static class Missile_SetAimpoint_SeaSkim_Patch
    {
        private static readonly AccessTools.FieldRef<Missile, MissileSeeker> SeekerRef =
            AccessTools.FieldRefAccess<Missile, MissileSeeker>("seeker");
        private static readonly AccessTools.FieldRef<OpticalSeekerCruiseMissile, float> AltitudeTargetRef =
            AccessTools.FieldRefAccess<OpticalSeekerCruiseMissile, float>("altitudeTarget");
        private static readonly AccessTools.FieldRef<OpticalSeekerCruiseMissile, bool> TerminalModeRef =
            AccessTools.FieldRefAccess<OpticalSeekerCruiseMissile, bool>("terminalMode");

        [HarmonyPostfix]
        public static void Postfix(Missile __instance)
        {
            if (!Plugin.CfgSeaSkimmers.Value || __instance == null) return;
            var name = __instance.name;
            if (string.IsNullOrEmpty(name) || !WeaponCatalog.IsSeaSkimmer(name)) return;

            try
            {
                var seeker = SeekerRef(__instance);
                var cruise = seeker as OpticalSeekerCruiseMissile;
                if (cruise == null) return;

                var skim = WeaponCatalog.SkimAltitude(name);
                var inTerminal = TerminalModeRef(cruise);
                var alt = AltitudeTargetRef(cruise);
                if (inTerminal)
                {
                    // terminal: hug the deck
                    if (alt > skim) AltitudeTargetRef(cruise) = skim;
                }
                else if (alt > skim * 3f)
                {
                    // cruise phase: keep a conservative mid-altitude, then drop
                    // (terminal block above catches the final run)
                }
            }
            catch (Exception e)
            {
                // never let a guidance tweak kill a missile update
                Plugin.Log.LogWarning("[FF] sea-skim postfix issue: " + e.Message);
            }
        }
    }
}
