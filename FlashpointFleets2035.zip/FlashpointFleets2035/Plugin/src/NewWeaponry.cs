// ============================================================================
// Flashpoint Fleets 2035 - NewWeaponry.cs
// Runtime creation of the missile catalog + wiring onto the FF_* ship
// launchers. Follows SonPamungkas' torpedo-mod cloning pattern exactly:
//   * clone the donor missile GameObject (HideAndDontSave, NetworkReset)
//   * re-stat motors / warhead / definition / WeaponInfo
//   * register in the Encyclopedia
//   * swap onto our launchers (identified by "FF_" name prefix + catalog key)
// Multiplayer-safe: no asset redistribution, prefab hashes re-assigned.
// ============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Mirage;
using UnityEngine;

namespace FlashpointFleets
{
    public static class NewWeaponry
    {
        public static readonly Dictionary<string, GameObject> Prefabs = new Dictionary<string, GameObject>();
        public static readonly Dictionary<string, WeaponInfo> Infos = new Dictionary<string, WeaponInfo>();

        static bool _done;

        // ------------------------------------------------------------------
        // Encyclopedia.AfterLoad (runs once the game's own catalog is ready)
        // ------------------------------------------------------------------
        [HarmonyPatch(typeof(Encyclopedia), "AfterLoad", new Type[] { })]
        [HarmonyPriority(Priority.Last)]
        public static class Encyclopedia_AfterLoad_FF_Patch
        {
            [HarmonyPrefix]
            public static void Prefix(Encyclopedia __instance) => TryCreate(__instance);

            [HarmonyPostfix]
            public static void Postfix(Encyclopedia __instance) => TryCreate(__instance);
        }

        static void TryCreate(Encyclopedia enc)
        {
            if (_done || !Plugin.CfgNewWeapons.Value) return;
            try
            {
                CreateAll(enc);
                _done = true;
            }
            catch (Exception e)
            {
                Plugin.Log.LogError("[FF] weapon catalog creation failed: " + e);
            }
        }

        // ------------------------------------------------------------------
        public static void CreateAll(Encyclopedia enc)
        {
            foreach (var def in WeaponCatalog.All)
            {
                if (Prefabs.ContainsKey(def.key)) continue;
                var clone = CreateMissile(enc, def);
                if (clone != null)
                    Plugin.Log.LogInfo($"[FF] missile ready: {def.displayName} ({def.key}, donor {def.donor})");
            }
            WireLaunchers();
        }

        static GameObject CreateMissile(Encyclopedia enc, FFWeaponDef def)
        {
            var donorGo = FindDonor(def);
            if (donorGo == null)
            {
                Plugin.Log.LogWarning($"[FF] no donor missile found for {def.key} (tried '{def.donor}' + fallbacks) - skipping.");
                return null;
            }

            var donorMissile = donorGo.GetComponent<Missile>();
            var donorInfo = donorMissile != null ? donorMissile.GetWeaponInfo() : null;
            var donorDef = donorMissile != null ? donorMissile.definition as MissileDefinition : null;
            if (donorMissile == null || donorInfo == null || donorDef == null)
            {
                Plugin.Log.LogWarning($"[FF] donor '{donorGo.name}' unusable for {def.key} - skipping.");
                return null;
            }

            var go = CleanClone(donorGo, def.key);
            var missile = go.GetComponent<Missile>();
            ApplyStats(missile, def);

            var md = UnityEngine.Object.Instantiate(donorDef);
            md.name = def.key;
            md.jsonKey = def.key;
            md.unitName = def.displayName;
            md.description = def.description;
            md.unitPrefab = go;
            md.dontAutomaticallyAddToEncyclopedia = false;
            md.radarSize = Mathf.Max(donorDef.radarSize * 0.8f, 0.0015f);
            Traverse.Create(missile).Field("definition").SetValue(md);

            var info = UnityEngine.Object.Instantiate(donorInfo);
            info.name = def.key + "_info";
            info.weaponName = def.displayName;
            info.shortName = def.shortName;
            info.description = def.description;
            info.massPerRound = def.mass;
            info.costPerRound = def.cost;
            info.weaponPrefab = go;
            info.blastDamage *= def.blastMult;
            info.pierceDamage += def.pierceBonus;
            Traverse.Create(missile).Field("info").SetValue(info);

            var by = Traverse.Create(missile).Field("blastYield");
            if (by != null) by.SetValue(by.GetValue<float>() * def.blastMult);
            var pd = Traverse.Create(missile).Field("pierceDamage");
            if (pd != null) pd.SetValue(pd.GetValue<float>() + def.pierceBonus);

            if (!enc.missiles.Contains(md)) enc.missiles.Add(md);

            Prefabs[def.key] = go;
            Infos[def.key] = info;
            return go;
        }

        static GameObject FindDonor(FFWeaponDef def)
        {
            var names = new List<string> { def.donor };
            if (def.donorFallbacks != null) names.AddRange(def.donorFallbacks);
            foreach (var n in names)
            {
                var go = Resources.FindObjectsOfTypeAll<GameObject>()
                    .FirstOrDefault(g => g != null && g.transform.parent == null &&
                                         string.Equals(g.name, n, StringComparison.OrdinalIgnoreCase) &&
                                         g.GetComponent<Missile>() != null);
                if (go != null) return go;
            }
            return null;
        }

        static void ApplyStats(Missile missile, FFWeaponDef def)
        {
            // motor scaling (same physics as the torpedo mod):
            //   topSpeed & burn time scale linearly, thrust with the sqrt
            var motors = Traverse.Create(missile).Field("motors");
            if (motors != null && motors.GetValue() is Array arr)
            {
                var thrustMult = Mathf.Sqrt(Mathf.Max(def.speedMult, 0.05f));
                foreach (var m in arr)
                {
                    if (m == null) continue;
                    var t = Traverse.Create(m);
                    t.Field("thrust").SetValue(t.Field("thrust").GetValue<float>() * thrustMult);
                    t.Field("topSpeed").SetValue(t.Field("topSpeed").GetValue<float>() * def.speedMult);
                    t.Field("burnTime").SetValue(t.Field("burnTime").GetValue<float>() * def.burnTimeMult);
                }
            }
        }

        // ------------------------------------------------------------------
        // Wire catalog missiles onto our launchers. Launcher names follow
        // FF/<ship>/<whatever>/<catalogKey> (see FF_ShipSpec.cs) - matching
        // is Contains() on the unique key so renames stay cheap.
        // ------------------------------------------------------------------
        public static void WireLaunchers()
        {
            int wired = 0;
            var launchers = Resources.FindObjectsOfTypeAll<MissileLauncher>();
            foreach (var launcher in launchers)
            {
                if (launcher == null || launcher.name == null || !launcher.name.StartsWith("FF_", StringComparison.Ordinal))
                    continue;
                foreach (var def in WeaponCatalog.All)
                {
                    if (!launcher.name.Contains(def.key)) continue;
                    GameObject prefab;
                    WeaponInfo info;
                    if (!Prefabs.TryGetValue(def.key, out prefab) || !Infos.TryGetValue(def.key, out info))
                        break; // creation failed for this key - donor missing; keep vanilla loadout
                    var t = Traverse.Create(launcher);
                    t.Field("info").SetValue(info);
                    t.Field("missile").SetValue(prefab);
                    wired++;
                    if (Plugin.CfgVerboseWeapons.Value)
                        Plugin.Log.LogInfo($"[FF] wired {launcher.name} -> {def.displayName}");
                    break;
                }
            }
            Plugin.Log.LogInfo($"[FF] launcher wiring complete: {wired} launcher(s) converted to Flashpoint missiles.");

            // Re-wire again when ships spawn later (prefabs instantiate lazily).
            if (!_rewireHooked)
            {
                _rewireHooked = true;
                // WeaponManager.Awake postfix keeps aircraft-side mounts current
                // (mirrors the torpedo mod's registration pattern).
            }
        }

        static bool _rewireHooked;

        [HarmonyPatch(typeof(WeaponManager), "Awake")]
        [HarmonyPriority(Priority.Last)]
        public static class WeaponManager_Awake_FF_Patch
        {
            [HarmonyPostfix]
            public static void Postfix(WeaponManager __instance)
            {
                try { WireLaunchersOn(__instance ? __instance.gameObject : null); }
                catch (Exception e) { Plugin.Log.LogWarning("[FF] WeaponManager rewire failed: " + e.Message); }
            }
        }

        static void WireLaunchersOn(GameObject go)
        {
            if (go == null) return;
            foreach (var launcher in go.GetComponentsInChildren<MissileLauncher>(true))
            {
                if (launcher == null || launcher.name == null ||
                    !launcher.name.StartsWith("FF_", StringComparison.Ordinal)) continue;
                foreach (var def in WeaponCatalog.All)
                {
                    if (!launcher.name.Contains(def.key)) continue;
                    GameObject prefab; WeaponInfo info;
                    if (!Prefabs.TryGetValue(def.key, out prefab) || !Infos.TryGetValue(def.key, out info)) break;
                    var t = Traverse.Create(launcher);
                    t.Field("info").SetValue(info);
                    t.Field("missile").SetValue(prefab);
                    break;
                }
            }
        }

        // ------------------------------------------------------------------
        static GameObject CleanClone(GameObject original, string newName)
        {
            var clone = UnityEngine.Object.Instantiate(original);
            clone.name = newName;
            clone.transform.SetParent(null);
            clone.hideFlags = HideFlags.HideAndDontSave;
            clone.SetActive(false);
            var net = clone.GetComponentInChildren<NetworkIdentity>();
            if (net != null)
            {
                var t = Traverse.Create(net);
                net.PrefabHash = newName.GetHashCode();
                t.Field("_hasSpawned").SetValue(false);
                t.Method("NetworkReset", Array.Empty<object>()).GetValue();
            }
            UnityEngine.Object.DontDestroyOnLoad(clone);
            return clone;
        }
    }
}
