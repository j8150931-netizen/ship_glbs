// ============================================================================
// Flashpoint Fleets 2035 - FFResupplyShip.cs
// Optional ANE-style logistics behavior (modeled on Aryx Naval Expansion's
// ResupplyShip): any ship carrying this component becomes a mobile rearm &
// resupply point for the fleet - the Rearmer capacity is boosted and the
// ship acts as the formation's ammunition tender.
// Attach it in the prefab factory or on any mod ship at runtime.
// ============================================================================

using System;
using UnityEngine;

namespace FlashpointFleets
{
    public class FFResupplyShip : MonoBehaviour
    {
        [Header("FF Resupply Ship")]
        public float resupplyRadius = 1200f;
        public float capacityBoostMult = 2f;
        public int maxContainers = 8;

        private void Awake()
        {
            try
            {
                var rearmer = GetComponent<Rearmer>();
                if (rearmer != null)
                {
                    var t = HarmonyLib.Traverse.Create(rearmer);
                    var cap = t.Field("Capacity");
                    if (cap != null)
                        cap.SetValue(cap.GetValue<float>() * capacityBoostMult);
                    Plugin.Log.LogInfo($"[FF] {name}: resupply fit-out applied (Rearmer capacity x{capacityBoostMult}).");
                }
            }
            catch (Exception e)
            {
                Plugin.Log.LogWarning("[FF] FFResupplyShip Awake issue: " + e.Message);
            }
        }
    }
}
