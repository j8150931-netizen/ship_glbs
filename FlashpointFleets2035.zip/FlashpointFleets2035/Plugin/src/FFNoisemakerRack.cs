// ============================================================================
// Flashpoint Fleets 2035 - FFNoisemakerRack.cs
// Torpedo soft-kill: every Flashpoint ship carries an acoustic noisemaker
// rack. When a torpedo closes inside the threat radius, the ship fires a
// spread of decoy buoys that bubble loudly and seduce acoustic/optical
// seekers. The buoys register themselves in a static list that the
// companion TorpedoShield DLL reads to divert incoming torpedoes.
//
// The rack is attached to the ship prefabs by FF_PrefabFactory (when this
// DLL is present in Assets/Plugins at build time). Buoys are procedural
// (no bundle dependency) so this works even on vanilla+mod ships.
// ============================================================================

using System.Collections.Generic;
using UnityEngine;

namespace FlashpointFleets
{
    /// <summary>Static registry read by TorpedoShield's seduction patch.</summary>
    public static class NoisemakerField
    {
        public struct Buoy
        {
            public Vector3 position;
            public float expiresAt;
            public float strength; // 0..1 seduction weight
        }

        public static readonly List<Buoy> Buoys = new List<Buoy>();

        public static void Prune()
        {
            float now = Time.time;
            for (int i = Buoys.Count - 1; i >= 0; i--)
                if (Buoys[i].expiresAt < now) Buoys.RemoveAt(i);
        }

        public static Buoy? Nearest(Vector3 pos, float maxRange)
        {
            Buoy? best = null;
            float bestSqr = maxRange * maxRange;
            for (int i = 0; i < Buoys.Count; i++)
            {
                var b = Buoys[i];
                if (b.expiresAt < Time.time) continue;
                var d = (b.position - pos).sqrMagnitude;
                if (d < bestSqr) { bestSqr = d; best = b; }
            }
            return best;
        }
    }

    public class FFNoisemakerRack : MonoBehaviour
    {
        [Header("FF Noisemaker Rack")]
        public float threatRadius = 2200f;
        public float cooldown = 22f;
        public int buoysPerSalvo = 2;
        public float buoyLifetime = 55f;
        public float buoySpacing = 90f;

        private float _nextSalvo;
        private float _nextScan;
        private const float ScanInterval = 1.5f;

        private readonly List<Ship> _threatCache = new List<Ship>();

        void Awake()
        {
            // config overrides (BepInEx), preferring the global values
            try
            {
                if (Plugin.CfgNoisemakerRadius != null) threatRadius = Plugin.CfgNoisemakerRadius.Value;
                if (Plugin.CfgNoisemakerCooldown != null) cooldown = Plugin.CfgNoisemakerCooldown.Value;
            }
            catch { /* config not ready - keep inspector values */ }
        }

        void FixedUpdate()
        {
            if (!Plugin.CfgNoisemakers.Value) return;
            if (Time.time < _nextScan) return;
            _nextScan = Time.time + ScanInterval;
            if (Time.time < _nextSalvo) return;

            if (!ScanForTorpedo(threatRadius)) return;

            DeploySalvo();
            _nextSalvo = Time.time + cooldown;
        }

        bool ScanForTorpedo(float radius)
        {
            // Cheap scan: any Missile unit underwater (y < 0.5) within radius.
            // TorpedoShield refines this with its own classifier; this coarse
            // check is intentionally dependency-free.
            var missiles = UnityEngine.Object.FindObjectsOfType<Missile>();
            if (missiles == null) return false;
            var origin = transform.position;
            foreach (var m in missiles)
            {
                if (m == null || !m.isActiveAndEnabled) continue;
                var p = m.transform.position;
                if (p.y > 0.5f) continue; // not a torpedo-like contact
                if ((p - origin).sqrMagnitude > radius * radius) continue;
                return true;
            }
            return false;
        }

        void DeploySalvo()
        {
            var origin = transform.position;
            for (int i = 0; i < buoysPerSalvo; i++)
            {
                // spread the salvo across the beam so the incoming fan must choose
                var side = (i % 2 == 0) ? 1f : -1f;
                var offset = transform.right * (side * buoySpacing * ((i / 2) + 1))
                           + transform.forward * (Random.Range(-40f, 40f));
                SpawnBuoy(origin + offset);
            }
            Plugin.Log.LogDebug($"[FF] {name}: noisemaker salvo deployed ({buoysPerSalvo} buoys).");
        }

        void SpawnBuoy(Vector3 pos)
        {
            var go = new GameObject("FF_NoisemakerBuoy");
            go.transform.position = pos;

            // visual: small float + bubble column
            var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "body";
            body.transform.SetParent(go.transform, false);
            body.transform.localScale = new Vector3(0.6f, 0.4f, 0.6f);
            body.transform.localPosition = new Vector3(0, 0.2f, 0);
            Object.Destroy(body.GetComponent<Collider>()); // purely visual
            var mat = body.GetComponent<Renderer>()?.material;
            if (mat != null)
            {
                mat.color = new Color(0.9f, 0.85f, 0.3f, 0.9f);
                mat.SetFloat("_Surface", 1); if (mat.HasProperty("_Mode")) mat.SetFloat("_Mode", 2);
            }

            var bubbles = go.AddComponent<ParticleSystem>();
            var main = bubbles.main;
            main.startLifetime = 3.5f;
            main.startSpeed = new ParticleSystem.MinMaxCurve(1.2f, 2.6f);
            main.startSize = new ParticleSystem.MinMaxCurve(0.4f, 1.4f);
            main.maxParticles = 120;
            main.loop = true;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var emission = bubbles.emission;
            emission.rateOverTime = 35f;
            var shape = bubbles.shape;
            shape.shapeType = ParticleSystemShapeType.Cone;
            shape.angle = 12f;
            shape.radius = 0.5f;
            var sol = bubbles.colorOverLifetime;
            sol.enabled = true;

            var sink = go.AddComponent<FFNoisemakerBuoy>();
            sink.lifetime = buoyLifetime;

            NoisemakerField.Buoys.Add(new NoisemakerField.Buoy
            {
                position = pos,
                expiresAt = Time.time + buoyLifetime,
                strength = 0.75f
            });
            NoisemakerField.Prune();
        }
    }

    /// <summary>Sinks slowly, bubbles loudly, despawns after its lifetime.</summary>
    public class FFNoisemakerBuoy : MonoBehaviour
    {
        public float lifetime = 55f;
        private float _born;

        void OnEnable() { _born = Time.time; }

        void Update()
        {
            transform.position += Vector3.down * (0.06f * Time.deltaTime);
            if (Time.time - _born > lifetime)
                Destroy(gameObject);
        }
    }
}
