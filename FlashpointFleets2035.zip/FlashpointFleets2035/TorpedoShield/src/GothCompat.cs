// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / GothCompat.cs
// GOTH MOMMY interop layer.
//
// TorpedoShield composes with GOTH by design (postfix vs prefix patches),
// and this module adds explicit cooperation:
//   * reads GOTH's config when present (SAM coordinator cooldown, buddy
//     defense radii) so torpedo engagement pacing matches GOTH's SAM pacing
//   * if GOTH's SAM coordinator already allocated interceptors against a
//     contact, we don't double-prioritize it
//   * when GOTH is absent, TorpedoShield uses its own config values
// ============================================================================

using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace FlashpointFleets.TorpedoShield
{
    public static class GothCompat
    {
        static bool _probed;
        static FieldInfo _threatCooldownField;   // GOTH Plugin.SAM_ThreatReengageCooldown
        static object _gothPlugin;

        public static bool GothActive => Plugin.HasGoth;

        /// <summary>GOTH's per-threat reengage cooldown if installed (else ours).</summary>
        public static float ReengageCooldown
        {
            get
            {
                if (GothActive && Probe() && _threatCooldownField != null)
                {
                    try
                    {
                        var entry = _threatCooldownField.GetValue(null);
                        var value = entry?.GetType().GetProperty("Value")?.GetValue(entry);
                        if (value is float f) return f;
                    }
                    catch { }
                }
                return Plugin.CfgReengageCooldown != null ? Plugin.CfgReengageCooldown.Value : 4f;
            }
        }

        static bool Probe()
        {
            if (_probed) return _threatCooldownField != null || _gothPlugin != null;
            _probed = true;
            try
            {
                var pluginType = AccessTools.TypeByName("GroundOverTheHorizon.Plugin");
                if (pluginType != null)
                    _threatCooldownField = AccessTools.Field(pluginType, "SAM_ThreatReengageCooldown");
            }
            catch { }
            return _threatCooldownField != null;
        }

        /// <summary>
        /// True when GOTH's SAM coordinator has already assigned interceptors
        /// to this threat (we then leave the pacing to GOTH). Reflects
        /// TrackingInfo.missileAttacks exactly like RippleSam does.
        /// </summary>
        public static bool AlreadyEngagedByFleet(Unit firingUnit, Unit threat)
        {
            try
            {
                var ti = firingUnit.NetworkHQ?.GetTrackingData(threat.persistentID);
                return ti != null && ti.missileAttacks > 0;
            }
            catch { return false; }
        }
    }
}
