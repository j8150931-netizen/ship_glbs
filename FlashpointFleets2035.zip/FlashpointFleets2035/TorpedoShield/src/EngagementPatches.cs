// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / EngagementPatches.cs
// Target-priority rules once a torpedo is detected:
//   * ASW/interceptor-armed launchers get TOP priority on torpedo tracks
//     (they hard-kill; the game's own FireControl then does the rest).
//   * CIWS/guns engage surfaced or near-surface torpedoes only.
//   * Standard SAMs normally IGNORE torpedoes (config can allow it).
// All postfixes -> compose with GOTH's AssessTargetPriority/ChooseTarget
// coordinator instead of fighting it.
// ============================================================================

using System;
using HarmonyLib;
using UnityEngine;

namespace FlashpointFleets.TorpedoShield
{
    [HarmonyPatch(typeof(Turret), "AssessTargetPriority")]
    public static class Turret_AssessTargetPriority_Torpedo_Patch
    {
        private static readonly AccessTools.FieldRef<Turret, WeaponStation[]> WeaponStationsRef =
            AccessTools.FieldRefAccess<Turret, WeaponStation[]>("weaponStations");

        [HarmonyPostfix]
        public static void Postfix(Turret __instance, Unit targetCandidate, ref float priorityThreshold)
        {
            if (__instance == null || targetCandidate == null) return;
            if (Plugin.CfgSonar == null || !Plugin.CfgSonar.Value) return;
            try
            {
                if (!TorpedoClassifier.IsTorpedo(targetCandidate)) return;

                var unit = __instance.GetComponentInParent<Unit>();
                var d = Vector3.Distance(__instance.transform.position, targetCandidate.transform.position);
                if (unit != null && targetCandidate.NetworkHQ == unit.NetworkHQ) return; // own torpedo
                if (d > Plugin.CfgEngagementRadius.Value) return;

                bool isAsw = TurretIsAsw(__instance);
                bool isGun = TurretIsGun(__instance);
                bool surfaced = targetCandidate.transform.position.y > -1.2f;

                if (isAsw)
                {
                    // dedicated ASW battery: torpedo tracks are the mission
                    priorityThreshold = Mathf.Max(priorityThreshold, 100000f);
                    Plugin.Dbg($"ASW turret {__instance.name} prioritizes torpedo {targetCandidate.name} @{d:F0}m");
                }
                else if (isGun && Plugin.CfgCiwsVsTorpedo.Value && surfaced)
                {
                    // CIWS can only hurt what it can reach: surfaced torpedoes
                    priorityThreshold = Mathf.Max(priorityThreshold, 60000f);
                }
                else if (!isGun && !isAsw && Plugin.CfgSamVsTorpedo.Value)
                {
                    // desperate measure, off by default
                    priorityThreshold = Mathf.Max(priorityThreshold, 400f);
                }
                else
                {
                    // everything else ignores the torpedo (don't waste SAMs)
                    priorityThreshold = -1f;
                }
            }
            catch (Exception e) { Plugin.Dbg("priority issue: " + e.Message); }
        }

        internal static bool TurretIsAsw(Turret turret)
        {
            try
            {
                var stations = WeaponStationsRef(turret);
                if (stations == null) return false;
                foreach (var st in stations)
                {
                    if (st == null) continue;
                    MissileLauncher launcher = null;
                    if (st.Weapons != null)
                        foreach (var w in st.Weapons)
                        {
                            launcher = w as MissileLauncher;
                            if (launcher != null) break;
                        }
                    if (launcher == null) continue;
                    var name = launcher.name ?? "";
                    // Flashpoint ASW launchers carry their catalog key in the name
                    if (name.Contains("FF_Yu8") || name.Contains("FF_Mk54") ||
                        name.IndexOf("ASROC", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        name.IndexOf("ASW", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        name.IndexOf("RBU", StringComparison.OrdinalIgnoreCase) >= 0)
                        return true;
                    // torpedo-mod Mako users (any mod ship that mounts it)
                    var info = Traverse.Create(launcher).Field("info").GetValue() as WeaponInfo;
                    if (info != null && info.name != null &&
                        info.name.IndexOf("Torpedo", StringComparison.OrdinalIgnoreCase) >= 0)
                        return true;
                }
            }
            catch { }
            return false;
        }

        internal static bool TurretIsGun(Turret turret)
        {
            try
            {
                return turret.GetComponentInChildren<Gun>(true) != null;
            }
            catch { return false; }
        }
    }
}
