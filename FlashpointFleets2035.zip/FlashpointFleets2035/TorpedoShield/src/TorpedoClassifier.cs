// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / TorpedoClassifier.cs
// Identifies torpedo units. Two modes (combinable):
//   ByName  - known torpedo mods: SonPamungkas' Torpedo (TorpedoFast/Light/
//             Big/20kt = Mako/Lemon/Hammerhead/Megalodon), Flashpoint's own
//             Mk54/Yu-8, and anything whose name/jsonKey says "torp".
//   ByTrait - any Missile running at/below the surface with torpedo-like
//             speed (covers future/unknown torpedo mods automatically).
// ============================================================================

using System;
using System.Collections.Generic;
using UnityEngine;

namespace FlashpointFleets.TorpedoShield
{
    public static class TorpedoClassifier
    {
        // SonPamungkas' Torpedo mod (cloned vanilla missiles):
        static readonly HashSet<string> KnownTorpedoNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "TorpedoFast", "TorpedoLight", "TorpedoBig", "Torpedo20kt", // torpedo mod internal names
            "SCT-350 'Mako'", "Type-88 'Lemon'", "HT-200 'Hammerhead'", "NT-2 'Megalodon' (20kt)",
        };

        // Flashpoint ASW weapons that swim:
        static readonly HashSet<string> FlashpointSwimmers = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "FF_Mk54", "FF_Yu8",
        };

        public enum Mode { ByName, ByTrait, Both }

        public static Mode ActiveMode
        {
            get
            {
                var s = Plugin.CfgClassification != null ? Plugin.CfgClassification.Value : "Both";
                if (string.Equals(s, "ByName", StringComparison.OrdinalIgnoreCase)) return Mode.ByName;
                if (string.Equals(s, "ByTrait", StringComparison.OrdinalIgnoreCase)) return Mode.ByTrait;
                return Mode.Both;
            }
        }

        public static bool IsTorpedo(Unit unit)
        {
            if (unit == null || unit is not Missile missile) return false;
            return IsTorpedo(missile);
        }

        public static bool IsTorpedo(Missile missile)
        {
            if (missile == null) return false;
            var mode = ActiveMode;
            if (mode == Mode.ByTrait) return ByTrait(missile);
            if (ByName(missile)) return true;
            return mode == Mode.Both && ByTrait(missile);
        }

        static bool ByName(Missile missile)
        {
            var n = missile.name;
            if (!string.IsNullOrEmpty(n))
            {
                if (KnownTorpedoNames.Contains(n)) return true;
                if (n.IndexOf("torp", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            var def = missile.definition;
            if (def != null)
            {
                var jk = def.jsonKey;
                if (!string.IsNullOrEmpty(jk) && jk.IndexOf("torp", StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;
            }
            return false;
        }

        static bool ByTrait(Missile missile)
        {
            try
            {
                var p = missile.transform.position;
                if (p.y > 0.75f) return false;         // flying, not swimming
                var rb = missile.GetComponent<Rigidbody>();
                float speed = rb != null ? rb.velocity.magnitude : 0f;
                if (speed > 140f) return false;         // faster than any torpedo
                if (speed < 3f) return false;           // floating debris / dead
                return true;
            }
            catch { return false; }
        }

        /// <summary>Sonar range for a given torpedo (deep ones are harder).</summary>
        public static float SonarRangeFor(Missile torpedo)
        {
            var deep = torpedo.transform.position.y < -2f;
            return deep ? Plugin.CfgSonarRangeSubmerged.Value : Plugin.CfgSonarRange.Value;
        }
    }
}
