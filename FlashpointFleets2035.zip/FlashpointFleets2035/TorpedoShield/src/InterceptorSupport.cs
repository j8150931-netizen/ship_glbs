// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / InterceptorSupport.cs
//   1. SEDUCTION - noisemaker buoys (from the main Flashpoint plugin) pull
//      inbound torpedoes off their firing solution by nudging their steering
//      inputs toward the buoy. Reads the main mod's NoisemakerField via
//      reflection so this DLL works with or without it.
//   2. PER-SHIP DEFENSE HOST - a lightweight component TorpedoShield adds to
//      every Ship at runtime (vanilla, ANE, Flashpoint) that runs:
//        - torpedo-evasion steering ("combing the tracks")
// The watch loop is driven from the plugin's own MonoBehaviour Update, so it
// does not depend on any game-internal Update method existing.
// ============================================================================

using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace FlashpointFleets.TorpedoShield
{
    // ------------------------------------------------------------------
    // 1. SEDUCTION - steering bias toward active noisemaker buoys
    // ------------------------------------------------------------------
    [HarmonyPatch(typeof(Missile), "SetAimpoint")]
    public static class Missile_SetAimpoint_Seduction_Patch
    {
        private static readonly AccessTools.FieldRef<Missile, Vector3> InputsRef =
            AccessTools.FieldRefAccess<Missile, Vector3>("inputs");

        // main-plugin buoy field (reflected, optional)
        static MethodInfo _nearestMethod;
        static bool _mainProbeDone;

        [HarmonyPostfix]
        public static void Postfix(Missile __instance)
        {
            if (!Plugin.CfgSeduction.Value || __instance == null) return;
            try
            {
                if (!TorpedoClassifier.IsTorpedo(__instance)) return;

                var buoy = NearestBuoy(__instance.transform.position, Plugin.CfgSeductionRadius.Value);
                if (buoy == null) return;

                var pos = (Vector3)GetBuoyPosition(buoy);
                var toBuoy = pos - __instance.transform.position;
                toBuoy.y = 0f;
                if (toBuoy.sqrMagnitude < 1f) return;

                // bias the torpedo's steering input toward the buoy - an organic
                // pull rather than a hard snap, so re-locked guidance can fight it
                var local = __instance.transform.InverseTransformDirection(toBuoy.normalized);
                var inp = InputsRef(__instance);
                InputsRef(__instance) = new Vector3(
                    Mathf.Lerp(inp.x, Mathf.Clamp(local.x, -1f, 1f), 0.30f),
                    inp.y,
                    inp.z);
            }
            catch (Exception e) { Plugin.Dbg("seduction issue: " + e.Message); }
        }

        static object NearestBuoy(Vector3 pos, float range)
        {
            try
            {
                if (!_mainProbeDone)
                {
                    _mainProbeDone = true;
                    var ffMain = AccessTools.TypeByName("FlashpointFleets.NoisemakerField");
                    if (ffMain != null)
                        _nearestMethod = AccessTools.Method(ffMain, "Nearest");
                }
                if (_nearestMethod == null) return null;
                return _nearestMethod.Invoke(null, new object[] { pos, range });
            }
            catch { return null; }
        }

        static object GetBuoyPosition(object buoy)
        {
            var f = buoy.GetType().GetField("position");
            return f != null ? f.GetValue(buoy) : (object)Vector3.zero;
        }
    }

    // ------------------------------------------------------------------
    // 2. PER-SHIP DEFENSE HOST + watchdog
    // ------------------------------------------------------------------
    public static class TorpedoWatchdog
    {
        private static float _nextTick;

        /// <summary>Called from the TorpedoShield plugin's Update.</summary>
        internal static void Tick()
        {
            if (Time.time < _nextTick) return;
            _nextTick = Time.time + 0.5f;

            foreach (var ship in UnityEngine.Object.FindObjectsOfType<Ship>())
            {
                if (ship == null || ship.disabled) continue;
                if (ship.GetComponent<TorpedoShieldHost>() == null)
                    ship.gameObject.AddComponent<TorpedoShieldHost>();
            }
        }
    }

    /// <summary>Per-ship defense brain: torpedo-evasion steering.</summary>
    public class TorpedoShieldHost : MonoBehaviour
    {
        private float _nextEvadeCheck;

        void Update()
        {
            if (!Plugin.CfgEvade.Value) return;
            if (Time.time < _nextEvadeCheck) return;
            _nextEvadeCheck = Time.time + 1.5f;
            try { Evade(); } catch { }
        }

        void Evade()
        {
            var ship = GetComponent<Ship>();
            if (ship == null || ship.disabled) return;

            Missile nearest = null;
            float bestSqr = Plugin.CfgEvadeRadius.Value * Plugin.CfgEvadeRadius.Value;
            foreach (var m in UnityEngine.Object.FindObjectsOfType<Missile>())
            {
                if (m == null || !m.isActiveAndEnabled || !TorpedoClassifier.IsTorpedo(m)) continue;
                if (m.NetworkHQ == ship.NetworkHQ) continue; // own torpedo
                var d = (m.transform.position - transform.position).sqrMagnitude;
                if (d < bestSqr) { bestSqr = d; nearest = m; }
            }
            if (nearest == null) return;

            // comb the tracks: steer until the torpedo bears abeam
            var toTorp = nearest.transform.position - transform.position;
            toTorp.y = 0f;
            var forward = transform.forward; forward.y = 0f;
            var angle = Vector3.SignedAngle(forward, toTorp.normalized, Vector3.up);
            if (Mathf.Abs(angle) < 60f || Mathf.Abs(angle) > 120f)
            {
                var steer = angle >= 0f ? -1f : 1f;
                ApplyRudder(steer * 0.6f);
                Plugin.Dbg($"{name}: combing tracks (torpedo {Mathf.Sqrt(bestSqr):F0} m, bearing {angle:F0})");
            }
        }

        void ApplyRudder(float steer)
        {
            try
            {
                var prop = GetComponentInChildren<ShipPropulsion>();
                if (prop == null) return;
                var t = Traverse.Create(prop);
                var inputs = t.Field("inputs");
                if (inputs == null) return;
                var v = (Vector3)inputs.GetValue();
                inputs.SetValue(new Vector3(Mathf.Lerp(v.x, steer, 0.25f), v.y, v.z));
            }
            catch { /* propulsion layout differs - skip silently */ }
        }
    }
}
