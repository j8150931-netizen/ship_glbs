// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / Plugin.cs
// Companion DLL: ship AI + radar alteration for torpedo defense, compatible
// with GOTH MOMMY (SonPamungkas), Aryx Naval Expansion, and every other
// ship mod that uses the game's Ship class.
//
//   * SONAR   : all ships (vanilla, ANE, Flashpoint, any Ship) detect
//               torpedoes inside the sonar envelope - even underwater, even
//               with GOTH's over-the-horizon radar math active.
//   * ENGAGE  : ASW-armed ships auto-launch interceptors at torpedo tracks;
//               CIWS engage surfaced/near-surface torpedoes.
//   * SOFT-KILL: noisemaker decoys seduce inbound torpedoes (uses the main
//               Flashpoint plugin's buoy field when present).
//   * EVADE   : threatened ships comb the torpedo tracks (optional).
//
// All patches are Harmony POSTFIXes - they compose after vanilla AND after
// GOTH's prefixes, so both load orders are safe.
// ============================================================================

using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace FlashpointFleets.TorpedoShield
{
    public static class MyPluginInfo
    {
        public const string PLUGIN_GUID = "com.flashpoint.torpedoshield";
        public const string PLUGIN_NAME = "TorpedoShield";
        public const string PLUGIN_VERSION = "0.9.0";

        public const string FF_MAIN_GUID = "com.flashpoint.fleets2035"; // soft
        public const string GOTH_GUID = "neutral.gothmommy";            // soft
        public const string TORPEDO_GUID = "com.sonpamungkas.torpedo";  // soft
    }

    [BepInPlugin(MyPluginInfo.PLUGIN_GUID, MyPluginInfo.PLUGIN_NAME, MyPluginInfo.PLUGIN_VERSION)]
    [BepInDependency(MyPluginInfo.FF_MAIN_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(MyPluginInfo.GOTH_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(MyPluginInfo.TORPEDO_GUID, BepInDependency.DependencyFlags.SoftDependency)]
    public class Plugin : BaseUnityPlugin
    {
        internal static ManualLogSource Log;
        internal static Harmony Harmony;

        // ---- sonar ----
        internal static ConfigEntry<bool> CfgSonar;
        internal static ConfigEntry<float> CfgSonarRange;
        internal static ConfigEntry<float> CfgSonarRangeSubmerged; // vs deep torpedoes
        internal static ConfigEntry<string> CfgClassification;
        // ---- engagement ----
        internal static ConfigEntry<bool> CfgInterceptors;
        internal static ConfigEntry<bool> CfgCiwsVsTorpedo;
        internal static ConfigEntry<bool> CfgSamVsTorpedo;
        internal static ConfigEntry<float> CfgEngagementRadius;
        internal static ConfigEntry<float> CfgReengageCooldown;
        // ---- soft kill ----
        internal static ConfigEntry<bool> CfgSeduction;
        internal static ConfigEntry<float> CfgSeductionRadius;
        // ---- evasion ----
        internal static ConfigEntry<bool> CfgEvade;
        internal static ConfigEntry<float> CfgEvadeRadius;
        // ---- misc ----
        internal static ConfigEntry<bool> CfgDebug;

        void Awake()
        {
            Log = Logger;

            CfgSonar = Config.Bind("Sonar", "Enable", true,
                "Ships detect torpedoes inside the sonar envelope (works with GOTH's radar overhaul active).");
            CfgSonarRange = Config.Bind("Sonar", "Range", 7000f,
                "Sonar detection range in meters for surfaced/near-surface torpedoes.");
            CfgSonarRangeSubmerged = Config.Bind("Sonar", "RangeDeep", 3200f,
                "Sonar detection range in meters for deep-running torpedoes.");
            CfgClassification = Config.Bind("Sonar", "Classification", "Both",
                "How to classify torpedoes: ByName (SonPamungkas torpedo mod names only), ByTrait (any missile " +
                "running underwater), or Both.");

            CfgInterceptors = Config.Bind("Engagement", "Interceptors", true,
                "ASW-armed ships automatically engage torpedo tracks (hard-kill).");
            CfgCiwsVsTorpedo = Config.Bind("Engagement", "CiwsVsTorpedo", true,
                "CIWS/gun turrets engage surfaced or near-surface torpedoes.");
            CfgSamVsTorpedo = Config.Bind("Engagement", "SamVsTorpedo", false,
                "Allow standard SAMs to engage torpedoes (expensive - usually a waste of interceptors).");
            CfgEngagementRadius = Config.Bind("Engagement", "Radius", 6500f,
                "Radius around the ship in which torpedo tracks may be engaged.");
            CfgReengageCooldown = Config.Bind("Engagement", "ReengageCooldown", 4f,
                "Seconds before the same torpedo track may be re-engaged.");

            CfgSeduction = Config.Bind("SoftKill", "NoisemakerSeduction", true,
                "Inbound torpedoes can be seduced by noisemaker buoys (Flashpoint ships auto-deploy them).");
            CfgSeductionRadius = Config.Bind("SoftKill", "SeductionRadius", 900f,
                "Distance at which a torpedo can be pulled toward a noisemaker buoy.");

            CfgEvade = Config.Bind("Evasion", "CombTracks", true,
                "Threatened ships comb the torpedo tracks (steer parallel to the attack bearing).");
            CfgEvadeRadius = Config.Bind("Evasion", "EvadeRadius", 2600f,
                "Radius that triggers torpedo-evasion steering.");

            CfgDebug = Config.Bind("Debug", "Verbose", false, "Log torpedo detections and engagements.");

            Harmony = new Harmony(MyPluginInfo.PLUGIN_GUID);
            Harmony.PatchAll();

            Log.LogInfo($"TorpedoShield {MyPluginInfo.PLUGIN_VERSION} loaded. " +
                        $"Flashpoint main mod: {HasFlashpointMain}; GOTH: {HasGoth}; Torpedo mod: {HasTorpedoMod}.");
        }

        void OnDestroy() => Harmony?.UnpatchSelf();

        // BepInEx plugins are MonoBehaviours - drive the watchdog from here
        // rather than patching a game-internal Update method.
        private void Update()
        {
            try { TorpedoWatchdog.Tick(); }
            catch { /* never let defense housekeeping spam the log */ }
        }

        internal static bool HasFlashpointMain =>
            BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(MyPluginInfo.FF_MAIN_GUID);
        internal static bool HasGoth =>
            BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(MyPluginInfo.GOTH_GUID);
        internal static bool HasTorpedoMod =>
            BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(MyPluginInfo.TORPEDO_GUID);

        internal static void Dbg(string msg)
        {
            if (CfgDebug != null && CfgDebug.Value) Log.LogInfo("[TorpedoShield] " + msg);
        }
    }
}
