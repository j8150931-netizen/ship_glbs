// ============================================================================
// Flashpoint Fleets 2035 - TorpedoShield / SonarPatches.cs
// The "radar alteration": torpedo detection for every ship.
//
// 1) Radar.RadarCheck POSTFIX  - after vanilla/GOTH have run their sweep,
//    we request detection checks for torpedo-class contacts inside the
//    sonar envelope (no radar cone: sonar is omni).
// 2) Radar.CanSeeRadarReturn POSTFIX - if the contact is a torpedo inside
//    sonar range, the return is forced visible (low-RCS underwater contacts
//    would otherwise never pass the radar equation).
//
// Both are POSTFIXes: GOTH's PREFIX patches (RadarCheck / CanSeeRadarReturn /
// DetectorManager.RequestRadarCheck) run first and are fully honored; we
// only *add* sonar contacts afterwards. Load order independent.
// ============================================================================

using System;
using HarmonyLib;
using NuclearOption.Jobs;
using UnityEngine;

namespace FlashpointFleets.TorpedoShield
{
    // ------------------------------------------------------------------
    // Feed torpedo contacts into the detection pipeline.
    // ------------------------------------------------------------------
    [HarmonyPatch(typeof(Radar), "RadarCheck")]
    public static class Radar_RadarCheck_Sonar_Patch
    {
        private static float _nextSweep;

        [HarmonyPostfix]
        public static void Postfix(Radar __instance)
        {
            if (__instance == null) return;
            if (Plugin.CfgSonar == null || !Plugin.CfgSonar.Value) return;
            try
            {
                // throttle: the game calls RadarCheck per detector tick; we add
                // our own sweep at most 4x/second
                if (Time.unscaledTime < _nextSweep) return;
                _nextSweep = Time.unscaledTime + 0.25f;

                var radarUnit = __instance.GetComponentInParent<Unit>();
                if (radarUnit == null || radarUnit.disabled) return;
                // only ships get sonar (aircraft radars stay vanilla)
                if (radarUnit.GetComponentInParent<Ship>() == null && radarUnit is not Ship) return;

                var origin = __instance.transform.position;
                var maxRange = Plugin.CfgSonarRange.Value;

                foreach (var missile in UnityEngine.Object.FindObjectsOfType<Missile>())
                {
                    if (missile == null || !missile.isActiveAndEnabled) continue;
                    if (!TorpedoClassifier.IsTorpedo(missile)) continue;
                    var rng = TorpedoClassifier.SonarRangeFor(missile);
                    if (rng > maxRange) maxRange = rng;

                    var to = (Vector3)missile.transform.position - origin;
                    to.y = 0f;
                    if (to.sqrMagnitude > rng * rng) continue;

                    // ask the standard pipeline to evaluate this contact;
                    // CanSeeRadarReturn (below) makes sure it passes.
                    if (missile is IRadarReturn rr)
                        DetectorManager.RequestRadarCheck(__instance, missile, rr);
                }
            }
            catch (Exception e)
            {
                Plugin.Dbg("sonar sweep issue: " + e.Message);
            }
        }
    }

    // ------------------------------------------------------------------
    // Force sonar contacts visible inside the envelope.
    // ------------------------------------------------------------------
    [HarmonyPatch(typeof(Radar), "CanSeeRadarReturn")]
    public static class Radar_CanSeeRadarReturn_Sonar_Patch
    {
        [HarmonyPostfix]
        public static void Postfix(Radar __instance, IRadarReturn radarReturn, float dist, ref bool __result)
        {
            if (__instance == null || radarReturn == null) return;
            if (Plugin.CfgSonar == null || !Plugin.CfgSonar.Value) return;
            if (__result) return; // already visible (e.g. surfaced torpedo) - done

            try
            {
                if (radarReturn is not Missile missile) return;
                if (!TorpedoClassifier.IsTorpedo(missile)) return;

                var radarUnit = __instance.GetComponentInParent<Unit>();
                if (radarUnit == null) return;
                if (radarUnit.GetComponentInParent<Ship>() == null && radarUnit is not Ship) return;

                float range = TorpedoClassifier.SonarRangeFor(missile);
                if (dist <= range)
                {
                    __result = true;
                    Plugin.Dbg($"sonar contact: {missile.name} at {dist:F0} m from {radarUnit.name}");
                }
            }
            catch (Exception e)
            {
                Plugin.Dbg("sonar return issue: " + e.Message);
            }
        }
    }

    // ------------------------------------------------------------------
    // Bridge TargetDetector (the bridge lookout on Flashpoint ships and the
    // detectors ANE uses) so ships without a Radar component still see
    // torpedo tracks. Same throttled sweep pattern.
    // ------------------------------------------------------------------
    [HarmonyPatch(typeof(TargetDetector), "CheckVisual")]
    public static class TargetDetector_CheckVisual_Sonar_Patch
    {
        private static float _nextSweep;

        [HarmonyPostfix]
        public static void Postfix(TargetDetector __instance)
        {
            if (__instance == null) return;
            if (Plugin.CfgSonar == null || !Plugin.CfgSonar.Value) return;
            if (__instance is Radar) return; // Radar path handled above
            try
            {
                if (Time.unscaledTime < _nextSweep) return;
                _nextSweep = Time.unscaledTime + 0.3f;

                var unit = __instance.GetComponentInParent<Unit>();
                if (unit == null || unit.disabled) return;
                if (unit is not Ship && unit.GetComponentInParent<Ship>() == null) return;

                var detected = AccessTools.FieldRefAccess<TargetDetector, System.Collections.Generic.List<Unit>>("detectedTargets");
                var list = detected(__instance);
                var origin = __instance.transform.position;

                foreach (var missile in UnityEngine.Object.FindObjectsOfType<Missile>())
                {
                    if (missile == null || !missile.isActiveAndEnabled) continue;
                    if (!TorpedoClassifier.IsTorpedo(missile)) continue;
                    if (list != null && list.Contains(missile)) continue;
                    var rng = TorpedoClassifier.SonarRangeFor(missile);
                    var to = (Vector3)missile.transform.position - origin;
                    to.y = 0f;
                    if (to.sqrMagnitude > rng * rng) continue;
                    if (missile.NetworkHQ == unit.NetworkHQ) continue; // own torpedo
                    list?.Add(missile);
                    Plugin.Dbg($"bridge sonar contact: {missile.name} -> {unit.name}");
                }
            }
            catch (Exception e)
            {
                Plugin.Dbg("bridge sweep issue: " + e.Message);
            }
        }
    }
}
